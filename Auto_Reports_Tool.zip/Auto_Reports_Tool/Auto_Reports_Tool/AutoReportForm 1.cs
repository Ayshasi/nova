﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO.Compression;
using System.Xml;
using System.Xml.Linq;
using System.Net;
using System.Net.Mail;
using System.Configuration;
using System.Data.SqlClient;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Xml.XPath;
using Xl = Microsoft.Office.Interop.Excel;
namespace Auto_Reports_Tool
{
    public partial class AutoReportForm : Form
    {
        public System.Timers.Timer Tm = new System.Timers.Timer(180000);
        //public System.Timers.Timer Tm = new System.Timers.Timer(10000);
        CommonClass Cs = new CommonClass();
        DBClass Db = new DBClass();
        XLClass xl = new XLClass();
        public string TarsFile = "";
        public AutoReportForm()
        {
            InitializeComponent();
        }
        private void AutoReportForm_Load(object sender, EventArgs e)
        {
            SerializedClass.GetInfo();
            Db.GetConnectinInfo();
            SerializedClass.p = this;
            Startbtn.Enabled = false;
            StopBtn.Enabled = true;
            Tm.Enabled = true;
            Tm.Elapsed += new System.Timers.ElapsedEventHandler(ProcessFiles);
            Tm.Start();
        }
        private void Main_Form_closed(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void Startbtn_Click_1(object sender, EventArgs e)
        {
            SerializedClass.GetInfo();
            Db.GetConnectinInfo();
            Startbtn.Enabled = false;
            StopBtn.Enabled = true;
            Tm.Enabled = true;
            Tm.Elapsed += new System.Timers.ElapsedEventHandler(ProcessFiles);
            Tm.Start();
        }

        public void ProcessFiles(object o, System.Timers.ElapsedEventArgs e)
        {
            Tm.Stop();

            try
            {

                if (DateTime.Now.Hour == 02 && DateTime.Today.DayOfWeek == DayOfWeek.Wednesday && Directory.GetFiles(System.Environment.CurrentDirectory + @"\SAGE_Report\", "SAGE_TTP_Report_" + DateTime.Now.ToString("ddMMyyyy") + @"_02*.xlsx").Length == 0)
                {
                    Statusupdate("Today's SAGE TTP Report Generation...");
                    Cs.SaveToReport("Status: Today's SAGE TTP Report Generation...");
                    xl.SAGETATSPEEDReport();
                }

                //xl.CUP_PM_Weekly_Report_New();

                //Statusupdate("Today's Frontiers TTP Report Generation...");
                //Cs.SaveToReport("Status: Today's Frontiers TTP Report Generation...");
                //xl.FrontiersTATSPEEDReport();

                //Cs.SaveToReport("Status: Searching Frontiers Manuscript: frontiers_booking@novatechset.com");

                //Cs.DownloadFrontiersEmail();
                //if (Directory.Exists(@"\\techsetserver2\Download\Frontiers\Manuscript\Move"))
                //{
                //    foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\Frontiers\Manuscript\Move", "*.zip"))
                //    {
                //        Statusupdate("Processing Zip: " + Path.GetFileName(Z));
                //        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                //        Cs.Book_FrontiersNew(Z);
                //    }
                //}
                //Cs.SaveToReport("Status: Searching Frontiers Correction: frontiers_booking@novatechset.com");

                //if (Directory.Exists(@"\\techsetserver2\Download\Frontiers\Correction\Move"))
                //{
                //    foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\Frontiers\Correction\Move", "*.zip"))
                //    {
                //        Statusupdate("Processing Zip: " + Path.GetFileName(Z));
                //        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                //        //Cs.Book_FrontiersNew(Z);
                //        //try
                //        //{
                //        //    using (File.OpenRead(Z)) { }
                //        //}
                //        //catch (Exception ee) { continue; }
                //        //if (Cs.ExtractZip(Z) == true)
                //        //{
                //        //    //Cs.Book_Frontiers(SerializedClass.CurrentLocation1);
                //        //    Cs.Book_FrontiersNew(SerializedClass.CurrentLocation1);

                //        //}

                //        //try { using (File.OpenRead(Z)) { } }
                //        //catch (Exception e1) { continue; }
                //        //if (Cs.ExtractZip(Z) == true) 
                //        //{
                //            Cs.Book_FrontiersAU(SerializedClass.CurrentLocation1,Z);
                //        //}
                //    }
                //}

                Statusupdate("Searching 1 CUP XLS txt files...");
                if (Directory.Exists(@"\\TECHSETSERVER2\Upload\Customer_Uploads\CUP_XLS\txt"))
                {
                    foreach (string Z in Directory.GetFiles(@"\\TECHSETSERVER2\Upload\Customer_Uploads\CUP_XLS\txt", "*.txt"))
                    {
                        Statusupdate("Processing 1 CUP XLS txt: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing 1 CUP XLS txt  file: " + Path.GetFileName(Z));
                        xl.Convert_CUP_TXTtoExcel(Z);
                    }
                }
            }
            catch (Exception exp)
            {
                Cs.SaveToReport(exp.Message + "<br>" + exp.StackTrace);
            }

            try
            {
                Cs.ValidateAPS();
            }
            catch (Exception APSval)
            {
                Cs.SaveToReport(APSval.Message + "<br>" + APSval.StackTrace);
            }
            try
            {
                string url = "https://api.novatechset.com/api/manuscripts/watch";
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Timeout = 90000;
                using (WebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    byte[] bytes = ReadFully(response.GetResponseStream());
                    var str = System.Text.Encoding.UTF8.GetString(bytes);
                    if ((str.Split('|').Length != 2) || (str.Split('|').Length == 2 && str.Split('|')[0] == @"""0"))
                    {
                        Cs.SendMail(str, "", "APS", true, "APSHIT");
                    }
                }
            }
            catch (WebException e1)
            {
                Cs.SendMail(e1.Message + "\n" + e1.StackTrace, "", "APS", true, "APSHIT");
                Cs.SaveToReport(e1.Message + "<br>" + e1.StackTrace);
            }



            foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Upload\Customer_Uploads\FRONTIERS", "*.txt"))
            {
                Statusupdate("Processing Txt: " + Path.GetFileName(Z));
                Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                //Cs.Book_Frontiersrevisesbooking((SerializedClass.CurrentLocation1), Path.GetFileName(Z));
                Cs.Book_FrontiersrevisesbookingNew((SerializedClass.CurrentLocation1), Path.GetFileName(Z));

            }
            foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\Frontiers\Republish", "*.txt"))
            {
                Statusupdate("Processing Txt: " + Path.GetFileName(Z));
                Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                Cs.Book_FrontiersRepublish((SerializedClass.CurrentLocation1), Path.GetFileName(Z));

            }
            /*try
            {
                Db.Sqladptr = new SqlDataAdapter(new SqlCommand("SELECT * FROM UploadProcess WHERE UploadStatus IN ('OPEN','PROCESSING','DWNST','DWNEN','UPDST','UPDEN','CPY2BP') ", Db.GetConnectionSesame()));
                Db.OpenConnectionSesame();
                Db.dt = new DataTable();
                Db.Sqladptr.Fill(Db.dt);
                Db.CloseConnectionSesame();
                Cs.SaveToReport("Status: SELECT * FROM UploadProcess WHERE UploadStatus IN ('OPEN','PROCESSING','DWNST','DWNEN','UPDST','UPDEN','CPY2BP') ...");
                Cs.SaveToReport("Status: OSA long stay count: " + Db.dt.Rows.Count.ToString() + "...");
                if (Db.dt.Rows.Count > 0)
                {
                    string Msg = "";
                    foreach (DataRow dr in Db.dt.Rows)
                    {
                        Cs.SaveToReport("Status: Condition checking OSA long stay Article: " + dr["ArticleID"].ToString() + "...");
                        string strtime = dr["ProcessStartTime"].ToString();
                        var culture = System.Globalization.CultureInfo.InvariantCulture;
                        //DateTime ddate = DateTime.ParseExact(strtime, "M/dd/yyyy HH:mm:ss", culture);
                        DateTime ddate = new DateTime();
                        if (Regex.IsMatch(strtime, @"^\d{1}/\d{1}/\d{4}")) ddate = DateTime.ParseExact(strtime, "M/d/yyyy HH:mm:ss", culture);
                        else if (Regex.IsMatch(strtime, @"^\d{2}/\d{2}/\d{4}")) ddate = DateTime.ParseExact(strtime, "MM/dd/yyyy HH:mm:ss", culture);
                        else if (Regex.IsMatch(strtime, @"^\d{2}/\d{1}/\d{4}")) ddate = DateTime.ParseExact(strtime, "MM/d/yyyy HH:mm:ss", culture);
                        else if (Regex.IsMatch(strtime, @"^\d{1}/\d{2}/\d{4}")) ddate = DateTime.ParseExact(strtime, "M/dd/yyyy HH:mm:ss", culture);
                        if (DateTime.Now > ddate.AddHours(5).AddMinutes(40) && ddate.ToString("MM/dd/yyyy HH:mm:ss") != "01/01/0001 00:00:00")
                        {
                            //if (DateTime.Now >= ddate.AddHours(6))
                            //{
                            //    string Query = "update UploadProcess set UploadStatus='Closed' where id=" + dr["id"].ToString();
                            //    Db.SqlCmd = new System.Data.SqlClient.SqlCommand(Query, Db.GetConnectionSesame());
                            //    Db.OpenConnectionSesame();
                            //    Db.SqlReader = Db.SqlCmd.ExecuteReader();
                            //    Db.SqlReader.Close();
                            //    System.Net.Mail.MailMessage MM1 = new System.Net.Mail.MailMessage("osatechsupport@novatechset.com", "Rajasekar@novatechset.com", "OSA file Long stay Error: " + dr["ArticleID"].ToString(), @"Dear Team,<Br/><Br/>OSA: File Long stay Error for: " + dr["ArticleID"].ToString() + "<Br/><Br/>File: " + dr["FileName"].ToString() + "<Br/>UploadStatus: " + dr["UploadStatus"].ToString() + "<Br/>File in time (IST): " + ddate.AddHours(5).AddMinutes(30) + "<Br/>File in time (Actual): " + ddate + "<Br/>More than 30 mins not processed so closed manualy.<Br/>" + "Regards,<Br/>TechSupport.");
                            //    MM1.To.Add("tiworkflow@novatechset.com");
                            //    System.Net.Mail.SmtpClient client1 = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                            //    MM1.IsBodyHtml = true;
                            //    client1.Send(MM1);
                            //}
                            //else
                            //{
                            //System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("osatechsupport@novatechset.com", "Rajasekar@novatechset.com", "OSA file Long stay Error: " + dr["ArticleID"].ToString(), @"Dear Team,<Br/><Br/>OSA: File Long stay Error for: " + dr["ArticleID"].ToString() + "<Br/><Br/>File: " + dr["FileName"].ToString() + "<Br/>UploadStatus: " + dr["UploadStatus"].ToString() + "<Br/>File in time (IST): " + ddate.AddHours(5).AddMinutes(30) + "<Br/>File in time (Actual): " + ddate + "<Br/><Br/>" + "Regards,<Br/>TechSupport.");
                            //MM.To.Add("tiworkflow@novatechset.com");
                            //System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                            //MM.IsBodyHtml = true;
                            //client.Send(MM);
                            //}
                            Msg += "<tr><td>" + dr["ArticleID"].ToString() + "</td><td>" + dr["FileName"].ToString() + "</td><td>" + dr["UploadStatus"].ToString() +
"</td><td>" + ddate.AddHours(5).AddMinutes(30) + "</td><td>" + ddate + "</td><td>" + dr["SystemName"].ToString() + "</td></tr>";
                        }
                    }
                    if (Msg != "")
                    {
                        Msg = "<table border=\"1\"><tr><th>Artice ID</th><th>File Name</th><th>Status</th><th>In Time(IST)</th><th>In Time(Actual)</th><th>System Name</th></tr>" + Msg + "</table>";
                        System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("osatechsupport@novatechset.com", "Rajasekar@novatechset.com", "OSA file Long stay Error", @"Dear Team,<Br/><Br/>OSA: File Long stay Error for below Articles. <Br/><Br/>" + Msg + "<Br/>Regards,<Br/>TechSupport.");
                        MM.To.Add("tiworkflow@novatechset.com");
                        System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                        MM.IsBodyHtml = true;
                        client.Send(MM);
                    }
                    else Cs.SaveToReport("Status: No record found. OSA long stay ...");
                }
            }
            catch (Exception ee)
            {
                System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("osatechsupport@novatechset.com", "tiworkflow@novatechset.com", "Unable to validate OSA file Long stay Error", @"Dear Team,<Br/><Br/>OSA: Unable to validate OSA file Long stay Error.<Br/><Br/>Error Message: " + ee.Message + "<Br/>" + ee.StackTrace + "<Br/><Br/>" + "Regards,<Br/>TechSupport.");
                MM.To.Add("Rajasekar@novatechset.com");
                MM.To.Add("tiworkflow@novatechset.com");
                System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                MM.IsBodyHtml = true;
                client.Send(MM);
            }*/
            try
            {
                if (Directory.Exists(@"\\techsetserver2\Upload\TARS"))
                {
                    DirectoryInfo info = new DirectoryInfo(@"\\techsetserver2\Upload\TARS");
                    FileInfo[] files = info.GetFiles().OrderBy(p => p.CreationTime).ToArray();
                    if (files.Length > 0)
                    {
                        FileInfo f = files[0];
                        if (DateTime.Now > f.CreationTime.AddMinutes(30) && TarsFile != f.FullName)
                        {
                            System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("automailer@novatechset.com", "kameshwaran@novatechset.com", "TARS TXT file Long stay Error", @"Dear Team,<Br/><Br/>TARS: TXT file Long stay Error for: " + f.FullName + "<Br/>File in time: " + f.CreationTime + "<Br/><Br/>" + "Regards,<Br/>TechSupport.");
                            MM.CC.Add("Rajasekar@novatechset.com");
                            MM.CC.Add("Saravanakumar@novatechset.com");
                            MM.CC.Add("tiworkflow@novatechset.com");
                            System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                            MM.IsBodyHtml = true;
                            client.Send(MM);
                            TarsFile = f.FullName;
                        }
                    }
                }

            }
            catch (Exception TErr) { }

            //Commented on 14th DEC 2020 P.Parthiban;
            //try
            //{
            //    DBClass db = new DBClass();
            //    string strQuery = "with CTE as (Select Artcl_ArticleId Article,Jrnl_Acronym Journal from Article artcl with(nolock) inner join Journal jrnl with(nolock) on  Artcl_JrnlId=Jrnl_Id where Jrnl_PublID=43 and CONVERT(varchar,Artcl_ReceivedDt,112)>= CONVERT(varchar,GETDATE()-3,112)) select distinct Journal,STUFF((SELECT ',' + US.Article FROM CTE US where us.Journal=Li.Journal FOR XML PATH('')), 1, 1, '') ArticleList from CTE LI";
            //    db.Sqladptr = new SqlDataAdapter(new SqlCommand(strQuery, db.GetConnection()));
            //    db.dt = new DataTable();
            //    db.Sqladptr.Fill(db.dt);
            //    db.CloseConnection();
            //    DataTable dtChennai = db.dt.Copy();
            //    string strMailbody = "";
            //    for (int i = 0; i < dtChennai.Rows.Count; i++)
            //    {
            //        string strQueryBlr = "select arch.ArtChap_ArticleChapterId,ACM.ACM_ReceivedDt,ACM_StgID from ArticleChapter arch with (nolock) inner join VolumeIssue VI  with (nolock) on VI.VI_ArtChapId=arch.ArtChap_Id inner join ArtChapMain ACM with (nolock) on ACM.ACM_Id=VI.VI_ACMId  inner join JournalBook JB with (NOLOCK) on JB.JB_Id=arch.ArtChap_JbID where ArtChap_ArticleChapterId not in (select items from [dbo].[Split]('" + dtChennai.Rows[i]["ArticleList"].ToString() + "',',')) and CONVERT(varchar,ACM_ReceivedDt,112)>= CONVERT(varchar,GETDATE()-3,112) and JB.JB_Acronym='" + dtChennai.Rows[i]["Journal"].ToString() + "' and ACM_ReceivedDt<DATEADD(MINUTE,-30,GETDATE()) and ACM_StgID=90";
            //        db.Sqladptr = new SqlDataAdapter(new SqlCommand(strQueryBlr, db.GetConnectionBlr()));
            //        db.dt = new DataTable();
            //        db.Sqladptr.Fill(db.dt);
            //        db.CloseConnection();
            //        for (int j = 0; j < db.dt.Rows.Count; j++)
            //        {
            //            if (strMailbody == "")
            //                strMailbody = "<table><tr><th>Article ID</th><th>Recevied Date</th></tr>";
            //            strMailbody = strMailbody + "<tr><td>" + db.dt.Rows[j]["ArtChap_ArticleChapterId"].ToString() + "</td><td>" + db.dt.Rows[j]["ACM_ReceivedDt"].ToString() + "</td></tr>";
            //        }
            //    }
            //    if (strMailbody != "")
            //    {
            //        strMailbody = strMailbody + "</table>";
            //        System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("tiworkflow@novatechset.com", "tiworkflow@novatechset.com", "RSC Book-in Article Mismatched", "Article not found in Chennai DB, but present in Bangalore DB.</br>" + strMailbody + "Regards,<Br/>TechSupport.");
            //        MM.CC.Add("techteamblr@novatechset.com");
            //        System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
            //        MM.IsBodyHtml = true;
            //        client.Send(MM);
            //    }
            //}
            //catch (Exception RSCErr)
            //{ }

            try
            {
                if (DateTime.Now.Hour == 02 && DateTime.Today.DayOfWeek == DayOfWeek.Wednesday && Directory.GetFiles(System.Environment.CurrentDirectory + @"\SAGE_Report\", "SAGE_TTP_Report_" + DateTime.Now.ToString("ddMMyyyy") + @"_02*.xlsx").Length == 0)
                {
                    Statusupdate("Today's SAGE TTP Report Generation...");
                    Cs.SaveToReport("Status: Today's SAGE TTP Report Generation...");
                    xl.SAGETATSPEEDReport();
                }
                if (DateTime.Now.Hour == 18 && DateTime.Today.DayOfWeek == DayOfWeek.Tuesday && Directory.GetFiles(System.Environment.CurrentDirectory + @"\SAGE_Report\", "SAGE_TTP_Report_" + DateTime.Now.ToString("ddMMyyyy") + @"_18*.xlsx").Length == 0)
                {
                    Statusupdate("Today's SAGE TTP Report Generation...");
                    Cs.SaveToReport("Status: Today's SAGE TTP Report Generation...");
                    xl.SAGETATSPEEDReport();
                }
                if (DateTime.Now.Hour == 20 && DateTime.Today.DayOfWeek != DayOfWeek.Saturday && DateTime.Today.DayOfWeek != DayOfWeek.Sunday && Directory.GetFiles(System.Environment.CurrentDirectory + @"\AIP_Report\", "AIP_Excel_Report_" + DateTime.Now.ToString("ddMMyyyy") + @"*.xlsx").Length == 0)
                {
                    Statusupdate("Today's AIP Report Generation...");
                    Cs.SaveToReport("Status: Today's AIP Report Generation...");
                    xl.CreateReport();
                }
                if (DateTime.Now.Hour == 08 && Directory.GetFiles(System.Environment.CurrentDirectory + @"\SAGE_Report\", "SAGE_Excel_Report_" + DateTime.Now.ToString("ddMMyyyy") + @"_08*.xlsx").Length == 0)
                {
                    Statusupdate("Today's SAGE Report Generation...");
                    Cs.SaveToReport("Status: Today's SAGE Report Generation...");
                    xl.SAGE_TempCreateReport();
                }
                if (DateTime.Now.Hour == 12 && Directory.GetFiles(System.Environment.CurrentDirectory + @"\SAGE_Report\", "SAGE_Excel_Report_" + DateTime.Now.ToString("ddMMyyyy") + @"_12*.xlsx").Length == 0)
                {
                    Statusupdate("Today's SAGE Report Generation...");
                    Cs.SaveToReport("Status: Today's SAGE Report Generation...");
                    xl.SAGE_TempCreateReport();
                }
                if (DateTime.Now.Hour == 16 && Directory.GetFiles(System.Environment.CurrentDirectory + @"\SAGE_Report\", "SAGE_Excel_Report_" + DateTime.Now.ToString("ddMMyyyy") + @"_16*.xlsx").Length == 0)
                {
                    Statusupdate("Today's SAGE Report Generation...");
                    Cs.SaveToReport("Status: Today's SAGE Report Generation...");
                    xl.SAGE_TempCreateReport();
                }
                if (DateTime.Now.Hour == 20 && Directory.GetFiles(System.Environment.CurrentDirectory + @"\SAGE_Report\", "SAGE_Excel_Report_" + DateTime.Now.ToString("ddMMyyyy") + @"_20*.xlsx").Length == 0)
                {
                    Statusupdate("Today's SAGE Report Generation...");
                    Cs.SaveToReport("Status: Today's SAGE Report Generation...");
                    xl.SAGE_TempCreateReport();
                }
                if (DateTime.Now.Hour == 23 && Directory.GetFiles(System.Environment.CurrentDirectory + @"\SAGE_Report\", "SAGE_Excel_Report_" + DateTime.Now.ToString("ddMMyyyy") + @"_23*.xlsx").Length == 0)
                {
                    Statusupdate("Today's SAGE Report Generation...");
                    Cs.SaveToReport("Status: Today's SAGE Report Generation...");
                    xl.SAGE_TempCreateReport();
                }
                if (DateTime.Now.Hour == 19 && Directory.GetFiles(System.Environment.CurrentDirectory + @"\SAGE_Report\", "SAGE_Excel_Report_" + DateTime.Now.ToString("ddMMyyyy") + @"_07*.xlsx").Length == 0)
                {
                    Statusupdate("Today's SAGE Report Generation...");
                    Cs.SaveToReport("Status: Today's SAGE Report Generation...");
                    xl.SAGE_CreateReport();
                }
                if (DateTime.Now.Hour == 9 && Directory.GetFiles(System.Environment.CurrentDirectory + @"\SAGE_Report\", "SAGE_Excel_Report_" + DateTime.Now.ToString("ddMMyyyy") + @"_09*.xlsx").Length == 0)
                {
                    Statusupdate("Today's SAGE Report Generation...");
                    Cs.SaveToReport("Status: Today's SAGE Report Generation...");
                    xl.SAGE_CreateReport();
                }
                if (DateTime.Now.Hour == 9 && Directory.GetFiles(System.Environment.CurrentDirectory + @"\SAGE_Report\", "SAGE_PM_Excel_Report_" + DateTime.Now.ToString("ddMMyyyy") + @"_09*.xlsx").Length == 0)
                {
                    Statusupdate("Today's SAGE PM Report Generation...");
                    Cs.SaveToReport("Status: Today's SAGE PM Report Generation...");
                    xl.SAGE_PM_CreateReport();
                }
                if (DateTime.Now.Hour == 19 && Directory.GetFiles(System.Environment.CurrentDirectory + @"\SAGE_Report\", "SAGE_PM_Excel_Report_" + DateTime.Now.ToString("ddMMyyyy") + @"_07*.xlsx").Length == 0)
                {
                    Statusupdate("Today's SAGE PM Report Generation...");
                    Cs.SaveToReport("Status: Today's SAGE PM Report Generation...");
                    xl.SAGE_PM_CreateReport();
                }
                //****             
                if (DateTime.Now.Hour == 8 && !File.Exists(System.Environment.CurrentDirectory + @"\IWAP_Report\IWAP_Report_" + DateTime.Now.ToString("ddMMyyyy") + @".txt"))
                {
                    Statusupdate("Today's IWAP Report Generation...");
                    Cs.SaveToReport("Status: Today's IWAP Report Generation...");
                    xl.IWAP_DailyReport();
                }
                //****             
                if (DateTime.Now.Hour == 10 && !File.Exists(System.Environment.CurrentDirectory + @"\CUP_Report\CUP_Report_" + DateTime.Now.ToString("ddMMyyyy") + @".txt"))
                {
                    Statusupdate("Today's CUP Report Generation...");
                    Cs.SaveToReport("Status: Today's CUP Report Generation...");
                    xl.CUP_DailyReport();
                }
                //**** 
                if (DateTime.Now.Hour == 8 && !File.Exists(System.Environment.CurrentDirectory + @"\Frontiers_Report\CrossRef_DOI_Details_" + DateTime.Now.ToString("ddMMyyyy") + @".txt"))
                {
                    Statusupdate("Today's Frontiers CrossRef_DOI_Details Report Generation...");
                    Cs.SaveToReport("Status: Today's Frontiers CrossRef_DOI_Details Report...");
                    xl.Frontiers_Daily_Report();
                }
                //**** 
                if (DateTime.Now.Hour == 9 && !File.Exists(System.Environment.CurrentDirectory + @"\CUP_Report\CUPPM_Report_" + DateTime.Now.ToString("ddMMyyyy") + @".txt"))
                {
                    Statusupdate("CUP PM Daily Report Generation...");
                    Cs.SaveToReport("Status: CUP PM Daily Report Generation...");
                    //xl.CUP_PM_Weekly_Report();
                    xl.CUP_PM_Weekly_Report_New();
                }
                //****     
                if (DateTime.Now.DayOfWeek == DayOfWeek.Monday && DateTime.Now.Hour == 9 && !File.Exists(System.Environment.CurrentDirectory + @"\CUP_Report\CUPRCP_Report_" + DateTime.Now.ToString("ddMMyyyy") + @".txt"))
                {
                    Statusupdate("CUP RCP Weekly Report Generation...");
                    Cs.SaveToReport("Status: CUP RCP Weekly Report Generation...");
                    xl.CUP_RCP_Weekly_Report();
                }
                if (DateTime.Now.Day == 1 && DateTime.Now.Hour == 11 && !File.Exists(System.Environment.CurrentDirectory + @"\CUP_Report\CUP_Report_" + DateTime.Now.ToString("ddMMyyyy") + @"_Monthly.txt"))
                {
                    Statusupdate("Last month's CUP Report Generation...");
                    Cs.SaveToReport("Status: Last month's CUP Report Generation...");
                    xl.CUP_MonthlyReport();
                }
                if (DateTime.Now.Hour == 9 && !File.Exists(System.Environment.CurrentDirectory + @"\TnF_Report\TnF_Report_" + DateTime.Now.ToString("ddMMyyyy") + @".txt"))
                {
                    Statusupdate("Today's TnF Report Generation...");
                    Cs.SaveToReport("Status: Today's TnF Report Generation...");
                    xl.TnF_DailyReport();
                }

                if (DateTime.Now.Hour == 10 && !File.Exists(System.Environment.CurrentDirectory + @"\TnF_OnshoreCSHL\TnF_OnshoreCSHL" + DateTime.Now.ToString("ddMMyyyy") + @".txt"))
                {
                    Statusupdate("Today's TnF CSHL Subcode missing articles...");
                    Cs.SaveToReport("Status: CSHL Subcode missing articles...");
                    xl.TnF_OnshoreCSHL();
                }

                if (DateTime.Now.Day == 1 && !File.Exists(System.Environment.CurrentDirectory + @"\Tnf_Resupplyarticle\Tnf_Resupplyarticle" + DateTime.Now.ToString("ddMMyyyy") + @".txt"))
                {
                    Statusupdate("Last month's TnF Resupply article list...");
                    Cs.SaveToReport("Status: Last month's TnF Resupply article list...");
                    xl.Tnf_Resupplyarticle();
                }
                if (DateTime.Now.Hour == 11)
                {
                    Statusupdate("SAGE Reminder checking...");
                    Cs.SaveToReport("Status: SAGE Reminder checking...");
                    Cs.SAGE_PIJ_Reminder();
                    Statusupdate("OSA PE Reminder checking...");
                    Cs.SaveToReport("Status: OSA PE Reminder checking...");
                    Cs.OSA_Onshore_Reminder();
                    Statusupdate("ASCE PE Reminder checking...");
                    Cs.SaveToReport("Status: ASCE PE Reminder checking...");
                    Cs.ASCE_Onshore_Reminder();
                }
            }
            catch (Exception ReportGen)
            {
                Cs.SaveToReport(ReportGen.Message + "<br>" + ReportGen.StackTrace);
            }
            try
            {
                Cs.SaveToReport("Status: Searching AbCATS Email: tsautoabcats@novatechset.com");
                Cs.DownloadEmail();
                Cs.SaveToReport("Status: Searching SAGE Email: tsautoSAGE@novatechset.com");
                Cs.DownloadSAGEEmail();
                Cs.SaveToReport("Status: Searching GEO Email: geolsocteam@novatechset.com");
                Cs.DownloadGeoEmail();
                //Cs.SaveToReport("Status: Searching Frontiers Email: frontiers_booking@novatechset.com");
                //Cs.DownloadFrontiersEmailDelete();
                //Cs.DownloadFrontiersEmail();
                //if (Directory.Exists(@"\\techsetserver2\Download\Frontiers\Manuscript\Move"))
                //if (Directory.Exists(@"\\techsetserver2\Download\Frontiers\Manuscript\Move"))
                //{
                //    foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\Frontiers\Manuscript\Move", "*.zip"))
                //    {
                //        Statusupdate("Processing Zip: " + Path.GetFileName(Z));
                //        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                //        Cs.Book_FrontiersNew(Z);
                //        //try
                //        //{
                //        //    using (File.OpenRead(Z)) { }
                //        //}
                //        //catch (Exception ee) { continue; }
                //        //if (Cs.ExtractZip(Z) == true)
                //        //{
                //        //    //Cs.Book_Frontiers(SerializedClass.CurrentLocation1);
                //        //    Cs.Book_FrontiersNew(SerializedClass.CurrentLocation1);
                //        //}
                //    }
                //}
                Statusupdate("Searching CUP XLS txt files...");
                if (Directory.Exists(@"\\TECHSETSERVER2\Upload\Customer_Uploads\CUP_XLS\txt"))
                {
                    foreach (string Z in Directory.GetFiles(@"\\TECHSETSERVER2\Upload\Customer_Uploads\CUP_XLS\txt", "*.txt"))
                    {
                        Statusupdate("Processing 2 CUP XLS txt: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing 2 CUP XLS txt  file: " + Path.GetFileName(Z));
                        xl.Convert_CUP_TXTtoExcel(Z);
                    }
                }
                //***
                Statusupdate("Searching Excel files...");
                //if (SerializedClass.WatchLocation1 != "" && Directory.Exists(SerializedClass.WatchLocation1))
                //{
                //    Cs.SaveToReport("Status:Searching Excel files...");
                //    foreach (string Z in Directory.GetFiles(SerializedClass.WatchLocation1, "*.xls*"))
                //    {
                //        Statusupdate("Processing Excel: " + Path.GetFileName(Z));
                //        Cs.SaveToReport("Status: Processing Excel file: " + Path.GetFileName(Z));
                //        Cs.Book_COB(Z, SerializedClass.CurrentLocation1);
                //    }
                //    SerializedClass.GetInfo();
                //}
                if (SerializedClass.WatchLocation2 != "" && Directory.Exists(SerializedClass.WatchLocation2))
                {
                    SerializedClass.CurrentLocation1 = SerializedClass.CurrentLocation2;
                    Cs.SaveToReport("Status:Searching Excel files...");
                    foreach (string Z in Directory.GetFiles(SerializedClass.WatchLocation2, "*.xls*"))
                    {
                        Statusupdate("Processing Excel: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing Excel file: " + Path.GetFileName(Z));
                        Cs.Book_APS_Printer(Z, SerializedClass.CurrentLocation1);
                    }
                    //foreach (string Z in Directory.GetFiles(SerializedClass.WatchLocation2, "*.xlsx"))
                    //{
                    //    Statusupdate("Processing Excel: " + Path.GetFileName(Z));
                    //    Cs.SaveToReport("Status: Processing Excel file: " + Path.GetFileName(Z));
                    //    Cs.Book_APS_Printer(Z, SerializedClass.CurrentLocation1);
                    //}
                    SerializedClass.GetInfo();
                }
                if (SerializedClass.WatchLocation10 != "" && Directory.Exists(SerializedClass.WatchLocation10))
                {
                    SerializedClass.CurrentLocation1 = SerializedClass.CurrentLocation10;
                    //foreach (string Z in Directory.GetFiles(@"E:\PARTHIBAN\ZipExtract_WatchPath1\ZipExtract_Inpath", "*.zip"))
                    //{
                    //    Statusupdate("Processing Zip: " + Path.GetFileName(Z));
                    //    Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                    //    try
                    //    {
                    //        using (File.OpenRead(Z)) { }
                    //    }
                    //    catch (Exception ee) { continue; }
                    //    if (Cs.ExtractZip(Z) == true)
                    //    {
                    //        Cs.Book_NewIssue_SAGE(SerializedClass.CurrentLocation1);
                    //    }
                    //}
                    foreach (string Z in Directory.GetFiles(SerializedClass.WatchLocation10, "*.zip"))
                    {
                        Statusupdate("Processing Zip: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        try
                        {
                            using (File.OpenRead(Z)) { }
                        }
                        catch (Exception ee) { continue; }
                        if (Cs.ExtractZip(Z) == true)
                        {
                            Cs.Book_NewIssue_SAGE(SerializedClass.CurrentLocation1);
                        }
                    }
                    foreach (string Z in Directory.GetFiles(SerializedClass.WatchLocation10, "*.txt"))
                    {
                        Statusupdate("Processing Txt: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        Cs.Book_Issue_SAGE(SerializedClass.CurrentLocation1, Z);
                    }
                    foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\Sage\ISSUES\Revised_Running_Order", "*.xls*"))
                    //foreach (string Z in Directory.GetFiles(@"E:\PARTHIBAN\ZipExtract_WatchPath1\ZipExtract_Inpath", "*.xls*"))
                    {
                        Statusupdate("Processing Txt: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        Cs.Book_Issue_Resupply_SAGE(SerializedClass.CurrentLocation1, Z);
                    }
                    foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\Sage\ISSUES\Move\Printer", "*.txt"))
                    {
                        Statusupdate("Processing Zip: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        Cs.Book_Issue_SAGE_Printer(SerializedClass.CurrentLocation1, Z);
                    }
                    foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\Sage\ISSUES\Move\Printer", "*.zip"))
                    {
                        Statusupdate("Processing Zip: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        Cs.Book_Issue_SAGE_Printer(SerializedClass.CurrentLocation1, Z);
                    }
                    foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\Sage\login\DOI_Updated", "*.txt"))
                    {
                        Statusupdate("Processing Txt: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: " + File.ReadAllText(Z));
                        if (Regex.IsMatch(Path.GetFileNameWithoutExtension(Z).ToUpper(), @"^(CC BY\-NC|CC BY NC ND|CC BY)$"))
                        {
                            foreach (string f in File.ReadLines(Z))
                            {
                                if (f.Trim() == "") continue;
                                string Aid = f.Trim();
                                Aid = Cs.ReturnDetail("Artcl_ArticleId", "Article", Db, "Artcl_JrnlId in (select Jrnl_Id from Journal where Jrnl_PublID='4') and Artcl_ArticleId='" + Aid + "'");
                                if (Aid != "" && Cs.CheckWhetherFileBooked(Aid))
                                {
                                    string Query = @"UPDATE article SET Artcl_OUPCopyright='" + Path.GetFileNameWithoutExtension(Z).ToUpper() + "' Where Artcl_ArticleId='" + Aid + "'";
                                    Db.SqlCmd = new System.Data.SqlClient.SqlCommand(Query, Db.GetConnection());
                                    Cs.SaveToReport("Status: " + Query + " " + Aid);
                                    Db.OpenConnection();
                                    Db.SqlReader = Db.SqlCmd.ExecuteReader();
                                    Db.SqlReader.Close();
                                    if (Directory.Exists(@"\\Techsetserver2\Journal\SAGE\" + Regex.Match(Aid.ToUpper(), @"^(([A-Z]*?)+)\d+$").Groups[1].Value + @"\Articles\DataSupplied\" + Aid + @"\First Proof\" + Aid + @"\"))
                                    {
                                        File.WriteAllText(@"\\Techsetserver2\Journal\SAGE\" + Regex.Match(Aid.ToUpper(), @"^(([A-Z]*?)+)\d+$").Groups[1].Value + @"\Articles\DataSupplied\" + Aid + @"\First Proof\" + Aid + @"\" + Path.GetFileName(Z), "");
                                    }
                                    else
                                    {
                                        File.WriteAllText(@"\\Techsetserver2\Journal\SAGE\" + Regex.Match(Aid.ToUpper(), @"^(([A-Z]*?)+)\d+$").Groups[1].Value + @"\Articles\DataSupplied\" + Aid + @"\First Proof\" + Path.GetFileName(Z), "");
                                    }
                                }
                            }
                        }
                        else
                        {
                            foreach (string f in File.ReadLines(Z))
                            {
                                if (f.Trim() == "") continue;
                                string Aid = f.Trim().Substring(f.Trim().Length - 6);
                                Aid = Cs.ReturnDetail("Artcl_ArticleId", "Article", Db, "Artcl_JrnlId in (select Jrnl_Id from Journal where Jrnl_PublID='4') and Artcl_ArticleId like'%" + Aid + "'");
                                if (Aid != "" && Cs.CheckWhetherFileBooked(Aid) && f.ToUpper() != Aid.ToUpper())
                                {
                                    string Query = @"UPDATE article SET Artcl_doi='" + f.Trim() + "' Where Artcl_ArticleId='" + Aid + "'";
                                    Db.SqlCmd = new System.Data.SqlClient.SqlCommand(Query, Db.GetConnection());
                                    Cs.SaveToReport("Status: " + Query + " " + Aid);
                                    Db.OpenConnection();
                                    Db.SqlReader = Db.SqlCmd.ExecuteReader();
                                    Db.SqlReader.Close();
                                    Db.SqlCmd = new System.Data.SqlClient.SqlCommand(Query, Db.GetConnectionBlr());
                                    Db.OpenConnectionBlr();
                                    Db.SqlReader = Db.SqlCmd.ExecuteReader();
                                    Cs.SaveToReport("Status: Bangalore DB " + Query + " " + Aid);
                                    Db.SqlReader.Close();
                                }
                            }
                        }
                        if (!Directory.Exists(@"\\techsetserver2\Download\Sage\login\DOI_Updated\Error\Backup\")) Directory.CreateDirectory(@"\\techsetserver2\Download\Sage\login\DOI_Updated\Error\Backup\");
                        File.Copy(Z, @"\\techsetserver2\Download\Sage\login\DOI_Updated\Error\Backup\" + Path.GetFileNameWithoutExtension(Z) + "_" + DateTime.Now.ToString("ddMMyyyy_HHmmss") + ".txt", true);
                        File.Delete(Z);
                    }
                    foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\Sage\CorrectionEG", "*_snapshot.pdf"))
                    {
                        Statusupdate("Processing file: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        Cs.SAGEEGCorrection(SerializedClass.CurrentLocation1, Z);
                    }
                    foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\RCS\CorrectionEG", "*_snapshot.pdf"))
                    {
                        Statusupdate("Processing file: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        Cs.RCSEGCorrection(SerializedClass.CurrentLocation1, Z);
                    }
                    foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\Sage\CorrectionEPT", "*_mvp.zip"))
                    {
                        Statusupdate("Processing file: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        File.Copy(Z, @"\\techsetserver2\Download\Sage\Corrections\" + Path.GetFileName(Z));
                        File.Delete(Z);
                    }
                    foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\Sage\CorrectionEPT", "*.zip"))
                    {
                        Statusupdate("Processing file: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        Cs.SAGEEPTCorrection(SerializedClass.CurrentLocation1, Z);
                    }
                    foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\Sage\CorrectionPDF", "*.zip"))
                    {
                        Statusupdate("Processing file: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        Cs.SagePDFCorrection(SerializedClass.CurrentLocation1, Z);
                    }
                    foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\Sage\CorrectionEG", "*.zip"))
                    {
                        Statusupdate("Processing Zip: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        try
                        {
                            using (File.OpenRead(Z)) { }
                        }
                        catch (Exception ee) { continue; }
                        if (Cs.ExtractZip(Z) == true)
                        {
                            Cs.SAGEPRCorrection(SerializedClass.CurrentLocation1);
                        }
                    }
                    foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\Sage\Set_Priority", "*.xml"))
                    {
                        Statusupdate("Processing Zip: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        try
                        {
                            XDocument xdoc = XDocument.Parse(File.ReadAllText(Z));
                            foreach (XElement e1 in xdoc.XPathSelectElements(@"//articles/article").ToList())
                            {
                                string Aid = "", sch = "";
                                if (e1.Elements("id").ToList().Count > 0) Aid = e1.Elements("id").First().Value;
                                if (e1.Elements("schduledt").ToList().Count > 0) sch = e1.Elements("schduledt").First().Value;
                                if (Aid != "" && Cs.ReturnDetail("Artcl_ArticleId", "Article", Db, "Artcl_JrnlId in (select Jrnl_Id from Journal where Jrnl_PublID='4') and Artcl_ArticleId='" + Aid + "'") != "")
                                {
                                    string Query = @"UPDATE article SET Artcl_Priority='1',Artcl_ScheduledDt='" + sch + "' Where Artcl_JrnlId in (select Jrnl_Id from Journal where Jrnl_PublID='4') and Artcl_ArticleId='" + Aid + "'";
                                    Db.SqlCmd = new System.Data.SqlClient.SqlCommand(Query, Db.GetConnection());
                                    Cs.SaveToReport("Status: " + Query + " " + Aid);
                                    Db.OpenConnection();
                                    Db.SqlReader = Db.SqlCmd.ExecuteReader();
                                    Db.SqlReader.Close();
                                }
                            }
                            File.Delete(Z);
                        }
                        catch (Exception ee) { Cs.SaveToReport("SAGE Priority:  " + ee.Message + @"\n" + ee.StackTrace); continue; }
                    }
                    foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\Sage\Set_Priority", "*.xls*"))
                    {
                        Statusupdate("Processing : " + Path.GetFileName(Z));
                        try
                        {
                            System.Collections.ArrayList ArticleID = new System.Collections.ArrayList();
                            Cs.SaveToReport("Status: Collecting data from excel file: " + Z);
                            Xl.Workbook xlWorkBook;
                            Xl.Worksheet xlWorkSheet;
                            Xl.Application xlapp;
                            xlapp = new Xl.Application();
                            xlapp.Visible = false;
                            xlWorkBook = xlapp.Workbooks.Open(Z);
                            xlWorkSheet = (Xl.Worksheet)xlWorkBook.Sheets[1];
                            int lastRow = xlWorkSheet.Cells.SpecialCells(Xl.XlCellType.xlCellTypeLastCell).Row;
                            System.Array MyValues = (System.Array)xlWorkSheet.get_Range("A1", "B" + lastRow.ToString()).Cells.Value;
                            int ros = MyValues.GetLength(0);
                            int cos = MyValues.GetLength(1);
                            xlapp.Quit();
                            xlapp = null;
                            GC.Collect();
                            GC.WaitForPendingFinalizers();
                            foreach (Process P in Process.GetProcessesByName("EXCEL"))
                            {
                                try
                                {
                                    P.Kill();
                                }
                                catch (Exception e2) { }
                            }
                            for (int i = 1; i <= ros; i++)
                            {
                                string val = "";
                                try
                                {
                                    val = MyValues.GetValue(i, 1).ToString();
                                }
                                catch (Exception e1)
                                {
                                    val = "";
                                    break;
                                }

                                string artid = MyValues.GetValue(i, 1).ToString().Trim();
                                if (!ArticleID.Contains(artid))
                                {
                                    string sch = "";

                                    try
                                    {
                                        sch = MyValues.GetValue(i, 2).ToString().Trim();
                                    }
                                    catch (Exception e1)
                                    {
                                        sch = "";
                                    }
                                    if (artid != "" && Cs.ReturnDetail("Artcl_ArticleId", "Article", Db, "Artcl_JrnlId in (select Jrnl_Id from Journal where Jrnl_PublID='4') and Artcl_ArticleId='" + artid + "'") != "")
                                    {
                                        string Query = @"UPDATE article SET Artcl_Priority='1',Artcl_ScheduledDt='" + sch + "' Where Artcl_JrnlId in (select Jrnl_Id from Journal where Jrnl_PublID='4') and Artcl_ArticleId='" + artid + "'";
                                        if (sch == "") Query = @"UPDATE article SET Artcl_Priority='1' Where Artcl_JrnlId in (select Jrnl_Id from Journal where Jrnl_PublID='4') and Artcl_ArticleId='" + artid + "'";
                                        Db.SqlCmd = new System.Data.SqlClient.SqlCommand(Query, Db.GetConnection());
                                        Cs.SaveToReport("Status: " + Query + " " + artid);
                                        Db.OpenConnection();
                                        Db.SqlReader = Db.SqlCmd.ExecuteReader();
                                        Db.SqlReader.Close();
                                    }
                                }
                            }
                            File.Delete(Z);
                        }
                        catch (Exception ee) { Cs.SaveToReport("SAGE Priority:  " + ee.Message + @"\n" + ee.StackTrace); File.Delete(Z); continue; }
                        SerializedClass.GetInfo();
                    }
                }

                foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\CUP\Openaccess", "*.txt"))
                {
                    Statusupdate("Processing Txt: " + Path.GetFileName(Z));
                    Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                    string Aid = Path.GetFileNameWithoutExtension(Z);
                    Aid = Cs.ReturnDetail("Artcl_ArticleId", "Article", Db, "Artcl_JrnlId in (select Jrnl_Id from Journal where Jrnl_PublID='8') and Artcl_ArticleId ='" + Aid + "'");

                    string AidOpenaccess = Aid + "_OpenAccess";
                    string DD = Cs.CalculateDueDate("", Db, DateTime.Today, 1).ToString("MM/dd/yyyy hh:mm:ss").Replace('-', '/');
                    if (Aid != "" && !Cs.CheckWhetherFileBooked(Aid + "_OpenAccess"))// && !Regex.IsMatch(Aid.ToUpper(),"^(FLM|FLO|COM|PLA)"))
                    {
                        //string Query = @"declare @ArtId as integer  insert into article ([Artcl_ArticleId],[Artcl_Status],[Artcl_DOI],[Artcl_JrnlId],[Artcl_AuthorName],[Artcl_AuthorEmail],[Artcl_DueDtCats],[Artcl_ReceivedDt],[Artcl_ExpFromTIDt],[Artcl_ScheduledDt],[Artcl_Volume],[Artcl_Issue],[Artcl_TextElectronic],[Artcl_TextFolios],[Artcl_TextTables],[Artcl_ArtLineArt],[Artcl_ArtHalftones],[Artcl_ArtColour],[Artcl_ArtSchemes],[Artcl_ArtElectronic],[Artcl_ArtToFollow],[Artcl_ArtReceivedDt],[Artcl_PDFToAuthor],[Artcl_PDFToProdEditor],[Artcl_PDFDespatched],[Artcl_Notes],[Artcl_Comments],[Artcl_WebDelivery],[Artcl_UploadedDt],[Artcl_Remarks],[Artcl_CopyEditing],[Artcl_ArtWork],[Artcl_AuthorPhotos],[Artcl_InlineFigures],[Artcl_StatusWeb],[Artcl_StatusGFX],[Artcl_CompletedDtGFX],[Artcl_ReceivedWeb],[Artcl_ExpTIWeb],[Artcl_ScheduledWeb],[Artcl_RemarkWeb],[Artcl_TypeWeb],[LastModifiedDate],[UsrID],[Artcl_ArtType],[Artcl_Type],[loaded2transaction],[loaded2transactionWeb],[loaded2transactionGFX],[Artcl_Platform],[Artcl_ReceivedSGML],[Artcl_ExpTISGML],[Artcl_ScheduledSGML],[Artcl_RemarkSGML],[Artcl_StatusSGML],[Artcl_UploadedSGML],[Artcl_Seq],[Artcl_Supplement],[Artcl_TotalAuthors],[Artcl_ReceivedTandF],[Artcl_ReceivedTandFWeb],[Artcl_ProofDue],[Sent2TU],[Artcl_PageType],[Artcl_Pages],[Artcl_FirstPage],[Artcl_LastPage],[Artcl_OUPCopyright],[Artcl_OUPOpenAccess],[Artcl_ManuscriptSuppliedEdited],[Artcl_ManuscriptSuppliedBy],[Artcl_SpecInst],[Artcl_OnlinePubDate],[Artcl_IssueCoverMonth],[Artcl_FolderCreated],[Complexity],[TetraBeYN],[TandF_SamJournal],[Artcl_TUsent2CUS],[Proof_Pages],[Artcl_TableLandscape],[Artcl_TablePotrait],[Artcl_OnLineIssue],[Artcl_CupCombined],[Artcl_CupCountry],[Artcl_EmailForCupCombined],[Artcl_NotePadQuerry],[Artcl_TypeSetQuerry],[Artcl_TICategory],[Artcl_IssueYN],[Artcl_Runon],[Artcl_Target],[Artcl_Priority],[Artcl_OupBlock],[Artcl_CETypeSet],[Artcl_TFMD],[Artcl_OupInst],[Artcl_ExpChangeLogNm],[Artcl_HardCopyOrNot],[CSHL_SubCode],[CSHL_MailSubject],[Cshl_EditorMail],[Artcl_RSCategory],[Artcl_RSColorPages],[Artcl_ActualSeq],[Artcl_DisciplineCode],[Artcl_CePages],[Artcl_ShortTitle],[Artcl_IssueSeq],[Artcl_EsmFtitle],[Artcl_EsmFCaption],[Artcl_IssueDesc],[Tetradate],[Artcl_SecondProof],[Artcl_ULType],[Artcl_FigureFileNames],[Artcl_CEName],[Artcl_CEMailID],[Artcl_Oup_MatRefNo],[artcl_invno],[artcl_invDate],[Issue_Invno],[Issue_InvDate],[Issue_Pages],[artcl_Pgs],[Artcl_IntrlInvNo],[Artcl_IntrlInvdate],[Inv_Blankpages],[Inv_ProofPages],[Inv_UploadDate],[Inv_Remark],[Artcl_PageIssueSheet_Check],[Artcl_PreVolume],[Artcl_PreIssue],[sent2Mail],[Artcl_CustomEmailCc],[artcl_TetraDate],[artcl_OptEmail],[Artcl_OUPSection],[Artcl_EprintEmail],[Artcl_onholdmsg],[Artcl_onholdmsgDt],[artcl_CEDuedate],[Artcl_PII],[HoldReleaseDate],[artcl_PrevCEDuedate],[Actual_ReceivedDt],[Actual_ScheduledDt],[artcl_PEDuedate],[Artcl_FVArticle],[artcl_forworkflow],[artcl_TransID],[artcl_TransStatus],[artcl_TransTime],[Artcl_OUPPreul],[Artcl_PEReceivedDt],[Artcl_PEScheduledDt],[Artcl_PEExpFromTIDt],[Artcl_PEUploadedDt],[Artcl_PEStatus],[Artcl_StageType],[artcl_wordcount],[artcl_coarticleid],[artcl_SamJournal],[artcl_TransIDGfx],[Artcl_ComplexType],[Artcl_CupCams],[ProofFraction_Pages],[Artcl_supplemental],[Artcl_VernacularTitle],[Artcl_CustReceiveddt],[Artcl_CustReviseddt],[Artcl_CustAccepteddt],[Artcl_Abstract],[Artcl_ColorFigure],[Artcl_ColorFigureCharge],[Artcl_ConflictofInterest],[Artcl_CopyrightCode],[Artcl_PapDate],[Artcl_PrintColourFigures],[Artcl_OnlineColourFigures],[ProofReference_Pages],[Artcl_EmailCc],[Artcl_EmailBCc],[Artcl_Inv_Relabel],[Artcl_Inv_Redraw],[Artcl_Inv_ScanImport],[Artcl_Rev_Inv_Relabel],[Artcl_Rev_Inv_Redraw],[Artcl_Rev_Inv_ScanImport],[Artcl_VolIssNoTrack],[Artcl_ResupplyType],[Artcl_MCQ],[Artcl_FigComment],[Artcl_Query],[Artcl_QueryPath],[Artcl_Orcid],[Artcl_FigQueryDt],[Artcl_ProofDispatch],[Artcl_UncorrectedProof],[Artcl_UncorrectedDate],[Artcl_ColorFig],[Artcl_ColorPages],[Artcl_AdvanceAccessDate],[Artcl_smartRemarks],[Artcl_ColourPrint],[Artcl_ColourWaived],[Artcl_ColourOnline],[Artcl_Advertisement_Page],[OUP_SPMComments],[Artcl_CEReceiveDate],[artcl_NoOfChars],[artcl_NoOfRefWords],[artcl_NoOfRefChars],[artcl_noofwords],[Artcl_EmbargoDt],[Artcl_SupplementaryData],[Artcl_Feedback],[Artcl_LicenceAccepted],[artcl_SourceBy],[Artcl_PAPSkip_Remark],[Artcl_Mailstatus],[Artcl_CODeleteRemarks],[Artcl_InvName],[Artcl_DelayReason],[Artcl_NoOfQueries],[Artcl_Noofdeletion],[Artcl_NoOfAdditions],[CO_MailStatus],[Artcl_Category],[Artcl_Classification],[Artcl_TnFAUCorr],[Artcl_Batch],[artcl_Reflowarticleid],[Artcl_NoOfPeQueries],[Artcl_AUCorr_RecDT],[Artcl_EDCorr_RecDT],[Artcl_FVPublDT],[Artcl_CEWordCount],[Artcl_CEWordRefCount],[Artcl_RFTAUInserted],[Artcl_RFTAUDeleted],[Artcl_RFTAUModified],[ArticleDeletion],[Artcl_ProofCr],[Artcl_EGProofCr],[Artcl_CC3Score],[Artcl_BookNo],[Artcl_TandFBooking],[JTS_Artcl_TandFBooking],[Artcl_ED_ProofCr],[Artcl_SPM_ProofCr],[Artcl_PE_ProofCr],[Artcl_AU_ProofCr],[Artcl_CUP_Remarks],[Manually_Closed],[artcl_transidamo],[Artcl_TnFPDFDT],[Artcl_NIH],[Artcl_TableKeying],[Artcl_EquationKeying],[Artcl_OtherKeying],[Artcl_RefKeying],[Artcl_CasperLink],[Inv_Reason],[Inv_Reasondate])SELECT [Artcl_ArticleId] + '_OpenAccess',[Artcl_Status]='PG',[Artcl_DOI],[Artcl_JrnlId],[Artcl_AuthorName],[Artcl_AuthorEmail],'" + DD + "',getdate(),'" + DD + "','" + DD + "',[Artcl_Volume],[Artcl_Issue],[Artcl_TextElectronic],[Artcl_TextFolios],[Artcl_TextTables],[Artcl_ArtLineArt],[Artcl_ArtHalftones],[Artcl_ArtColour],[Artcl_ArtSchemes],[Artcl_ArtElectronic],[Artcl_ArtToFollow],[Artcl_ArtReceivedDt],[Artcl_PDFToAuthor],[Artcl_PDFToProdEditor],[Artcl_PDFDespatched],[Artcl_Notes],[Artcl_Comments],[Artcl_WebDelivery],[Artcl_UploadedDt]=NULL,[Artcl_Remarks],[Artcl_CopyEditing],[Artcl_ArtWork],[Artcl_AuthorPhotos],[Artcl_InlineFigures],[Artcl_StatusWeb],[Artcl_StatusGFX],[Artcl_CompletedDtGFX],[Artcl_ReceivedWeb],[Artcl_ExpTIWeb],[Artcl_ScheduledWeb],[Artcl_RemarkWeb],[Artcl_TypeWeb],[LastModifiedDate],[UsrID],'2107',[Artcl_Type],[loaded2transaction],[loaded2transactionWeb],[loaded2transactionGFX],[Artcl_Platform],[Artcl_ReceivedSGML],[Artcl_ExpTISGML],[Artcl_ScheduledSGML],[Artcl_RemarkSGML],[Artcl_StatusSGML],[Artcl_UploadedSGML],[Artcl_Seq],[Artcl_Supplement],[Artcl_TotalAuthors],[Artcl_ReceivedTandF],[Artcl_ReceivedTandFWeb],[Artcl_ProofDue],[Sent2TU],[Artcl_PageType],[Artcl_Pages],[Artcl_FirstPage],[Artcl_LastPage],[Artcl_OUPCopyright],[Artcl_OUPOpenAccess],[Artcl_ManuscriptSuppliedEdited],[Artcl_ManuscriptSuppliedBy],[Artcl_SpecInst],[Artcl_OnlinePubDate],[Artcl_IssueCoverMonth],0,[Complexity],[TetraBeYN],[TandF_SamJournal],[Artcl_TUsent2CUS],[Proof_Pages],[Artcl_TableLandscape],[Artcl_TablePotrait],[Artcl_OnLineIssue],[Artcl_CupCombined],[Artcl_CupCountry],[Artcl_EmailForCupCombined],[Artcl_NotePadQuerry],[Artcl_TypeSetQuerry],[Artcl_TICategory],[Artcl_IssueYN],[Artcl_Runon],[Artcl_Target],[Artcl_Priority],[Artcl_OupBlock],[Artcl_CETypeSet],[Artcl_TFMD],[Artcl_OupInst],[Artcl_ExpChangeLogNm],[Artcl_HardCopyOrNot],[CSHL_SubCode],[CSHL_MailSubject],[Cshl_EditorMail],[Artcl_RSCategory],[Artcl_RSColorPages],[Artcl_ActualSeq],[Artcl_DisciplineCode],[Artcl_CePages],[Artcl_ShortTitle],[Artcl_IssueSeq],[Artcl_EsmFtitle],[Artcl_EsmFCaption],[Artcl_IssueDesc],[Tetradate],[Artcl_SecondProof],[Artcl_ULType],[Artcl_FigureFileNames],[Artcl_CEName],[Artcl_CEMailID],[Artcl_Oup_MatRefNo],[artcl_invno],[artcl_invDate],[Issue_Invno],[Issue_InvDate],[Issue_Pages],[artcl_Pgs],[Artcl_IntrlInvNo],[Artcl_IntrlInvdate],[Inv_Blankpages],[Inv_ProofPages],[Inv_UploadDate],[Inv_Remark],[Artcl_PageIssueSheet_Check],[Artcl_PreVolume],[Artcl_PreIssue],[sent2Mail],[Artcl_CustomEmailCc],[artcl_TetraDate],[artcl_OptEmail],[Artcl_OUPSection],[Artcl_EprintEmail],[Artcl_onholdmsg],[Artcl_onholdmsgDt],[artcl_CEDuedate],[Artcl_PII],[HoldReleaseDate],[artcl_PrevCEDuedate],[Actual_ReceivedDt],[Actual_ScheduledDt],[artcl_PEDuedate],[Artcl_FVArticle],[artcl_forworkflow],[artcl_TransID],[artcl_TransStatus],[artcl_TransTime],[Artcl_OUPPreul],[Artcl_PEReceivedDt],[Artcl_PEScheduledDt],[Artcl_PEExpFromTIDt],[Artcl_PEUploadedDt],[Artcl_PEStatus],[Artcl_StageType],[artcl_wordcount],[artcl_coarticleid],[artcl_SamJournal],[artcl_TransIDGfx],[Artcl_ComplexType],[Artcl_CupCams],[ProofFraction_Pages],[Artcl_supplemental],[Artcl_VernacularTitle],[Artcl_CustReceiveddt],[Artcl_CustReviseddt],[Artcl_CustAccepteddt],[Artcl_Abstract],[Artcl_ColorFigure],[Artcl_ColorFigureCharge],[Artcl_ConflictofInterest],[Artcl_CopyrightCode],[Artcl_PapDate],[Artcl_PrintColourFigures],[Artcl_OnlineColourFigures],[ProofReference_Pages],[Artcl_EmailCc],[Artcl_EmailBCc],[Artcl_Inv_Relabel],[Artcl_Inv_Redraw],[Artcl_Inv_ScanImport],[Artcl_Rev_Inv_Relabel],[Artcl_Rev_Inv_Redraw],[Artcl_Rev_Inv_ScanImport],[Artcl_VolIssNoTrack],[Artcl_ResupplyType],[Artcl_MCQ],[Artcl_FigComment],[Artcl_Query],[Artcl_QueryPath],[Artcl_Orcid],[Artcl_FigQueryDt],[Artcl_ProofDispatch],[Artcl_UncorrectedProof],[Artcl_UncorrectedDate],[Artcl_ColorFig],[Artcl_ColorPages],[Artcl_AdvanceAccessDate],[Artcl_smartRemarks],[Artcl_ColourPrint],[Artcl_ColourWaived],[Artcl_ColourOnline],[Artcl_Advertisement_Page],[OUP_SPMComments],[Artcl_CEReceiveDate],[artcl_NoOfChars],[artcl_NoOfRefWords],[artcl_NoOfRefChars],[artcl_noofwords],[Artcl_EmbargoDt],[Artcl_SupplementaryData],[Artcl_Feedback],[Artcl_LicenceAccepted],[artcl_SourceBy],[Artcl_PAPSkip_Remark],[Artcl_Mailstatus],[Artcl_CODeleteRemarks],[Artcl_InvName],[Artcl_DelayReason],[Artcl_NoOfQueries],[Artcl_Noofdeletion],[Artcl_NoOfAdditions],[CO_MailStatus],[Artcl_Category],[Artcl_Classification],[Artcl_TnFAUCorr],[Artcl_Batch],[artcl_Reflowarticleid],[Artcl_NoOfPeQueries],[Artcl_AUCorr_RecDT],[Artcl_EDCorr_RecDT],[Artcl_FVPublDT],[Artcl_CEWordCount],[Artcl_CEWordRefCount],[Artcl_RFTAUInserted],[Artcl_RFTAUDeleted],[Artcl_RFTAUModified],[ArticleDeletion],[Artcl_ProofCr],[Artcl_EGProofCr],[Artcl_CC3Score],[Artcl_BookNo],[Artcl_TandFBooking],[JTS_Artcl_TandFBooking],[Artcl_ED_ProofCr],[Artcl_SPM_ProofCr],[Artcl_PE_ProofCr],[Artcl_AU_ProofCr],[Artcl_CUP_Remarks],[Manually_Closed],[artcl_transidamo],[Artcl_TnFPDFDT],[Artcl_NIH],[Artcl_TableKeying],[Artcl_EquationKeying],[Artcl_OtherKeying],[Artcl_RefKeying],[Artcl_CasperLink],[Inv_Reason],[Inv_Reasondate]  FROM [Article] where Artcl_ArticleId='" + Aid + "'SELECT @ArtId=SCOPE_IDENTITY() Insert into TrnsJournal(JrnlTrns_ArticleID,JrnlTrns_Emp,JrnlTrns_Dept,JrnlTrns_Intime,JrnlTrns_Outtime,JrnlTrns_ProcessCd,JrnlTrns_Status,JrnlTrns_NextProcessID,JrnlTrns_Jtype,JrnlTrns_Remarks,LastModifiedDate,UsrID,Jrnltrns_processtype) values(@ArtId,'1','Admin',getdate(),getdate(),'14','Completed','25','Article','Auto Entry',getdate(),1,'Pending')";
                        string Query = @"declare @ArtId as integer  insert into article ([Artcl_ArticleId],[Artcl_Status],[Artcl_DOI],[Artcl_JrnlId],[Artcl_AuthorName],[Artcl_AuthorEmail],[Artcl_DueDtCats],[Artcl_ReceivedDt],[Artcl_ExpFromTIDt],[Artcl_ScheduledDt],[Artcl_Volume],[Artcl_Issue],[Artcl_TextElectronic],[Artcl_TextFolios],[Artcl_TextTables],[Artcl_ArtLineArt],[Artcl_ArtHalftones],[Artcl_ArtColour],[Artcl_ArtSchemes],[Artcl_ArtElectronic],[Artcl_ArtToFollow],[Artcl_ArtReceivedDt],[Artcl_PDFToAuthor],[Artcl_PDFToProdEditor],[Artcl_PDFDespatched],[Artcl_Notes],[Artcl_Comments],[Artcl_WebDelivery],[Artcl_UploadedDt],[Artcl_Remarks],[Artcl_CopyEditing],[Artcl_ArtWork],[Artcl_AuthorPhotos],[Artcl_InlineFigures],[Artcl_StatusWeb],[Artcl_StatusGFX],[Artcl_CompletedDtGFX],[Artcl_ReceivedWeb],[Artcl_ExpTIWeb],[Artcl_ScheduledWeb],[Artcl_RemarkWeb],[Artcl_TypeWeb],[LastModifiedDate],[UsrID],[Artcl_ArtType],[Artcl_Type],[loaded2transaction],[loaded2transactionWeb],[loaded2transactionGFX],[Artcl_Platform],[Artcl_ReceivedSGML],[Artcl_ExpTISGML],[Artcl_ScheduledSGML],[Artcl_RemarkSGML],[Artcl_StatusSGML],[Artcl_UploadedSGML],[Artcl_Seq],[Artcl_Supplement],[Artcl_TotalAuthors],[Artcl_ReceivedTandF],[Artcl_ReceivedTandFWeb],[Artcl_ProofDue],[Sent2TU],[Artcl_PageType],[Artcl_Pages],[Artcl_FirstPage],[Artcl_LastPage],[Artcl_OUPCopyright],[Artcl_OUPOpenAccess],[Artcl_ManuscriptSuppliedEdited],[Artcl_ManuscriptSuppliedBy],[Artcl_SpecInst],[Artcl_OnlinePubDate],[Artcl_IssueCoverMonth],[Artcl_FolderCreated],[Complexity],[TetraBeYN],[TandF_SamJournal],[Artcl_TUsent2CUS],[Proof_Pages],[Artcl_TableLandscape],[Artcl_TablePotrait],[Artcl_OnLineIssue],[Artcl_CupCombined],[Artcl_CupCountry],[Artcl_EmailForCupCombined],[Artcl_NotePadQuerry],[Artcl_TypeSetQuerry],[Artcl_TICategory],[Artcl_IssueYN],[Artcl_Runon],[Artcl_Target],[Artcl_Priority],[Artcl_OupBlock],[Artcl_CETypeSet],[Artcl_TFMD],[Artcl_OupInst],[Artcl_ExpChangeLogNm],[Artcl_HardCopyOrNot],[CSHL_SubCode],[CSHL_MailSubject],[Cshl_EditorMail],[Artcl_RSCategory],[Artcl_RSColorPages],[Artcl_ActualSeq],[Artcl_DisciplineCode],[Artcl_CePages],[Artcl_ShortTitle],[Artcl_IssueSeq],[Artcl_EsmFtitle],[Artcl_EsmFCaption],[Artcl_IssueDesc],[Tetradate],[Artcl_SecondProof],[Artcl_ULType],[Artcl_FigureFileNames],[Artcl_CEName],[Artcl_CEMailID],[Artcl_Oup_MatRefNo],[artcl_invno],[artcl_invDate],[Issue_Invno],[Issue_InvDate],[Issue_Pages],[artcl_Pgs],[Artcl_IntrlInvNo],[Artcl_IntrlInvdate],[Inv_Blankpages],[Inv_ProofPages],[Inv_UploadDate],[Inv_Remark],[Artcl_PageIssueSheet_Check],[Artcl_PreVolume],[Artcl_PreIssue],[sent2Mail],[Artcl_CustomEmailCc],[artcl_TetraDate],[artcl_OptEmail],[Artcl_OUPSection],[Artcl_EprintEmail],[Artcl_onholdmsg],[Artcl_onholdmsgDt],[artcl_CEDuedate],[Artcl_PII],[HoldReleaseDate],[artcl_PrevCEDuedate],[Actual_ReceivedDt],[Actual_ScheduledDt],[artcl_PEDuedate],[Artcl_FVArticle],[artcl_forworkflow],[artcl_TransID],[artcl_TransStatus],[artcl_TransTime],[Artcl_OUPPreul],[Artcl_PEReceivedDt],[Artcl_PEScheduledDt],[Artcl_PEExpFromTIDt],[Artcl_PEUploadedDt],[Artcl_PEStatus],[Artcl_StageType],[artcl_wordcount],[artcl_coarticleid],[artcl_SamJournal],[artcl_TransIDGfx],[Artcl_ComplexType],[Artcl_CupCams],[ProofFraction_Pages],[Artcl_supplemental],[Artcl_VernacularTitle],[Artcl_CustReceiveddt],[Artcl_CustReviseddt],[Artcl_CustAccepteddt],[Artcl_Abstract],[Artcl_ColorFigure],[Artcl_ColorFigureCharge],[Artcl_ConflictofInterest],[Artcl_CopyrightCode],[Artcl_PapDate],[Artcl_PrintColourFigures],[Artcl_OnlineColourFigures],[ProofReference_Pages],[Artcl_EmailCc],[Artcl_EmailBCc],[Artcl_Inv_Relabel],[Artcl_Inv_Redraw],[Artcl_Inv_ScanImport],[Artcl_Rev_Inv_Relabel],[Artcl_Rev_Inv_Redraw],[Artcl_Rev_Inv_ScanImport],[Artcl_VolIssNoTrack],[Artcl_ResupplyType],[Artcl_MCQ],[Artcl_FigComment],[Artcl_Query],[Artcl_QueryPath],[Artcl_Orcid],[Artcl_FigQueryDt],[Artcl_ProofDispatch],[Artcl_UncorrectedProof],[Artcl_UncorrectedDate],[Artcl_ColorFig],[Artcl_ColorPages],[Artcl_AdvanceAccessDate],[Artcl_smartRemarks],[Artcl_ColourPrint],[Artcl_ColourWaived],[Artcl_ColourOnline],[Artcl_Advertisement_Page],[OUP_SPMComments],[Artcl_CEReceiveDate],[artcl_NoOfChars],[artcl_NoOfRefWords],[artcl_NoOfRefChars],[artcl_noofwords],[Artcl_EmbargoDt],[Artcl_SupplementaryData],[Artcl_Feedback],[Artcl_LicenceAccepted],[artcl_SourceBy],[Artcl_PAPSkip_Remark],[Artcl_Mailstatus],[Artcl_CODeleteRemarks],[Artcl_InvName],[Artcl_DelayReason],[Artcl_NoOfQueries],[Artcl_Noofdeletion],[Artcl_NoOfAdditions],[CO_MailStatus],[Artcl_Category],[Artcl_Classification],[Artcl_TnFAUCorr],[Artcl_Batch],[artcl_Reflowarticleid],[Artcl_NoOfPeQueries],[Artcl_AUCorr_RecDT],[Artcl_EDCorr_RecDT],[Artcl_FVPublDT],[Artcl_CEWordCount],[Artcl_CEWordRefCount],[Artcl_RFTAUInserted],[Artcl_RFTAUDeleted],[Artcl_RFTAUModified],[ArticleDeletion],[Artcl_ProofCr],[Artcl_EGProofCr],[Artcl_CC3Score],[Artcl_BookNo],[Artcl_TandFBooking],[JTS_Artcl_TandFBooking],[Artcl_ED_ProofCr],[Artcl_SPM_ProofCr],[Artcl_PE_ProofCr],[Artcl_AU_ProofCr],[Artcl_CUP_Remarks],[Manually_Closed],[artcl_transidamo],[Artcl_TnFPDFDT],[Artcl_NIH],[Artcl_TableKeying],[Artcl_EquationKeying],[Artcl_OtherKeying],[Artcl_RefKeying],[Artcl_CasperLink],[Inv_Reason],[Inv_Reasondate])SELECT [Artcl_ArticleId] + '_OpenAccess',[Artcl_Status]='UL',[Artcl_DOI],[Artcl_JrnlId],[Artcl_AuthorName],[Artcl_AuthorEmail],'" + DD + "',getdate(),'" + DD + "','" + DD + "',[Artcl_Volume],[Artcl_Issue],[Artcl_TextElectronic],[Artcl_TextFolios],[Artcl_TextTables],[Artcl_ArtLineArt],[Artcl_ArtHalftones],[Artcl_ArtColour],[Artcl_ArtSchemes],[Artcl_ArtElectronic],[Artcl_ArtToFollow],[Artcl_ArtReceivedDt],[Artcl_PDFToAuthor],[Artcl_PDFToProdEditor],[Artcl_PDFDespatched],[Artcl_Notes],[Artcl_Comments],[Artcl_WebDelivery],[Artcl_UploadedDt]=getdate(),[Artcl_Remarks],[Artcl_CopyEditing],[Artcl_ArtWork],[Artcl_AuthorPhotos],[Artcl_InlineFigures],[Artcl_StatusWeb],[Artcl_StatusGFX],[Artcl_CompletedDtGFX],[Artcl_ReceivedWeb],[Artcl_ExpTIWeb],[Artcl_ScheduledWeb],[Artcl_RemarkWeb],[Artcl_TypeWeb],[LastModifiedDate],[UsrID],'2107',[Artcl_Type],[loaded2transaction],[loaded2transactionWeb],[loaded2transactionGFX],[Artcl_Platform],[Artcl_ReceivedSGML],[Artcl_ExpTISGML],[Artcl_ScheduledSGML],[Artcl_RemarkSGML],[Artcl_StatusSGML],[Artcl_UploadedSGML],[Artcl_Seq],[Artcl_Supplement],[Artcl_TotalAuthors],[Artcl_ReceivedTandF],[Artcl_ReceivedTandFWeb],[Artcl_ProofDue],[Sent2TU],[Artcl_PageType],[Artcl_Pages],[Artcl_FirstPage],[Artcl_LastPage],[Artcl_OUPCopyright],[Artcl_OUPOpenAccess],[Artcl_ManuscriptSuppliedEdited],[Artcl_ManuscriptSuppliedBy],[Artcl_SpecInst],[Artcl_OnlinePubDate],[Artcl_IssueCoverMonth],0,[Complexity],[TetraBeYN],[TandF_SamJournal],[Artcl_TUsent2CUS],[Proof_Pages],[Artcl_TableLandscape],[Artcl_TablePotrait],[Artcl_OnLineIssue],[Artcl_CupCombined],[Artcl_CupCountry],[Artcl_EmailForCupCombined],[Artcl_NotePadQuerry],[Artcl_TypeSetQuerry],[Artcl_TICategory],[Artcl_IssueYN],[Artcl_Runon],[Artcl_Target],[Artcl_Priority],[Artcl_OupBlock],[Artcl_CETypeSet],[Artcl_TFMD],[Artcl_OupInst],[Artcl_ExpChangeLogNm],[Artcl_HardCopyOrNot],[CSHL_SubCode],[CSHL_MailSubject],[Cshl_EditorMail],[Artcl_RSCategory],[Artcl_RSColorPages],[Artcl_ActualSeq],[Artcl_DisciplineCode],[Artcl_CePages],[Artcl_ShortTitle],[Artcl_IssueSeq],[Artcl_EsmFtitle],[Artcl_EsmFCaption],[Artcl_IssueDesc],[Tetradate],[Artcl_SecondProof],[Artcl_ULType],[Artcl_FigureFileNames],[Artcl_CEName],[Artcl_CEMailID],[Artcl_Oup_MatRefNo],[artcl_invno],[artcl_invDate],[Issue_Invno],[Issue_InvDate],[Issue_Pages],[artcl_Pgs],[Artcl_IntrlInvNo],[Artcl_IntrlInvdate],[Inv_Blankpages],[Inv_ProofPages],[Inv_UploadDate],[Inv_Remark],[Artcl_PageIssueSheet_Check],[Artcl_PreVolume],[Artcl_PreIssue],[sent2Mail],[Artcl_CustomEmailCc],[artcl_TetraDate],[artcl_OptEmail],[Artcl_OUPSection],[Artcl_EprintEmail],[Artcl_onholdmsg],[Artcl_onholdmsgDt],[artcl_CEDuedate],[Artcl_PII],[HoldReleaseDate],[artcl_PrevCEDuedate],[Actual_ReceivedDt],[Actual_ScheduledDt],[artcl_PEDuedate],[Artcl_FVArticle],[artcl_forworkflow],[artcl_TransID],[artcl_TransStatus],[artcl_TransTime],[Artcl_OUPPreul],[Artcl_PEReceivedDt],[Artcl_PEScheduledDt],[Artcl_PEExpFromTIDt],[Artcl_PEUploadedDt],[Artcl_PEStatus],[Artcl_StageType],[artcl_wordcount],[artcl_coarticleid],[artcl_SamJournal],[artcl_TransIDGfx],[Artcl_ComplexType],[Artcl_CupCams],[ProofFraction_Pages],[Artcl_supplemental],[Artcl_VernacularTitle],[Artcl_CustReceiveddt],[Artcl_CustReviseddt],[Artcl_CustAccepteddt],[Artcl_Abstract],[Artcl_ColorFigure],[Artcl_ColorFigureCharge],[Artcl_ConflictofInterest],[Artcl_CopyrightCode],[Artcl_PapDate],[Artcl_PrintColourFigures],[Artcl_OnlineColourFigures],[ProofReference_Pages],[Artcl_EmailCc],[Artcl_EmailBCc],[Artcl_Inv_Relabel],[Artcl_Inv_Redraw],[Artcl_Inv_ScanImport],[Artcl_Rev_Inv_Relabel],[Artcl_Rev_Inv_Redraw],[Artcl_Rev_Inv_ScanImport],[Artcl_VolIssNoTrack],[Artcl_ResupplyType],[Artcl_MCQ],[Artcl_FigComment],[Artcl_Query],[Artcl_QueryPath],[Artcl_Orcid],[Artcl_FigQueryDt],[Artcl_ProofDispatch],[Artcl_UncorrectedProof],[Artcl_UncorrectedDate],[Artcl_ColorFig],[Artcl_ColorPages],[Artcl_AdvanceAccessDate],[Artcl_smartRemarks],[Artcl_ColourPrint],[Artcl_ColourWaived],[Artcl_ColourOnline],[Artcl_Advertisement_Page],[OUP_SPMComments],[Artcl_CEReceiveDate],[artcl_NoOfChars],[artcl_NoOfRefWords],[artcl_NoOfRefChars],[artcl_noofwords],[Artcl_EmbargoDt],[Artcl_SupplementaryData],[Artcl_Feedback],[Artcl_LicenceAccepted],[artcl_SourceBy],[Artcl_PAPSkip_Remark],[Artcl_Mailstatus],[Artcl_CODeleteRemarks],[Artcl_InvName],[Artcl_DelayReason],[Artcl_NoOfQueries],[Artcl_Noofdeletion],[Artcl_NoOfAdditions],[CO_MailStatus],[Artcl_Category],[Artcl_Classification],[Artcl_TnFAUCorr],[Artcl_Batch],[artcl_Reflowarticleid],[Artcl_NoOfPeQueries],[Artcl_AUCorr_RecDT],[Artcl_EDCorr_RecDT],[Artcl_FVPublDT],[Artcl_CEWordCount],[Artcl_CEWordRefCount],[Artcl_RFTAUInserted],[Artcl_RFTAUDeleted],[Artcl_RFTAUModified],[ArticleDeletion],[Artcl_ProofCr],[Artcl_EGProofCr],[Artcl_CC3Score],[Artcl_BookNo],[Artcl_TandFBooking],[JTS_Artcl_TandFBooking],[Artcl_ED_ProofCr],[Artcl_SPM_ProofCr],[Artcl_PE_ProofCr],[Artcl_AU_ProofCr],[Artcl_CUP_Remarks],[Manually_Closed],[artcl_transidamo],[Artcl_TnFPDFDT],[Artcl_NIH],[Artcl_TableKeying],[Artcl_EquationKeying],[Artcl_OtherKeying],[Artcl_RefKeying],[Artcl_CasperLink],[Inv_Reason],[Inv_Reasondate]  FROM [Article] where Artcl_ArticleId='" + Aid + "'SELECT @ArtId=SCOPE_IDENTITY() Insert into TrnsJournal(JrnlTrns_ArticleID,JrnlTrns_Emp,JrnlTrns_Dept,JrnlTrns_Intime,JrnlTrns_Outtime,JrnlTrns_ProcessCd,JrnlTrns_Status,JrnlTrns_NextProcessID,JrnlTrns_Jtype,JrnlTrns_Remarks,LastModifiedDate,UsrID,Jrnltrns_processtype) values(@ArtId,'1','Admin',getdate(),getdate(),'14','Completed','25','Article','Auto Entry',getdate(),1,'Pending')";
                        Db.SqlCmd = new System.Data.SqlClient.SqlCommand(Query, Db.GetConnection());
                        Cs.SaveToReport("Status: " + Query + " " + Aid);
                        Db.OpenConnection();
                        Db.SqlReader = Db.SqlCmd.ExecuteReader();
                        Db.SqlReader.Close();

                        Cs.SaveToReport("Status: Author Correction update JR_Main Table file: " + Path.GetFileName(Z));
                        string Ar_JrnlId = Cs.ReturnDetail("Artcl_JrnlId", "Article", Db, "Artcl_ArticleId='" + Aid + "'");
                        string Jrnl_Acronym = Cs.ReturnDetail("Jrnl_Acronym", "Journal", Db, "Jrnl_Id='" + Ar_JrnlId + "'"); ;
                        string Journalid = Cs.ReturnDetail("Jrnl_Id", "Journal", Db, "Jrnl_Acronym='" + Jrnl_Acronym + "' AND Jrnl_PublID='8'");
                        string JRM_Id = Cs.ReturnDetail("max(JRM_Id) as id", "JR_Main", Db, "");

                        string Query1 = "INSERT INTO JR_Main(JRM_Id,JRM_JournalID,JRM_ArticleID,LastModifiedDate,UsrID,Insert_Date) Values('" + (Convert.ToInt64(JRM_Id) + 1) + @"','" + Journalid + @"','" + AidOpenaccess + "',getdate(),'1',getdate())";
                        if (Cs.ReturnDetail("JRM_Id", "JR_Main", Db, "JRM_ArticleID='" + AidOpenaccess + "' AND JRM_JournalID='" + Journalid + "'") == "")
                        {
                            Cs.SaveToReport("Status: " + Query1 + " " + Path.GetFileName(Z));
                            Db.SqlCmd = new System.Data.SqlClient.SqlCommand(Query1, Db.GetConnection());
                            Db.OpenConnection();
                            Db.SqlReader = Db.SqlCmd.ExecuteReader();
                            Db.SqlReader.Close();
                        }

                        string sDD = Cs.CalculateDueDate("", Db, DateTime.Today, 2).ToString("MM/dd/yyyy hh:mm:ss").Replace('-', '/');
                        string eDD = Cs.CalculateDueDate("", Db, DateTime.Today, 1).ToString("MM/dd/yyyy hh:mm:ss").Replace('-', '/');
                        Cs.SaveToReport("Status: Author Correction " + AidOpenaccess + " update JR_Stage_Tran Table file: " + Path.GetFileName(Z));

                        string JRS_Id = Cs.ReturnDetail("max(JRST_ID) as id", "JR_Stage_Tran", Db, "");
                        Query = "Insert into JR_Stage_Tran(JRST_ID,JRST_JRM_ID, JRST_JRS_ID, JRST_DueDtCats, JRST_ReceivedDt, JRST_ScheduledDt,JRST_ExpectedDt,JRST_Status, LastModifiedDate,UsrID,JRST_SmartRemarks,Jrst_CupCams,JRST_MoveFiles) Values('" + (Convert.ToInt64(JRS_Id) + 1) + @"','" + (Convert.ToInt64(JRM_Id) + 1) + @"','35','" + sDD + "',getdate(),'" + eDD + "','" + eDD + "','25',getdate(),'1','','" + Path.GetFileNameWithoutExtension(Z) + "','0')";
                        Cs.SaveToReport("Status: " + Query + " " + Path.GetFileName(Z));
                        Db.SqlCmd = new System.Data.SqlClient.SqlCommand(Query, Db.GetConnection());
                        Db.OpenConnection();
                        Db.SqlReader = Db.SqlCmd.ExecuteReader();
                        Db.SqlReader.Close();


                        //JR_Articles 
                        string JRA_ID = Cs.ReturnDetail("max(JRA_ID) as id", "JR_Articles", Db, "");
                        Query = "Insert into JR_Articles(JRA_ID,JRA_JRST_ID,JRA_ArticleID ,JRA_Status,JRA_StageID,LastModifiedDate,UsrID,JRST_MoveFiles) Values('" + (Convert.ToInt64(JRA_ID) + 1) + @"','" + (Convert.ToInt64(JRS_Id) + 1) + @"','" + AidOpenaccess + @"','25','35',getdate(),'1','0')";
                        Cs.SaveToReport("Status: " + Query + " " + Path.GetFileName(Z));
                        Db.SqlCmd = new System.Data.SqlClient.SqlCommand(Query, Db.GetConnection());
                        Db.OpenConnection();
                        Db.SqlReader = Db.SqlCmd.ExecuteReader();
                        Db.SqlReader.Close();

                        //TrnsJournalRev 
                        Query = "INSERT into TrnsJournalRev(JrnlTrns_ArticleId,JrnlTrns_Emp ,JrnlTrns_Dept,JrnlTrns_InTime ,JrnlTrns_OutTime,JrnlTrns_ProcessCd ,JrnlTrns_Status,JrnlTrns_Remarks,JrnlTrns_NextProcessID ,LastModifiedDate ,UsrID ,JrnlTrns_JType,Jrnltrns_processtype) Values('" + (Convert.ToInt64(JRA_ID) + 1) + @"','1','Administration',getdate(),getdate(),'14','Completed','Auto Entry','25',getdate(),'1','AU Correction','Pending')";
                        Cs.SaveToReport("Status: " + Query + " " + Path.GetFileName(Z));
                        Db.SqlCmd = new System.Data.SqlClient.SqlCommand(Query, Db.GetConnection());
                        Db.OpenConnection();
                        Db.SqlReader = Db.SqlCmd.ExecuteReader();
                        Db.SqlReader.Close();
                    }
                    else
                    {
                        Cs.SaveToReport("Article not found or open access already booked: " + Aid);
                    }
                    File.Delete(Z);
                }
                foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\CUP\JAS_Bookreview_Booking", "*.xls*"))
                {
                    Statusupdate("Processing : " + Path.GetFileName(Z));
                    try
                    {
                        System.Collections.ArrayList ArticleID = new System.Collections.ArrayList();
                        Cs.SaveToReport("Status: Collecting data from excel file: " + Z);
                        Xl.Workbook xlWorkBook;
                        Xl.Worksheet xlWorkSheet;
                        Xl.Application xlapp;
                        xlapp = new Xl.Application();
                        xlapp.Visible = false;
                        xlWorkBook = xlapp.Workbooks.Open(Z);
                        xlWorkSheet = (Xl.Worksheet)xlWorkBook.Sheets[1];
                        int lastRow = xlWorkSheet.Cells.SpecialCells(Xl.XlCellType.xlCellTypeLastCell).Row;
                        System.Array MyValues = (System.Array)xlWorkSheet.get_Range("A1", "C" + lastRow.ToString()).Cells.Value;
                        int ros = MyValues.GetLength(0);
                        int cos = MyValues.GetLength(1);
                        xlapp.Quit();
                        xlapp = null;
                        GC.Collect();
                        GC.WaitForPendingFinalizers();
                        foreach (Process P in Process.GetProcessesByName("EXCEL"))
                        {
                            try
                            {
                                P.Kill();
                            }
                            catch (Exception e2) { }
                        }
                        for (int i = 2; i <= ros; i++)
                        {
                            string val = "";
                            try
                            {
                                val = MyValues.GetValue(i, 1).ToString();
                            }
                            catch (Exception e1)
                            {
                                val = "";
                                break;
                            }
                            string artid = MyValues.GetValue(i, 1).ToString().Trim();
                            if (!ArticleID.Contains(artid))
                            {
                                string cont = "", email = "";
                                try
                                {
                                    cont = MyValues.GetValue(i, 2).ToString().Trim();
                                }
                                catch (Exception e1)
                                {
                                    cont = "";
                                }
                                try
                                {
                                    email = MyValues.GetValue(i, 3).ToString().Trim();
                                }
                                catch (Exception e1)
                                {
                                    email = "";
                                }
                                if (cont != "" && email != "" && artid != "" && Cs.ReturnDetail("Artcl_ArticleId", "Article", Db, "Artcl_JrnlId in (select Jrnl_Id from Journal where Jrnl_PublID='8') and Artcl_ArticleId='" + artid + "' and isnull(Artcl_UploadedDt,'')=''") != "")
                                {
                                    string Query = @"UPDATE article SET Artcl_EmailForCupCombined='" + email.Replace("'", "''") + "',Artcl_CupCountry='" + cont + "' Where Artcl_JrnlId in (select Jrnl_Id from Journal where Jrnl_PublID='8') and Artcl_ArticleId='" + artid + "'";
                                    Db.SqlCmd = new System.Data.SqlClient.SqlCommand(Query, Db.GetConnection());
                                    Cs.SaveToReport("Status: " + Query + " " + artid);
                                    Db.OpenConnection();
                                    Db.SqlReader = Db.SqlCmd.ExecuteReader();
                                    Db.SqlReader.Close();
                                }
                            }
                        }
                        File.Copy(Z, @"\\techsetserver2\Download\CUP\JAS_Bookreview_Booking\Completed\" + DateTime.Now.ToString("ddMMyyyy_HHmmss_") + Path.GetFileName(Z), true);
                        File.Delete(Z);
                    }
                    catch (Exception ee) { Cs.SaveToReport("CUP JAS Book review:  " + ee.Message + @"\n" + ee.StackTrace); File.Delete(Z); File.Copy(Z, @"\\techsetserver2\Download\CUP\JAS_Bookreview_Booking\Error\" + DateTime.Now.ToString("ddMMyyyy_HHmmss_") + Path.GetFileName(Z), true); continue; }
                    SerializedClass.GetInfo();
                }

                if (SerializedClass.WatchLocation3 != "" && Directory.Exists(SerializedClass.WatchLocation3))
                {
                    SerializedClass.CurrentLocation1 = SerializedClass.CurrentLocation3;
                    Statusupdate("Searching Excel/XML files...");
                    Cs.SaveToReport("Status:Searching Excel/XML files...");
                    foreach (string Z in Directory.GetFiles(SerializedClass.WatchLocation3).Where(s => Regex.IsMatch(Path.GetExtension(s).ToLower(), @"\.(xls|xml)")))
                    {
                        Statusupdate("Processing file: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        Cs.Book_CUPRevises(Z, SerializedClass.CurrentLocation1);
                    }
                    Statusupdate("Searching zip files...");
                    Cs.SaveToReport("Status:Searching zip files...");
                    foreach (string Z in Directory.GetFiles(SerializedClass.WatchLocation3).Where(s => Regex.IsMatch(Path.GetExtension(s).ToLower(), @"\.(zip)")))
                    {
                        Statusupdate("Processing file: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        if (Cs.ExtractZip(Z) == true)
                        {
                            if (Directory.Exists(Z.ToLower().Replace(".zip", "")))
                            {
                                bool fileprocessed = false;
                                foreach (string f in Directory.GetFiles(Z.ToLower().Replace(".zip", ""), "*.*", SearchOption.AllDirectories).Where(s => Regex.IsMatch(Path.GetExtension(s).ToLower(), @"\.(xlsx)")))
                                {
                                    Cs.Book_CUPRevises(f, SerializedClass.CurrentLocation1, Z);
                                    fileprocessed = true;
                                    break;
                                }

                                if (!fileprocessed)
                                {
                                    foreach (string f in Directory.GetFiles(Z.ToLower().Replace(".zip", ""), "*.*", SearchOption.AllDirectories).Where(s => Regex.IsMatch(Path.GetExtension(s).ToLower(), @"\.(xml)")))
                                    {
                                        if (Regex.IsMatch(Path.GetFileNameWithoutExtension(f).ToLower(), @"(_)?make(\-)?up(_)?"))
                                        {
                                            Cs.Book_CUPRevises(f, SerializedClass.CurrentLocation1, Z);
                                            fileprocessed = true;
                                            break;
                                        }
                                    }
                                }


                                //if (!fileprocessed)
                                //{
                                //    foreach (string f in Directory.GetFiles(Z.ToLower().Replace(".zip", ""), "*.*", SearchOption.AllDirectories).Where(s => Regex.IsMatch(Path.GetExtension(s).ToLower(), @"\.(xml)")))
                                //    {
                                //        if (Regex.IsMatch(Path.GetFileNameWithoutExtension(f).ToLower(), "(_)?export(_)?"))
                                //        {
                                //            Cs.Book_CUPRevises(f, SerializedClass.CurrentLocation1, Z);
                                //            fileprocessed = true;
                                //            break;
                                //        }
                                //    }
                                //}

                                if (!fileprocessed)
                                {
                                    Cs.cuppmjrnl = false;
                                    Cs.cupjrnl = "";
                                    if (Cs.ReturnDetail("isnull(Jrnl_User,'') as id", "journal", Db, "Jrnl_PublID='8' and Jrnl_Acronym='" + Path.GetFileNameWithoutExtension(Z).Split('_')[0] + "'") != "")
                                    {
                                        Cs.cuppmjrnl = true; Cs.cupjrnl = Path.GetFileNameWithoutExtension(Z).Split('_')[0];
                                    }
                                    Cs.SendMail(Z, "Dear Team,<Br/><Br/>Error while booking file: " + Path.GetFileName(Z) + "<Br/>Unable to find issue makeup excel or xml", "CUP", true, "Revises 1", Z);
                                    Cs.SaveToReport("Error while booking file: >Unable to find issue makeup excel or xml " + Path.GetFileName(Z) + "\n");
                                    Cs.Clear();
                                }
                            }
                        }
                    }
                    SerializedClass.GetInfo();
                }
                if (SerializedClass.WatchLocation4 != "" && Directory.Exists(SerializedClass.WatchLocation4))
                {
                    SerializedClass.CurrentLocation1 = SerializedClass.CurrentLocation4;
                    Cs.SaveToReport("Status:Searching Excel files...");
                    foreach (string Z in Directory.GetFiles(SerializedClass.WatchLocation4, "*.xls*"))
                    {
                        Statusupdate("Processing Excel: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing Excel file: " + Path.GetFileName(Z));
                        Cs.Book_ERS(Z, SerializedClass.CurrentLocation1);
                    }
                    SerializedClass.GetInfo();
                }
                if (SerializedClass.WatchLocation5 != "" && Directory.Exists(SerializedClass.WatchLocation5))
                {
                    SerializedClass.CurrentLocation1 = SerializedClass.CurrentLocation5;
                    Statusupdate("Searching Excel files...");
                    Cs.SaveToReport("Status:Searching Excel files...");
                    foreach (string Z in Directory.GetFiles(SerializedClass.WatchLocation5).Where(s => Regex.IsMatch(Path.GetExtension(s).ToLower(), @"\.(xls)")))
                    {
                        Statusupdate("Processing file: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        Cs.Book_STA_AU_Survey(Z, SerializedClass.CurrentLocation1);
                    }
                    SerializedClass.GetInfo();
                }
                if (SerializedClass.WatchLocation6 != "" && Directory.Exists(SerializedClass.WatchLocation6))
                {
                    SerializedClass.CurrentLocation1 = SerializedClass.CurrentLocation6;
                    Statusupdate("Searching Excel files...");
                    Cs.SaveToReport("Status:Searching Excel files...");
                    foreach (string Z in Directory.GetFiles(SerializedClass.WatchLocation6).Where(s => Regex.IsMatch(Path.GetExtension(s).ToLower(), @"\.(xls)")))
                    {
                        Statusupdate("Processing file: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        Cs.Book_AIPJPS_Printer(Z, SerializedClass.CurrentLocation1);
                    }
                    if (Directory.Exists(@"\\techsetserver2\Download\AIP\CorrectionEG"))
                    {
                        foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\AIP\CorrectionEG", "*_snapshot.pdf"))
                        {
                            Statusupdate("Processing file: " + Path.GetFileName(Z));
                            Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                            Cs.AIPEGCorrection(SerializedClass.CurrentLocation1, Z);
                        }
                    }
                    SerializedClass.GetInfo();
                }
                foreach (string Z in Directory.GetFiles(@"\\techsetserver2\Download\AIP_Issue_Makeup\Cover_Booking", "*.txt"))
                {
                    if (Path.GetFileNameWithoutExtension(Z).Split('_').Length == 4)
                    {
                        Statusupdate("Processing Txt: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        string Aid = Path.GetFileNameWithoutExtension(Z).ToUpper();
                        string Jacro = Aid.Split('_')[1];
                        string Vol = Aid.Split('_')[2];
                        string iss = Aid.Split('_')[3];
                        string jid = Cs.ReturnDetail("Jrnl_Id", "Journal", Db, "Jrnl_PublID='99' and Jrnl_Acronym ='" + Jacro + "'");
                        string DD = Cs.CalculateDueDate("", Db, DateTime.Today, 3).ToString("MM/dd/yyyy hh:mm:ss").Replace('-', '/');
                        string sDD = Cs.CalculateDueDate("", Db, DateTime.Today, 2).ToString("MM/dd/yyyy hh:mm:ss").Replace('-', '/');
                        string eDD = Cs.CalculateDueDate("", Db, DateTime.Today, 1).ToString("MM/dd/yyyy hh:mm:ss").Replace('-', '/');
                        if (Aid != "" && !Cs.CheckWhetherFileBooked(Aid))
                        {
                            //string Artcl_Status = "PE_SRV";
                            //string sts = "171";
                            //if (Jacro == "CHA") { Artcl_Status = "PE"; sts = "75"; }
                            //if (Jacro == "LTP") { Artcl_Status = "DP"; sts = "20"; }
                            string Artcl_Status = "PR1";
                            string sts = "23";
                            string book = @"declare @ArtId as integer insert into Article(Artcl_JrnlId,Artcl_ArticleId,Artcl_Volume,Artcl_Issue,Artcl_Title,Artcl_TextFolios,Artcl_TextElectronic,Artcl_ArtLineArt,Artcl_ArtElectronic,Artcl_ArtReceivedDt,Artcl_ArtWork,Artcl_ReceivedDt,Artcl_ScheduledDt,artcl_SourceBy,Artcl_FolderCreated,Artcl_Status,Artcl_ArtType,Artcl_ExpFromTIDt,Artcl_DueDtCats,Artcl_PII) values('" + jid + @"','" + Aid + @"','" + Vol + @"','" + iss + @"','" + Aid + @"','1','1','','',getdate(),'',getdate(),'" + sDD + @"','Word','0','" + Artcl_Status + "','256','" + eDD + @"','" + DD + @"','JPS_Workflow')  SELECT @ArtId=SCOPE_IDENTITY() Insert into TrnsJournal(JrnlTrns_ArticleID,JrnlTrns_Emp,JrnlTrns_Dept,JrnlTrns_Intime,JrnlTrns_Outtime,JrnlTrns_ProcessCd,JrnlTrns_Status,JrnlTrns_NextProcessID,JrnlTrns_Jtype,JrnlTrns_Remarks,LastModifiedDate,UsrID,Jrnltrns_processtype) values(@ArtId,'1','Admin',getdate(),getdate(),'14','Completed','" + sts + "','Article','Auto Entry',getdate(),1,'Pending')";
                            Db.SqlCmd = new System.Data.SqlClient.SqlCommand(book, Db.GetConnection());
                            Cs.SaveToReport("Status: " + book + " " + Aid);
                            Db.OpenConnection();
                            Db.SqlReader = Db.SqlCmd.ExecuteReader();
                            Db.SqlReader.Close();
                            Cs.SaveToReport("Process completed. File: " + Path.GetFileName(Z));
                            Cs.SendMail(Aid, "Dear Team,<Br/><Br/>AutoBooking information updated successfully for file: " + Path.GetFileName(Z), "AIP", false, "First Proof Stage");
                        }
                        else if (Aid != "" && Cs.CheckWhetherFileBooked(Aid))
                        {
                            //Cs.SaveToReport("Article already booked: " + Aid);
                            //Cs.SendMail(Aid, "Dear Team,<Br/><Br/>Article already booked.", "AIP", true, "First Proof", Path.GetFileName(Z));
                            string Artcl_Status = "PR1";
                            string sts = "23";
                            string artid = Cs.ReturnDetail("Artcl_id", "Article", Db, "Artcl_ArticleId='" + Aid + "' and isnull(artcl_uploadeddt,'')<>''");
                            if (artid != "")
                            {
                                string book = @"update Article set artcl_uploadeddt=null,Artcl_ReceivedDt=getdate(),Artcl_ScheduledDt='" + sDD + @"',Artcl_Status='" + Artcl_Status + "',Artcl_ExpFromTIDt='" + eDD + @"',Artcl_DueDtCats='" + DD + @"' where artcl_id=" + artid + " Insert into TrnsJournal(JrnlTrns_ArticleID,JrnlTrns_Emp,JrnlTrns_Dept,JrnlTrns_Intime,JrnlTrns_Outtime,JrnlTrns_ProcessCd,JrnlTrns_Status,JrnlTrns_NextProcessID,JrnlTrns_Jtype,JrnlTrns_Remarks,LastModifiedDate,UsrID,Jrnltrns_processtype) values(" + artid + ",'1','Admin',getdate(),getdate(),'33','Completed','" + sts + "','Article','Auto Entry',getdate(),1,'Pending')";
                                Db.SqlCmd = new System.Data.SqlClient.SqlCommand(book, Db.GetConnection());
                                Cs.SaveToReport("Status: " + book + " " + Aid);
                                Db.OpenConnection();
                                Db.SqlReader = Db.SqlCmd.ExecuteReader();
                                Db.SqlReader.Close();
                                Cs.SaveToReport("Process completed. File: " + Path.GetFileName(Z));
                                Cs.SendMail(Aid, "Dear Team,<Br/><Br/>AutoBooking information updated successfully for file: " + Path.GetFileName(Z), "AIP", false, "Revises Stage");
                            }
                            else
                            {
                                Cs.SaveToReport("Cover not uploaded yet. File: " + Path.GetFileName(Z));
                                Cs.SendMail(Aid, "Dear Team,<Br/><Br/>Cover not uploaded yet File: " + Path.GetFileName(Z), "AIP", true, "Revises Stage");
                            }
                        }
                        File.Delete(Z);
                    }
                }

                if (SerializedClass.WatchLocation6 != "" && Directory.Exists(SerializedClass.WatchLocation6 + @"\Revises"))
                {
                    SerializedClass.CurrentLocation1 = SerializedClass.CurrentLocation6;
                    Statusupdate("Searching Excel files...");
                    Cs.SaveToReport("Status:Searching Excel files...");
                    foreach (string Z in Directory.GetFiles(SerializedClass.WatchLocation6 + @"\Revises").Where(s => Regex.IsMatch(Path.GetExtension(s).ToLower(), @"\.(xls)")))
                    {
                        Statusupdate("Processing file: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        Cs.Book_AIPJPS_Revises(Z, SerializedClass.CurrentLocation1);
                    }
                    SerializedClass.GetInfo();
                }
                //if (SerializedClass.WatchLocation7 != "" && Directory.Exists(SerializedClass.WatchLocation7))
                //{
                //    SerializedClass.CurrentLocation1 = SerializedClass.CurrentLocation7;
                //    Statusupdate("Searching Excel files...");
                //    Cs.SaveToReport("Status:Searching Excel files...");
                //    foreach (string Z in Directory.GetFiles(SerializedClass.WatchLocation7).Where(s => Regex.IsMatch(Path.GetExtension(s).ToLower(), @"\.(xls)")))
                //    {
                //        Statusupdate("Processing file: " + Path.GetFileName(Z));
                //        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                //        Cs.Issue_Publication_Data_FSPM(Z, SerializedClass.CurrentLocation1);
                //    }
                //    SerializedClass.GetInfo();
                //}
                if (SerializedClass.WatchLocation8 != "" && Directory.Exists(SerializedClass.WatchLocation8))
                {
                    SerializedClass.CurrentLocation1 = SerializedClass.CurrentLocation8;
                    Statusupdate("Searching Excel files...");
                    Cs.SaveToReport("Status:Searching Excel files...");
                    foreach (string Z in Directory.GetFiles(SerializedClass.WatchLocation8).Where(s => Regex.IsMatch(Path.GetExtension(s).ToLower(), @"\.(xls)")))
                    {
                        Statusupdate("Processing file: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        Cs.Book_Issue_GSA(Z, SerializedClass.CurrentLocation1);
                    }
                    SerializedClass.GetInfo();
                }
                if (SerializedClass.WatchLocation9 != "" && Directory.Exists(SerializedClass.WatchLocation9))
                {
                    SerializedClass.CurrentLocation1 = SerializedClass.CurrentLocation9;
                    Statusupdate("Searching Email files...");
                    Cs.SaveToReport("Status:Searching Email files...");
                    foreach (string Z in Directory.GetFiles(SerializedClass.WatchLocation9).Where(s => Regex.IsMatch(Path.GetExtension(s).ToLower(), @"\.(msg)")))
                    {
                        Statusupdate("Processing file: " + Path.GetFileName(Z));
                        Cs.SaveToReport("Status: Processing file: " + Path.GetFileName(Z));
                        Cs.BookGSL_Revises(Z, SerializedClass.CurrentLocation1);
                    }
                    SerializedClass.GetInfo();
                }
            }
            catch (Exception ReportGen1)
            {
                Cs.SaveToReport(ReportGen1.Message + "<br>" + ReportGen1.StackTrace);
            }
            Tm.Start();
        }



        private void StopBtn_Click(object sender, EventArgs e)
        {
            Application.DoEvents();
            DialogResult result = MessageBox.Show("Do you want to exit?", "Booking Tool", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes) Application.Exit();
            else
            {
                Startbtn.Enabled = true;
                StopBtn.Enabled = false;
            }
        }
        public void Statusupdate(string item)
        {
            SerializedClass.additemDelegate obj = new SerializedClass.additemDelegate(add);
            this.Invoke(obj, item);
        }
        private void add(string item)
        {
            this.Status.Items.Add(DateTime.Now.ToString() + "    " + item);
            Application.DoEvents();
        }

        private void ListLogCBBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string Logname = SerializedClass.ErrDate + @".htm";
            string val = ListLogCBBox.SelectedItem.ToString();
            switch (val)
            {
                case "Generate AIP Excel Report":
                    xl.CreateReport();
                    ListLogCBBox.SelectedItem = ListLogCBBox.GetItemText("View Today's Log");
                    Application.DoEvents();
                    break;
                case "APS Invoice Booking":
                    if (File.Exists(SerializedClass.CurrentLocation2 + @"\Logs\" + Logname)) System.Diagnostics.Process.Start(SerializedClass.CurrentLocation2 + @"\Logs\" + Logname);
                    else MessageBox.Show("Log not generated yet");
                    ListLogCBBox.SelectedItem = ListLogCBBox.GetItemText("View Today's Log");
                    Application.DoEvents();
                    break;
                case "COBISSUE_MAKEUP":
                    if (File.Exists(SerializedClass.CurrentLocation1 + @"\Logs\" + Logname)) System.Diagnostics.Process.Start(SerializedClass.CurrentLocation1 + @"\Logs\" + Logname);
                    else MessageBox.Show("Log not generated yet");
                    ListLogCBBox.SelectedItem = ListLogCBBox.GetItemText("View Today's Log");
                    Application.DoEvents();
                    break;
                case "CUPISSUE_MAKEUP":
                    if (File.Exists(SerializedClass.CurrentLocation3 + @"\Logs\" + Logname)) System.Diagnostics.Process.Start(SerializedClass.CurrentLocation3 + @"\Logs\" + Logname);
                    else MessageBox.Show("Log not generated yet");
                    ListLogCBBox.SelectedItem = ListLogCBBox.GetItemText("View Today's Log");
                    Application.DoEvents();
                    break;
                case "ERSISSUE_MAKEUP":
                    if (File.Exists(SerializedClass.CurrentLocation4 + @"\Logs\" + Logname)) System.Diagnostics.Process.Start(SerializedClass.CurrentLocation4 + @"\Logs\" + Logname);
                    else MessageBox.Show("Log not generated yet");
                    ListLogCBBox.SelectedItem = ListLogCBBox.GetItemText("View Today's Log");
                    Application.DoEvents();
                    break;
                case "TnF STA":
                    if (File.Exists(SerializedClass.CurrentLocation5 + @"\Logs\" + Logname)) System.Diagnostics.Process.Start(SerializedClass.CurrentLocation5 + @"\Logs\" + Logname);
                    else MessageBox.Show("Log not generated yet");
                    ListLogCBBox.SelectedItem = ListLogCBBox.GetItemText("View Today's Log");
                    Application.DoEvents();
                    break;
                case "AIPISSUE_MAKEUP":
                    if (File.Exists(SerializedClass.CurrentLocation6 + @"\Logs\" + Logname)) System.Diagnostics.Process.Start(SerializedClass.CurrentLocation6 + @"\Logs\" + Logname);
                    else MessageBox.Show("Log not generated yet");
                    ListLogCBBox.SelectedItem = ListLogCBBox.GetItemText("View Today's Log");
                    Application.DoEvents();
                    break;
                case "GSAISSUE_MAKEUP":
                    if (File.Exists(SerializedClass.CurrentLocation8 + @"\Logs\" + Logname)) System.Diagnostics.Process.Start(SerializedClass.CurrentLocation8 + @"\Logs\" + Logname);
                    else MessageBox.Show("Log not generated yet");
                    ListLogCBBox.SelectedItem = ListLogCBBox.GetItemText("View Today's Log");
                    Application.DoEvents();
                    break;
                case "SAGEISSUE_MAKEUP":
                    if (File.Exists(SerializedClass.CurrentLocation10 + @"\Logs\" + Logname)) System.Diagnostics.Process.Start(SerializedClass.CurrentLocation10 + @"\Logs\" + Logname);
                    else MessageBox.Show("Log not generated yet");
                    ListLogCBBox.SelectedItem = ListLogCBBox.GetItemText("View Today's Log");
                    Application.DoEvents();
                    break;
            }
        }
        public static byte[] ReadFully(Stream input)
        {
            byte[] buffer = new byte[16 * 1024];
            using (MemoryStream ms = new MemoryStream())
            {
                int read;
                while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
                {
                    ms.Write(buffer, 0, read);
                }
                return ms.ToArray();
            }
        }

        private void Startbtn_Click(object sender, EventArgs e)
        {

        }

    }
}
