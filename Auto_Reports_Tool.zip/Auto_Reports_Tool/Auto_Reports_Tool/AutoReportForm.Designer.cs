﻿namespace Auto_Reports_Tool
{
    partial class AutoReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ListLogCBBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Status = new System.Windows.Forms.ListBox();
            this.StopBtn = new System.Windows.Forms.Button();
            this.Startbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ListLogCBBox
            // 
            this.ListLogCBBox.BackColor = System.Drawing.Color.LightCyan;
            this.ListLogCBBox.FormattingEnabled = true;
            this.ListLogCBBox.Items.AddRange(new object[] {
            "View Today\'s Log",
            "APS Invoice Booking",
            "COBISSUE_MAKEUP",
            "CUPISSUE_MAKEUP",
            "ERSISSUE_MAKEUP",
            "Generate AIP Excel Report",
            "TnF STA",
            "SAGEISSUE_MAKEUP",
            "AIPISSUE_MAKEUP",
            "GSAISSUE_MAKEUP"});
            this.ListLogCBBox.Location = new System.Drawing.Point(311, 218);
            this.ListLogCBBox.Name = "ListLogCBBox";
            this.ListLogCBBox.Size = new System.Drawing.Size(107, 21);
            this.ListLogCBBox.TabIndex = 11;
            this.ListLogCBBox.Text = "View Today\'s Log";
            this.ListLogCBBox.SelectedIndexChanged += new System.EventHandler(this.ListLogCBBox_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Progress";
            // 
            // Status
            // 
            this.Status.FormattingEnabled = true;
            this.Status.Items.AddRange(new object[] {
            "Started.."});
            this.Status.Location = new System.Drawing.Point(12, 30);
            this.Status.Name = "Status";
            this.Status.Size = new System.Drawing.Size(293, 277);
            this.Status.TabIndex = 9;
            // 
            // StopBtn
            // 
            this.StopBtn.BackColor = System.Drawing.Color.LightCyan;
            this.StopBtn.Enabled = false;
            this.StopBtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.StopBtn.Location = new System.Drawing.Point(324, 180);
            this.StopBtn.Name = "StopBtn";
            this.StopBtn.Size = new System.Drawing.Size(76, 23);
            this.StopBtn.TabIndex = 8;
            this.StopBtn.Text = "STOP";
            this.StopBtn.UseVisualStyleBackColor = false;
            // 
            // Startbtn
            // 
            this.Startbtn.BackColor = System.Drawing.Color.LightCyan;
            this.Startbtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Startbtn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Startbtn.Location = new System.Drawing.Point(324, 138);
            this.Startbtn.Name = "Startbtn";
            this.Startbtn.Size = new System.Drawing.Size(76, 23);
            this.Startbtn.TabIndex = 7;
            this.Startbtn.Text = "START";
            this.Startbtn.UseVisualStyleBackColor = false;
            // 
            // AutoReportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(429, 322);
            this.Controls.Add(this.ListLogCBBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Status);
            this.Controls.Add(this.StopBtn);
            this.Controls.Add(this.Startbtn);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Name = "AutoReportForm";
            this.Text = "Auto Reports";
            this.Load += new System.EventHandler(this.AutoReportForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox ListLogCBBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox Status;
        private System.Windows.Forms.Button StopBtn;
        private System.Windows.Forms.Button Startbtn;
    }
}

