﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data;

namespace Auto_Reports_Tool
{
    class DBClass
    {
        //Main_Form Mf = new Main_Form();         
        public SqlConnection SqlConn = new SqlConnection();
        public SqlConnection SqlConnSesame = new SqlConnection();
        public SqlConnection SqlConnAPS = new SqlConnection();
        public SqlConnection SqlConnblr = new SqlConnection();
        public SqlConnection SqlConnEG = new SqlConnection();
        public SqlCommand SqlCmd = new SqlCommand();
        public SqlDataAdapter Sqladptr = new SqlDataAdapter();
        public SqlDataReader SqlReader;
        public DataTable dt;
        public DataSet ds;
        string ConnectionStr { get; set; }
        string connectionStringSesame { get; set; }
        string connectionStringAPS { get; set; }
        string connectionStringBangalore { get; set; }
        string connectionstringEG { get; set; }
        public void GetConnectinInfo(string sesame = "")
        {
            //CommonClass Cs = new CommonClass();  
            string DBinfo = Regex.Match(SerializedClass.Lookupinfo, "<DB>([^<>]*?)</DB>").Groups[1].Value;
            if (sesame == "ASME") DBinfo = Regex.Match(SerializedClass.Lookupinfo, "<SDB>([^<>]*?)</SDB>").Groups[1].Value;
            ConnectionStr = "Data Source=" + DBinfo.Split('|')[0] + ";Initial Catalog=" + DBinfo.Split('|')[1] + ";User Id=" + DBinfo.Split('|')[2] + ";Password=" + DBinfo.Split('|')[3] + ";Connection Timeout=120;Max Pool Size=500;Pooling = True";
            connectionStringSesame = "Data Source=sesame-dblive.ctrglcosg13x.ap-south-1.rds.amazonaws.com;Initial Catalog=LiveSESAME;Integrated Security=False;User Id=UserSesame;Password=$Sesame2018;Max Pool Size=1024;Pooling=true;MultipleActiveResultSets=True";
            connectionStringAPS = "Data Source=tsdbserver.cxnkf4pwz5qd.us-east-1.rds.amazonaws.com;Initial Catalog=API;Integrated Security=False;User Id=techsetdbadmin;Password=TS1setup!;Max Pool Size=1024;Pooling=true;MultipleActiveResultSets=True";
            connectionStringBangalore = "Data Source= 192.168.1.28 ;Initial Catalog=JTS;User Id=report;Password=srnovaserver@123;Connection Timeout=60;Max Pool Size=500;Pooling = True"; //"Data Source=192.168.1.28;Initial Catalog=NEWJTS;User Id=upload;Password=srnovaserver@123;Connection Timeout=120;Max Pool Size=500;Pooling = True";
           // connectionstringEG = "Data Source= tsdbserver.cxnkf4pwz5qd.us-east-1.rds.amazonaws.com;Initial Catalog=OCT;User Id=techsetdbadmin;Password=TS1setup!;Connection Timeout=60;Max Pool Size=500;Pooling = True";
            connectionstringEG = "Data Source= rds-db-editgenie-prod.crknd7prkc6v.us-west-2.rds.amazonaws.com;Initial Catalog=OCT;User Id=techsetdbadmin;Password=TS1setup!;Connection Timeout=60;Max Pool Size=500;Pooling = True";     
        }

        public SqlConnection GetConnection(string sesame = "")
        {
            if (sesame == "ASME") GetConnectinInfo("ASME");
            else GetConnectinInfo();
            try
            {
                SqlConn = new SqlConnection(ConnectionStr);
            }
            catch (Exception e) { }
            return SqlConn;
        }
        public SqlConnection GetConnectionSesame(string sesame = "")
        {
            GetConnectinInfo();
            try
            {
                SqlConnSesame = new SqlConnection(connectionStringSesame);
            }
            catch (Exception e) { }
            return SqlConnSesame;
        }
        public SqlConnection GetConnectionAPS(string sesame = "")
        {
            GetConnectinInfo();
            try
            {
                SqlConnAPS = new SqlConnection(connectionStringAPS);
            }
            catch (Exception e) { }
            return SqlConnAPS;
        }
        public SqlConnection GetConnectionBlr(string sesame = "")
        {
            GetConnectinInfo();
            try
            {
                SqlConnblr = new SqlConnection(connectionStringBangalore);
            }
            catch (Exception e) { }
            return SqlConnblr;
        }

        public void OpenConnection()
        {
            if (SqlConn.State == ConnectionState.Open)
            {
                SqlConn.Close();
            }
            SqlConn.Open();
        }
        public void CloseConnection()
        {
            if (SqlConn.State == ConnectionState.Open)
            {
                SqlConn.Close();
            }
        }
        public void OpenConnectionSesame()
        {
            if (SqlConnSesame.State == ConnectionState.Open)
            {
                SqlConnSesame.Close();
            }
            SqlConnSesame.Open();
        }
        public void CloseConnectionSesame()
        {
            if (SqlConnSesame.State == ConnectionState.Open)
            {
                SqlConnSesame.Close();
            }
        }
        public void OpenConnectionAPS()
        {
            if (SqlConnAPS.State == ConnectionState.Open)
            {
                SqlConnAPS.Close();
            }
            SqlConnAPS.Open();
        }
        public void CloseConnectionAPS()
        {
            if (SqlConnAPS.State == ConnectionState.Open)
            {
                SqlConnAPS.Close();
            }
        }
        public void OpenConnectionBlr()
        {
            if (SqlConnblr.State == ConnectionState.Open)
            {
                SqlConnblr.Close();
            }
            SqlConnblr.Open();
        }
        public void CloseConnectionBlr()
        {
            if (SqlConnblr.State == ConnectionState.Open)
            {
                SqlConnblr.Close();
            }
        }
        public void openConnectionEG()
        {
            if (SqlConnEG.State == ConnectionState.Open)
            {
                SqlConnEG.Close();
            }
            SqlConnEG.Open();
        }
        public void CloseConnectionEG()
        {
            if (SqlConnEG.State == ConnectionState.Open)
            {
                SqlConnEG.Close();
            }
        }
        public SqlConnection getconnectionEG()
        {
            GetConnectinInfo();
            try
            {
                SqlConnEG = new SqlConnection(connectionstringEG);
            }
            catch (Exception e) { }
            return SqlConnEG;
        }
    }
}
