﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;

namespace Auto_Reports_Tool
{
   public static class SerializedClass
    {
       public static string Lookupinfo = "", WatchLocation1 = "", WatchLocation2 = "", WatchLocation3 = "", WatchLocation4 = "", WatchLocation5 = "", WatchLocation6 = "", WatchLocation7 = "", WatchLocation8 = "", WatchLocation9 = "", WatchLocation10 = "", CurrentLocation1 = "", CurrentLocation2 = "", CurrentLocation3 = "", CurrentLocation4 = "", CurrentLocation5 = "", CurrentLocation6 = "", CurrentLocation7 = "", CurrentLocation8 = "", CurrentLocation9 = "", CurrentLocation10 = "", Date = "", month = "", ErrDate = "", Errmonth = "", MailServer = "";

       public delegate void additemDelegate(string item);
       //public static additemDelegate Statusupdate;
       //public static a;
       public static AutoReportForm p;
        public static void GetInfo()
        {
            Lookupinfo   = File.ReadAllText(System.Environment.CurrentDirectory + @"\ZipExtract.ini");           
            WatchLocation1 = Regex.Match(Lookupinfo, "<WL1>([^<>]*?)</WL1>").Groups[1].Value;            
            WatchLocation2 = Regex.Match(Lookupinfo, "<WL2>([^<>]*?)</WL2>").Groups[1].Value;
            WatchLocation3 = Regex.Match(Lookupinfo, "<WL3>([^<>]*?)</WL3>").Groups[1].Value;
            WatchLocation4 = Regex.Match(Lookupinfo, "<WL4>([^<>]*?)</WL4>").Groups[1].Value;
            WatchLocation5 = Regex.Match(Lookupinfo, "<WL5>([^<>]*?)</WL5>").Groups[1].Value;
            WatchLocation6 = Regex.Match(Lookupinfo, "<WL6>([^<>]*?)</WL6>").Groups[1].Value;
            WatchLocation7 = Regex.Match(Lookupinfo, "<WL7>([^<>]*?)</WL7>").Groups[1].Value;
            WatchLocation8 = Regex.Match(Lookupinfo, "<WL8>([^<>]*?)</WL8>").Groups[1].Value;
            WatchLocation9 = Regex.Match(Lookupinfo, "<WL9>([^<>]*?)</WL9>").Groups[1].Value;
            WatchLocation10 = Regex.Match(Lookupinfo, "<WL10>([^<>]*?)</WL10>").Groups[1].Value;
            CurrentLocation1 = Regex.Match(Lookupinfo, "<CL1>([^<>]*?)</CL1>").Groups[1].Value;
            CurrentLocation2 = Regex.Match(Lookupinfo, "<CL2>([^<>]*?)</CL2>").Groups[1].Value;
            CurrentLocation3 = Regex.Match(Lookupinfo, "<CL3>([^<>]*?)</CL3>").Groups[1].Value;
            CurrentLocation4 = Regex.Match(Lookupinfo, "<CL4>([^<>]*?)</CL4>").Groups[1].Value;
            CurrentLocation5 = Regex.Match(Lookupinfo, "<CL5>([^<>]*?)</CL5>").Groups[1].Value;
            CurrentLocation6 = Regex.Match(Lookupinfo, "<CL6>([^<>]*?)</CL6>").Groups[1].Value;
            CurrentLocation7 = Regex.Match(Lookupinfo, "<CL7>([^<>]*?)</CL7>").Groups[1].Value;
            CurrentLocation8 = Regex.Match(Lookupinfo, "<CL8>([^<>]*?)</CL8>").Groups[1].Value;
            CurrentLocation9 = Regex.Match(Lookupinfo, "<CL9>([^<>]*?)</CL9>").Groups[1].Value;
            CurrentLocation10 = Regex.Match(Lookupinfo, "<CL10>([^<>]*?)</CL10>").Groups[1].Value;
            Date = DateTime.Now.ToString("dd") + @"-" + DateTime.Now.ToString("MMM").ToUpper() + @"-" + DateTime.Now.ToString("yyyy");
            month =  DateTime.Now.ToString("MMM").ToUpper() + @"-" + DateTime.Now.Year.ToString();
            ErrDate = DateTime.Now.ToString("dd") +  DateTime.Now.ToString("MM")  + DateTime.Now.ToString("yyyy");
            Errmonth = DateTime.Now.ToString("MM") + DateTime.Now.ToString("yyyy");
            if (File.Exists(@"\\dt0308\d\Environment\DT0308.ini")) MailServer = File.ReadAllText(@"\\dt0308\d\Environment\DT0308.ini").Split('|')[File.ReadAllText(@"\\dt0308\d\Environment\DT0308.ini").Split('|').Length - 1];
        }

    }
}
