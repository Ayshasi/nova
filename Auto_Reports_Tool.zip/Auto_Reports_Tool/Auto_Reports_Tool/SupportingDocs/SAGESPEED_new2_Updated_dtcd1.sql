Declare @FromDt varchar(100) = '19000101'
Declare @ToDt varchar(100) = '20220919'
Declare @Jrnl_User varchar(max) =''
Declare @Jrnl_Acronym varchar(max) = ''


if (@FromDt='' or @ToDt='')
begin
	set @FromDt='19000101'
	set @ToDt=convert(varchar(12),GETDATE(),112)
end
					select	J.Jrnl_Acronym as Journal,
					--J.Jrnl_ProjFrom as Region,
					Artcl_ArticleID  as Articleid,
					REPLACE(CONVERT(VARCHAR,Artcl_ReceivedDt,106),' ','-') as [MS Recd date],
					REPLACE(CONVERT(VARCHAR,(select top 1 
							Trns1.JrnlTrns_OutTime
							from TrnsJournal Trns1 with(nolock)
							where Trns1.JrnlTrns_NextProcessID='20'
							and Trns1.JrnlTrns_Status='Completed' 
							and Trns1.JrnlTrns_ArticleId=Artcl_ID
							order by Trns1.Jrnltrns_id desc),106),' ','-')  as [CE/XML sent date],
					dbo.fnTATWithoutHolidaysNew(convert(date,Artcl_ReceivedDt), convert(date, (select top 1 
							Trns1.JrnlTrns_OutTime
							from TrnsJournal Trns1 with(nolock)
							where Trns1.JrnlTrns_NextProcessID='20'
							and Trns1.JrnlTrns_Status='Completed' 
							and Trns1.JrnlTrns_ArticleId=Artcl_ID
							order by Trns1.Jrnltrns_id desc)),0,0)-1	as [CE/XML TAT],
					REPLACE(CONVERT(VARCHAR,Artcl_UploadedDt,106),' ','-') as [Proof sent Date],
					dbo.fnTATWithoutHolidaysNew(convert(date,(select top 1 
							Trns1.JrnlTrns_OutTime
							from TrnsJournal Trns1 with(nolock)
							where Trns1.JrnlTrns_NextProcessID='20'
							and Trns1.JrnlTrns_Status='Completed' 
							and Trns1.JrnlTrns_ArticleId=Artcl_ID
							order by Trns1.Jrnltrns_id desc)), convert(date, Artcl_UploadedDt,106),0,0)-1	as [Proof TAT],
					REPLACE(CONVERT(VARCHAR,MJ.JRST_ReceivedDt,106),' ','-') as  [Receipt of auth/ed corr],				
					dbo.fnTATWithoutHolidaysNew(convert(date,MJ.JRST_ReceivedDt), convert(date, (select top 1 
							Trns.JrnlTrns_OutTime
							from TrnsJournalRev Trns with(nolock)
							where (Trns.JrnlTrns_NextProcessID='112' or Trns.JrnlTrns_NextProcessID='33')
							and Trns.Jrnltrns_ProcessCd='202'
							and Trns.JrnlTrns_Status='Completed' 
							and Trns.JrnlTrns_ArticleId=MJ.JRA_ID
							order  by Trns.Jrnltrns_id desc)),0,0)-1	as [Time taken - auth/ed],							
					REPLACE(CONVERT(VARCHAR,(select top 1 
							Trns.JrnlTrns_OutTime
							from TrnsJournalRev Trns with(nolock)
							where Trns.JrnlTrns_NextProcessID='202'
							and Trns.JrnlTrns_Status='Completed' 
							and Trns.JrnlTrns_ArticleId=MJ.JRA_ID
							order by Trns.Jrnltrns_id desc),106),' ','-')  as [Rev. Proof sent date],		
					dbo.fnTATWithoutHolidaysNew(convert(date,MJ.JRST_ReceivedDt), convert(date, (select top 1 
							Trns.JrnlTrns_OutTime
							from TrnsJournalRev Trns with(nolock)
							where Trns.JrnlTrns_NextProcessID='202'
							and Trns.JrnlTrns_Status='Completed' 
							and Trns.JrnlTrns_ArticleId=MJ.JRA_ID
							order by Trns.Jrnltrns_id desc)),0,0)-1	as [Auth/ed corrs - TAT],		
					isnull(REPLACE(CONVERT(VARCHAR,(select top 1 JRST_ReceivedDt from 
							JR_Main M with(nolock)
							Join JR_Stage_Tran T with(nolock) on (M.JRM_ID=T.JRST_JRM_ID)
						where JRST_JRS_ID in (109,110,111) 
						and JRST_UploadedDT is not null
						and JRM_ArticleID=A.Artcl_ArticleID 
						order by JRST_UploadedDT desc),106),' ','-'),'')  as [Proj. Mgr Corrs],
					REPLACE(CONVERT(VARCHAR,(select top 1 
							Trns.JrnlTrns_OutTime
							from TrnsJournalRev Trns with(nolock)
							where (Trns.JrnlTrns_NextProcessID='112' or Trns.JrnlTrns_NextProcessID='33')
							and Trns.Jrnltrns_ProcessCd='202'
							and Trns.JrnlTrns_Status='Completed' 
							and (Trns.JrnlTrns_ArticleId=MJ.JRA_ID or Trns.JrnlTrns_ArticleId=MJ1.JRA_ID)
							order  by Trns.Jrnltrns_id desc),106),' ','-')  as [PAP approval date],	
				 dbo.fnTATWithoutHolidaysNew(convert(date, (select top 1 
							Trns.JrnlTrns_OutTime
							from TrnsJournalRev Trns with(nolock)
							where Trns.JrnlTrns_NextProcessID='202'
							and Trns.JrnlTrns_Status='Completed' 
							and (Trns.JrnlTrns_ArticleId=MJ.JRA_ID or Trns.JrnlTrns_ArticleId=MJ1.JRA_ID)
							order by Trns.Jrnltrns_id desc)),convert(date,(select top 1 
							Trns.JrnlTrns_OutTime
							from TrnsJournalRev Trns with(nolock)
							where (Trns.JrnlTrns_NextProcessID='112' or Trns.JrnlTrns_NextProcessID='33')
							and Trns.Jrnltrns_ProcessCd='202'
							and Trns.JrnlTrns_Status='Completed' 
							and (Trns.JrnlTrns_ArticleId=MJ.JRA_ID or Trns.JrnlTrns_ArticleId=MJ1.JRA_ID)
							order  by Trns.Jrnltrns_id desc)),0,0)-1  as [TAT],		
					REPLACE(CONVERT(VARCHAR,(select top 1 JRST_UploadedDT from 
							JR_Main M with(nolock) 
							Join JR_Stage_Tran T with(nolock) on (M.JRM_ID=T.JRST_JRM_ID)
					where JRST_JRS_ID in (58)--,59,60) 
					and JRST_UploadedDT is not null
					and JRM_ArticleID=A.Artcl_ArticleID 
					order by JRST_UploadedDT desc),106),' ','-')  as [PAP Uploaded Date],					
					dbo.fnTATWithoutHolidaysNew(convert(date,(select top 1 
							Trns.JrnlTrns_OutTime
							from TrnsJournalRev Trns with(nolock)
							where (Trns.JrnlTrns_NextProcessID='112' or Trns.JrnlTrns_NextProcessID='33')
							and Trns.Jrnltrns_ProcessCd='202'
							and Trns.JrnlTrns_Status='Completed' 
							and (Trns.JrnlTrns_ArticleId=MJ.JRA_ID or Trns.JrnlTrns_ArticleId=MJ1.JRA_ID)
							order  by Trns.Jrnltrns_id desc)), convert(date, (select top 1 JRST_UploadedDT from 
							JR_Main M 
							Join JR_Stage_Tran T with(nolock) on (M.JRM_ID=T.JRST_JRM_ID)
					where JRST_JRS_ID in (58)--,59,60) 
					and JRST_UploadedDT is not null
					and JRM_ArticleID=A.Artcl_ArticleID 
					order by JRST_UploadedDT desc)),0,0)-1	as [PAP TAT],		
					--'' as [Target],					
					--DATEDIFF(DAY,Artcl_ReceivedDt,
					--			(
					--			--select top 1 JRST_UploadedDT from 
					--			--		JR_Main M 
					--			--		Join JR_Stage_Tran T on (M.JRM_ID=T.JRST_JRM_ID)
					--			--where JRST_JRS_ID in (35,36,37,78,97,98) 
					--			--and JRST_UploadedDT is not null
					--			--and JRM_ArticleID=A.Artcl_ArticleID 
					--			--order by JRST_UploadedDT desc
					--			--)
					--			select top 1 
					--		Trns.JrnlTrns_OutTime
					--		from TrnsJournalRev Trns
					--		where (Trns.JrnlTrns_NextProcessID='112' or Trns.JrnlTrns_NextProcessID='33')
					--		and Trns.Jrnltrns_ProcessCd='202'
					--		and Trns.JrnlTrns_Status='Completed' 
					--		and Trns.JrnlTrns_ArticleId=MJ.JRA_ID
					--		order  by Trns.Jrnltrns_id desc)
					--			) as [Total TTP1],
					--dbo.fnTATWithoutHolidaysNew(convert(date,Artcl_ReceivedDt), convert(date, (select top 1 
					--		Trns.JrnlTrns_OutTime
					--		from TrnsJournalRev Trns
					--		where (Trns.JrnlTrns_NextProcessID='112' or Trns.JrnlTrns_NextProcessID='33')
					--		and Trns.Jrnltrns_ProcessCd='202'
					--		and Trns.JrnlTrns_Status='Completed' 
					--		and (Trns.JrnlTrns_ArticleId=MJ.JRA_ID or Trns.JrnlTrns_ArticleId=MJ1.JRA_ID)
					--		order  by Trns.Jrnltrns_id desc)),0,0)
					--			as [Total TTP],
						dbo.fnTATWithoutHolidaysNew(convert(date,Artcl_ReceivedDt), convert(date, (select top 1 JRST_UploadedDT from 
							JR_Main M with(nolock) 
							Join JR_Stage_Tran T with(nolock) on (M.JRM_ID=T.JRST_JRM_ID)
					where JRST_JRS_ID in (58)--,59,60) 
					and JRST_UploadedDT is not null
					and JRM_ArticleID=A.Artcl_ArticleID 
					order by JRST_UploadedDT desc)),0,0)
								as [Total TTP],
					J.Jrnl_Contact as PM,
					isnull(Proof_Pages,0) as Pages
								--,									
					--'' as [Comparison to Target],
					--Artcl_ReceivedDt as RecDt ,
					--SUBSTRING(CONVERT(VARCHAR(11),JRST_UploadedDT,106),4,10) MonthYear
		
		from 
		Article A
		join Journal J on (A.Artcl_JrnlId=J.Jrnl_Id)
		join Publishers P on (J.Jrnl_PublID=P.Publ_ID)
		left join (select JRA_ID,JRA_ArticleID from 
			JR_Main M 
			Join JR_Stage_Tran T with(nolock) on (M.JRM_ID=T.JRST_JRM_ID)
			Join JR_Articles AT with(nolock) on (AT.JRA_JRST_ID=T.JRST_ID)
		where JRST_JRS_ID=109 ) MJ1 on (A.Artcl_ArticleID=MJ1.JRA_ArticleID)	
		left join (select JRM_ID,JRA_ID,JRA_ArticleID,JRST_ReceivedDt,JRST_UploadedDT from 
			JR_Main M 
			Join JR_Stage_Tran T with(nolock) on (M.JRM_ID=T.JRST_JRM_ID)
			Join JR_Articles AT with(nolock) on (AT.JRA_JRST_ID=T.JRST_ID)
		where JRST_JRS_ID=35 ) MJ on (A.Artcl_ArticleID=MJ.JRA_ArticleID)			
		where P.Publ_ID=4 
		and CHARINDEX('_', A.Artcl_ArticleId) = 0	 and isnull(Inv_OtherTypesetter,'')<>'Y' and Jrnl_Acronym<>a.Artcl_ArticleId
		and artcl_id>1531455
		--and convert(varchar(12),MJ.JRST_UploadedDT,112)>= @FromDt 
		--and convert(varchar(12),MJ.JRST_UploadedDT,112)<=@ToDt 
		and convert(varchar(12),Artcl_ReceivedDt,112)>= @FromDt 
		and convert(varchar(12),Artcl_ReceivedDt,112)<=@ToDt 
		order by Artcl_ReceivedDt desc 
		--order by Artcl_ArticleID  