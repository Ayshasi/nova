﻿using System;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using Xl = Microsoft.Office.Interop.Excel;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Net;
using Renci.SshNet;
//using Limilabs.FTP.Client;

namespace Auto_Reports_Tool
{
    class XLClass
    {
        public void CellAlignment(Xl.Range chartRange)
        {
            //chartRange.BorderAround(Xl.XlLineStyle.xlContinuous, Xl.XlBorderWeight.xlMedium, Xl.XlColorIndex.xlColorIndexAutomatic, Xl.XlColorIndex.xlColorIndexAutomatic);
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeLeft).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeRight).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideHorizontal).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideVertical).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeBottom).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeTop).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Columns.AutoFit();
            chartRange.Cells.HorizontalAlignment = Xl.XlHAlign.xlHAlignCenter;
        }

        public bool CreateReport1()
        {
            try
            {               
                DBClass db = new DBClass();
                int globalcnt=0;
                string Q1 = "SELECT Artcl_ArticleId,Artcl_Status,Proof_Pages,Artcl_ReceivedDt,Artcl_ScheduledDt FROM Article where Artcl_JrnlId IN (SELECT Jrnl_Id FROM Journal where Jrnl_PublID=99 )"; //and  YEAR(Artcl_ReceivedDt)=YEAR(GETDATE())  and MONTH(Artcl_ReceivedDt)=MONTH(GETDATE())-1 AND DAY(Artcl_ReceivedDt)=DAY(GETDATE()-7)";
                string Q2 = "SELECT Article.Artcl_ArticleId,Article.Artcl_Status,Article.Proof_Pages,JR_Stage_Tran.JRST_ReceivedDt,JR_Stage_Tran.JRST_ScheduledDt,JR_Stage_Tran.JRST_JRS_ID FROM JR_Stage_Tran inner JOIN JR_Main  on  JRST_JRM_ID= JRM_Id INNER JOIN Article on Artcl_ArticleId=JR_Main.JRM_ArticleID  where  JR_Stage_Tran.JRST_JRM_ID IN (SELECT JRM_Id FROM JR_Main where JRM_JournalID IN(SELECT Jrnl_Id FROM Journal where Jrnl_PublID=99))"; //and  YEAR(JR_Stage_Tran.JRST_ReceivedDt)=YEAR(GETDATE())  and MONTH(JR_Stage_Tran.JRST_ReceivedDt)=MONTH(GETDATE())-1  AND DAY(JR_Stage_Tran.JRST_ReceivedDt)=DAY(GETDATE()-7)";
                ////string Q3 = " SELECT Artcl_ArticleId,artcl_SourceBy,Artcl_TextFolios,Proof_Pages,Artcl_Volume,Artcl_Issue FROM Article where Artcl_JrnlId IN (SELECT Jrnl_Id FROM Journal where Jrnl_PublID=99 ) and  YEAR(Artcl_ReceivedDt)=YEAR(GETDATE())  and MONTH(Artcl_ReceivedDt)=MONTH(GETDATE())-1 AND DAY(Artcl_ReceivedDt)=DAY(GETDATE()-7) AND Artcl_ArticleId LIKE '%";
                ////string Q4 = "SELECT Article.Artcl_ArticleId,Article.artcl_SourceBy,Article.Artcl_TextFolios,Article.Proof_Pages,Article.Artcl_Volume,Article.Artcl_Issue FROM JR_Stage_Tran inner JOIN JR_Main  on  JRST_JRM_ID= JRM_Id INNER JOIN Article on Artcl_ArticleId=JR_Main.JRM_ArticleID  where  YEAR(JR_Stage_Tran.JRST_ReceivedDt)=YEAR(GETDATE())  and MONTH(JR_Stage_Tran.JRST_ReceivedDt)=MONTH(GETDATE())-1  AND DAY(JR_Stage_Tran.JRST_ReceivedDt)=DAY(GETDATE()-7) AND JR_Stage_Tran.JRST_JRM_ID IN (SELECT JRM_Id FROM JR_Main where JRM_JournalID IN(SELECT Jrnl_Id FROM Journal where Jrnl_PublID=99)) AND Article.Artcl_ArticleId LIKE '%";
                ////db.Sqladptr = new SqlDataAdapter(new SqlCommand("SELECT Artcl_ArticleId,Artcl_Status,Proof_Pages,Artcl_ReceivedDt,Artcl_ScheduledDt FROM Article where Artcl_ArticleId like'%JLA'", db.GetConnection()));

                //string Q1 = "SELECT Artcl_ArticleId,Artcl_Status,Proof_Pages,Artcl_ReceivedDt,Artcl_ScheduledDt FROM Article where Artcl_JrnlId IN (SELECT Jrnl_Id FROM Journal where Jrnl_PublID=99 ) and  YEAR(Artcl_ReceivedDt)=YEAR(GETDATE())  and MONTH(Artcl_ReceivedDt)=MONTH(GETDATE()) AND DAY(Artcl_ReceivedDt)=DAY(GETDATE())";
                //string Q2 = "SELECT Article.Artcl_ArticleId,Article.Artcl_Status,Article.Proof_Pages,JR_Stage_Tran.JRST_ReceivedDt,JR_Stage_Tran.JRST_ScheduledDt,JR_Stage_Tran.JRST_JRS_ID FROM JR_Stage_Tran inner JOIN JR_Main  on  JRST_JRM_ID= JRM_Id INNER JOIN Article on Artcl_ArticleId=JR_Main.JRM_ArticleID  where  YEAR(JR_Stage_Tran.JRST_ReceivedDt)=YEAR(GETDATE())  and MONTH(JR_Stage_Tran.JRST_ReceivedDt)=MONTH(GETDATE())  AND DAY(JR_Stage_Tran.JRST_ReceivedDt)=DAY(GETDATE()) AND JR_Stage_Tran.JRST_JRM_ID IN (SELECT JRM_Id FROM JR_Main where JRM_JournalID IN(SELECT Jrnl_Id FROM Journal where Jrnl_PublID=99))";
                ////string Q3 = " SELECT Artcl_ArticleId,artcl_SourceBy,Artcl_TextFolios,Proof_Pages,Artcl_Volume,Artcl_Issue FROM Article where Artcl_JrnlId IN (SELECT Jrnl_Id FROM Journal where Jrnl_PublID=99 ) and  YEAR(Artcl_ReceivedDt)=YEAR(GETDATE())  and MONTH(Artcl_ReceivedDt)=MONTH(GETDATE()) AND DAY(Artcl_ReceivedDt)=DAY(GETDATE()) AND Artcl_ArticleId LIKE '%";
                ////string Q4 = "SELECT Article.Artcl_ArticleId,Article.artcl_SourceBy,Article.Artcl_TextFolios,Article.Proof_Pages,Article.Artcl_Volume,Article.Artcl_Issue FROM JR_Stage_Tran inner JOIN JR_Main  on  JRST_JRM_ID= JRM_Id INNER JOIN Article on Artcl_ArticleId=JR_Main.JRM_ArticleID  where  YEAR(JR_Stage_Tran.JRST_ReceivedDt)=YEAR(GETDATE())  and MONTH(JR_Stage_Tran.JRST_ReceivedDt)=MONTH(GETDATE())  AND DAY(JR_Stage_Tran.JRST_ReceivedDt)=DAY(GETDATE()) AND JR_Stage_Tran.JRST_JRM_ID IN (SELECT JRM_Id FROM JR_Main where JRM_JournalID IN(SELECT Jrnl_Id FROM Journal where Jrnl_PublID=99)) AND Article.Artcl_ArticleId LIKE '%";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rows = ds.Tables[0].Rows;
                Xl.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                Xl.Workbook xlWorkBook;
                Xl.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                System.Collections.ArrayList JRlist = new System.Collections.ArrayList();
                System.Collections.ArrayList JRStagelist = new System.Collections.ArrayList(); 
                //***
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "Sr. No.";
                xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                xlWorkSheet.Cells[1, 3] = "Article ID";
                xlWorkSheet.Cells[1, 4] = "Curr. Activity";
                xlWorkSheet.Cells[1, 5] = "Pages";
                xlWorkSheet.Cells[1, 6] = "Submission";
                xlWorkSheet.Cells[1, 7] = "Recd Date";
                xlWorkSheet.Cells[1, 8] = "Due Date";
                xlWorkSheet.Cells[1, 9] = "Type";
                xlWorkSheet.Cells[1, 10] = "Date to be sent";
                xlWorkSheet.Cells[1, 11] = "Reasons for Delay";
                int i = 2, k = 1, rcnt = rows.Count;
                globalcnt+=rows.Count;
                for (int j = 0; j < rows.Count; j++)
                {
                    if ((Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value == "")||(Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value.ToUpper() == "SAMPLE" ))continue;
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value;
                    if (!JRlist.Contains(Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value))
                    {
                        JRlist.Add(Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value);
                    }
                    xlWorkSheet.Cells[i, 3] = Regex.Match(rows[j][0].ToString(), @"^\d+").Groups[0].Value;
                    xlWorkSheet.Cells[i, 4] = rows[j][1].ToString();
                    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 6] = "Starter";
                    JRStagelist.Add(Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value + "|Starter");
                    xlWorkSheet.Cells[i, 7] = rows[j][3].ToString();
                    xlWorkSheet.Cells[i, 8] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 9] = "";
                    xlWorkSheet.Cells[i, 10] = "";
                    xlWorkSheet.Cells[i, 11] = "";
                    i++;
                    k++;
                }
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q2, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                rows = ds.Tables[0].Rows;
                for (int j = 0; j < rows.Count; j++)
                {
                    string stage = "";
                    if (Regex.IsMatch(rows[j][5].ToString(), "^(35|36|37|78|97|98)$")) stage = "CorrectionsToVendor";
                    else if (Regex.IsMatch(rows[j][5].ToString(), "^(33|34)$")) stage = "RevisionsToVendor";
                    else if (Regex.IsMatch(rows[j][5].ToString(), "^(43)$")) stage = "PaginationToVendor";
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value;
                    if (!JRlist.Contains(Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value))
                    {
                        JRlist.Add(Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value);
                    }
                    JRStagelist.Add(Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value + '|' + stage);
                    xlWorkSheet.Cells[i, 3] = Regex.Match(rows[j][0].ToString(), @"^\d+").Groups[0].Value;
                    xlWorkSheet.Cells[i, 4] = rows[j][1].ToString();
                    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 6] = stage;
                    xlWorkSheet.Cells[i, 7] = rows[j][3].ToString();
                    xlWorkSheet.Cells[i, 8] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 9] = "";
                    xlWorkSheet.Cells[i, 10] = "";
                    xlWorkSheet.Cells[i, 11] = "";
                    i++;
                    k++;
                }
                rcnt += rows.Count;
                globalcnt+=rows.Count;
                Xl.Range chartRange = xlWorkSheet.get_Range("A1", "K" + (rcnt + 1));
                CellAlignment(chartRange);              
                chartRange = xlWorkSheet.get_Range("A1", "K1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                //***                
                if (JRlist.Count > 0)
                {
                    xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.Add();
                    //xlWorkSheet.Cells.NumberFormat = "@";
                    xlWorkSheet.Cells[3, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[3, 2] = "Column Labels";
                    xlWorkSheet.Cells[4, 1] = "Row Labels";
                    xlWorkSheet.Cells[4, 2] = "Starter";
                    xlWorkSheet.Cells[4, 3] = "CorrectionsToVendor";
                    xlWorkSheet.Cells[4, 4] = "RivisionsToVendor";
                    xlWorkSheet.Cells[4, 5] = "PaginationToVendor";
                    xlWorkSheet.Cells[4, 6] = "Grand Total";
                    chartRange = xlWorkSheet.get_Range("A3", "F4");
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;  
                    i = 5;
                    foreach (string JID in JRlist)
                    {
                        int S = 0, CV = 0, RV = 0, PV = 0; 
                        foreach (string Stage in JRStagelist)
                        {
                            if (Stage.Contains(JID))
                            {
                                if (Stage.Contains("Starter"))
                                {
                                    S++;
                                }
                                else if (Stage.Contains("CorrectionsToVendor"))
                                {
                                    CV++;
                                }
                                else if (Stage.Contains("RevisionsToVendor"))
                                {
                                    RV++;
                                }
                                else if (Stage.Contains("PaginationToVendor"))
                                {
                                    PV++;
                                }
                            }
                        }
                        xlWorkSheet.Cells[i, 1] = JID;
                        if (S > 0)
                        {
                            xlWorkSheet.Cells[i, 2] = S;
                        }
                        else xlWorkSheet.Cells[i, 2] = "";                                  
                        if (CV> 0)
                        {
                            xlWorkSheet.Cells[i, 3] = CV;
                        }
                        else xlWorkSheet.Cells[i, 3] = "";                       
                        if (RV > 0)
                        {
                            xlWorkSheet.Cells[i, 4] = RV;
                        }
                        else xlWorkSheet.Cells[i, 4] = "";                       
                        if (PV > 0)
                        {
                            xlWorkSheet.Cells[i, 5] = PV;
                        }
                        else xlWorkSheet.Cells[i, 5] = "";
                        //chartRange = xlWorkSheet.Cells.get_Range(xlWorkSheet.Cells[i, 6]);
                        xlWorkSheet.Cells[i, 6] = string.Format("=SUM(B{0}:E{0})", i);                        
                        i++;
                    }
                    xlWorkSheet.Cells[i, 1] = "Grand Total";
                    xlWorkSheet.Cells[i, 2] = string.Format("=SUM(B5:B{0})", i-1);
                    xlWorkSheet.Cells[i, 3] = string.Format("=SUM(C5:C{0})", i-1);
                    xlWorkSheet.Cells[i, 4] = string.Format("=SUM(D5:D{0})", i-1);
                    xlWorkSheet.Cells[i, 5] = string.Format("=SUM(E5:E{0})", i-1);
                    xlWorkSheet.Cells[i, 6] = string.Format("=SUM(F5:F{0})", i-1);
                    chartRange = xlWorkSheet.get_Range("A4", "F" + i);
                    CellAlignment(chartRange);
                    chartRange = xlWorkSheet.get_Range("A" + i, "F" + i);
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                }
                //foreach (string JID in Alist)
                //{
                //    db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q3 + JID +"'", db.GetConnection()));
                //    db.dt = new DataTable();
                //    db.Sqladptr.Fill(db.dt);
                //    db.CloseConnection();
                //    ds = new DataSet("New_DataSet");
                //    ds.Tables.Add(db.dt);
                //    rows = ds.Tables[0].Rows;                   
                //    xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.Add();
                //    //xlWorkSheet.Cells.NumberFormat = "@";
                //    xlWorkSheet.Cells[1, 1] = "Customer";
                //    xlWorkSheet.Cells[2, 1] = "Journal";
                //    xlWorkSheet.Cells[3, 1] = "Volume / Issue";
                //    xlWorkSheet.Cells[4, 1] = "Project Manager";
                //    xlWorkSheet.Cells[5, 1] = "AIP Production Editor";
                //    xlWorkSheet.Cells[1, 2] = "AIP";
                //    xlWorkSheet.Cells[2, 2] = JID;                    
                //    if( rows.Count>0)
                //    {
                //        xlWorkSheet.Cells[3, 2] = rows[0][4].ToString() + '(' + rows[0][5].ToString() + ')';
                //    }                  
                //    xlWorkSheet.Cells[4, 2] = "";
                //    xlWorkSheet.Cells[5, 2] = "";
                //    i = 8; k = 1; rcnt = rows.Count;
                //    globalcnt+=rows.Count;

                //    xlWorkSheet.Cells[7, 1] = "S.No.";
                //    xlWorkSheet.Cells[7, 2] = "Article No.";
                //    xlWorkSheet.Cells[7, 3] = "Source";
                //    xlWorkSheet.Cells[7, 4] = "MSS";
                //    xlWorkSheet.Cells[7, 5] = "Pages";
                //    xlWorkSheet.Cells[7, 6] = "Application file formats";
                //    xlWorkSheet.Cells[7, 7] = "Redrawing - Simple";
                //    xlWorkSheet.Cells[7, 8] = "Redrawing - Medium";
                //    xlWorkSheet.Cells[7, 9] = "Redrawing - Complex";
                //    xlWorkSheet.Cells[7, 10] = "Graphic editing";
                //    xlWorkSheet.Cells[7, 11] = "RForensic Image";
                //    xlWorkSheet.Cells[7, 12] = "AA's";                
                //    for (int j = 0; j < rows.Count; j++)
                //    {
                //        xlWorkSheet.Cells[i, 1] = k;
                //        xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                //        xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();
                //        xlWorkSheet.Cells[i, 4] = rows[j][2].ToString();
                //        xlWorkSheet.Cells[i, 5] = rows[j][3].ToString();
                //        xlWorkSheet.Cells[i, 6] = "";
                //        xlWorkSheet.Cells[i, 7] = "";
                //        xlWorkSheet.Cells[i, 8] = "";
                //        xlWorkSheet.Cells[i, 9] = "";
                //        xlWorkSheet.Cells[i, 10] = "";
                //        xlWorkSheet.Cells[i, 11] = "";
                //        xlWorkSheet.Cells[i, 12] = "";
                //        i++;
                //        k++;
                //    }
                //    db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q4 + JID + "'", db.GetConnection()));
                //    db.dt = new DataTable();
                //    db.Sqladptr.Fill(db.dt);
                //    db.CloseConnection();
                //    ds = new DataSet("New_DataSet");
                //    ds.Tables.Add(db.dt);
                //    rows = ds.Tables[0].Rows;
                //    if (rows.Count > 0)
                //    {
                //        xlWorkSheet.Cells[3,2] = rows[0][4].ToString() + '(' + rows[0][5].ToString() + ')';
                //    }
                //    for (int j = 0; j < rows.Count; j++)
                //    {
                //        xlWorkSheet.Cells[i, 1] = k;
                //        xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                //        xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();
                //        xlWorkSheet.Cells[i, 4] = rows[j][2].ToString();
                //        xlWorkSheet.Cells[i, 5] = rows[j][3].ToString();
                //        xlWorkSheet.Cells[i, 6] = "";
                //        xlWorkSheet.Cells[i, 7] = "";
                //        xlWorkSheet.Cells[i, 8] = "";
                //        xlWorkSheet.Cells[i, 9] = "";
                //        xlWorkSheet.Cells[i, 10] = "";
                //        xlWorkSheet.Cells[i, 11] = "";
                //        xlWorkSheet.Cells[i, 12] = "";
                //        i++;
                //        k++;
                //    }
               
                //rcnt += rows.Count;
                //globalcnt+=rows.Count;
                //chartRange = xlWorkSheet.get_Range("A1", "B5");
                //CellAlignment(chartRange);
                //chartRange = xlWorkSheet.get_Range("A7", "L" + (rcnt +7));
                //CellAlignment(chartRange);
                //chartRange = xlWorkSheet.get_Range("B" + (rcnt + 8), "C" + (rcnt + 8));
                //chartRange.Merge();   
                //chartRange.Columns.AutoFit();
                ////xlWorkSheet.Unprotect();
                //xlWorkSheet.Cells[rcnt + 8, 2] = "Total";
                //chartRange = xlWorkSheet.Cells.get_Range("B" + (rcnt + 8));
                //CellAlignment(chartRange);
                //chartRange = xlWorkSheet.Cells.get_Range("C" + (rcnt + 8));
                //CellAlignment(chartRange);
                //chartRange = xlWorkSheet.Cells.get_Range("D" + (rcnt + 8));
                //chartRange.Formula = "=SUM(D8:D" + (rcnt + 7) + ")";
                //CellAlignment(chartRange);
                //chartRange = xlWorkSheet.Cells.get_Range("E" + (rcnt + 8));
                //chartRange.Formula = "=SUM(E8:E" + (rcnt + 7) + ")";
                //CellAlignment(chartRange);
                //chartRange = xlWorkSheet.Cells.get_Range("F" + (rcnt + 8));
                //chartRange.Formula = "=SUM(F8:F" + (rcnt + 7) + ")";
                //CellAlignment(chartRange);
                //chartRange = xlWorkSheet.Cells.get_Range("G" + (rcnt + 8));
                //chartRange.Formula = "=SUM(G8:G" + (rcnt + 7) + ")";
                //CellAlignment(chartRange);
                //chartRange = xlWorkSheet.Cells.get_Range("H" + (rcnt + 8));
                //chartRange.Formula = "=SUM(H8:H" + (rcnt + 7) + ")";
                //CellAlignment(chartRange);
                //chartRange = xlWorkSheet.Cells.get_Range("I" + (rcnt + 8));
                //chartRange.Formula = "=SUM(I8:I" + (rcnt + 7) + ")";
                //CellAlignment(chartRange);
                //chartRange = xlWorkSheet.Cells.get_Range("J" + (rcnt + 8));
                //chartRange.Formula = "=SUM(J8:J" + (rcnt + 7) + ")";
                //CellAlignment(chartRange);
                //chartRange = xlWorkSheet.Cells.get_Range("K" + (rcnt + 8));
                //chartRange.Formula = "=SUM(K8:K" + (rcnt + 7) + ")";
                //CellAlignment(chartRange);
                //chartRange = xlWorkSheet.Cells.get_Range("L" + (rcnt + 8));
                //chartRange.Formula = "=SUM(L8:L" + (rcnt + 7) + ")";
                //CellAlignment(chartRange);
                //chartRange = xlWorkSheet.get_Range("A1" , "L" + (rcnt + 8));                
                //chartRange.Columns.AutoFit();              
                //}
                //xlWorkSheet.Cells[rcnt + 8, 4] = "=SUM(D8:D" + (rcnt + 7) + ")";
                //xlWorkSheet.Cells[rcnt + 8, 5] = "=SUM(E8:E" + (rcnt + 7) + ")";
                //xlWorkSheet.Cells[rcnt + 8, 6] = "=SUM(F8:F" + (rcnt + 7) + ")";
                //xlWorkSheet.Cells[rcnt + 8, 7] = "=SUM(G8:G" + (rcnt + 7) + ")";
                //xlWorkSheet.Cells[rcnt + 8, 8] = "=SUM(H8:H" + (rcnt + 7) + ")";
                //xlWorkSheet.Cells[rcnt + 8, 9] = "=SUM(I8:I" + (rcnt + 7) + ")";
                //xlWorkSheet.Cells[rcnt + 8, 10] = "=SUM(J8:J" + (rcnt + 7) + ")";
                //xlWorkSheet.Cells[rcnt + 8, 11] = "=SUM(K8:K" + (rcnt + 7) + ")";
                //xlWorkSheet.Cells[rcnt + 8, 12] = "=SUM(L8:L" + (rcnt + 7) + ")";              
                if (globalcnt > 0)
                {
                    string fname = @"G:\PARTHIBAN\samples\MyFirstExcelSheet_" + DateTime.Now.ToString("ddMMyyyy_hhmmss") + @".xlsx";
                    xlWorkSheet.SaveAs(fname);
                    xlApp.Quit();
                   Process.Start(fname);
                }
                else
                { 
                    MessageBox.Show("No records found");
                }
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public bool CreateReport2()
        {
            try
            {
                DBClass db = new DBClass();
                int globalcnt = 0;
                string Q1 = "SELECT Artcl_ArticleId,Artcl_Status,Proof_Pages,Artcl_ReceivedDt,Artcl_ScheduledDt FROM Article where Artcl_JrnlId IN (SELECT Jrnl_Id FROM Journal where Jrnl_PublID=99 )";
                string Q2 = "SELECT Article.Artcl_ArticleId,Article.Artcl_Status,Article.Proof_Pages,JR_Stage_Tran.JRST_ReceivedDt,JR_Stage_Tran.JRST_ScheduledDt,JR_Stage_Tran.JRST_JRS_ID FROM JR_Stage_Tran inner JOIN JR_Main  on  JRST_JRM_ID= JRM_Id INNER JOIN Article on Artcl_ArticleId=JR_Main.JRM_ArticleID  where  JR_Stage_Tran.JRST_JRM_ID IN (SELECT JRM_Id FROM JR_Main where JRM_JournalID IN(SELECT Jrnl_Id FROM Journal where Jrnl_PublID=99))";             


                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q2, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rows = ds.Tables[0].Rows;
                Xl.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                Xl.Workbook xlWorkBook;
                Xl.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                System.Collections.ArrayList JRlist = new System.Collections.ArrayList();
                System.Collections.ArrayList JRStagelist = new System.Collections.ArrayList();
                System.Collections.ArrayList Addedlist = new System.Collections.ArrayList();
                //***
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Name = "Comp. Report - WIP";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "Sr. No.";
                xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                xlWorkSheet.Cells[1, 3] = "Article ID";
                xlWorkSheet.Cells[1, 4] = "Curr. Activity";
                xlWorkSheet.Cells[1, 5] = "Pages";
                xlWorkSheet.Cells[1, 6] = "Submission";
                xlWorkSheet.Cells[1, 7] = "Recd Date";
                xlWorkSheet.Cells[1, 8] = "Due Date";
                xlWorkSheet.Cells[1, 9] = "Type";
                xlWorkSheet.Cells[1, 10] = "Date to be sent";
                xlWorkSheet.Cells[1, 11] = "Reasons for Delay";
                int i = 2, k = 1, rcnt =0;
                globalcnt += rows.Count;
                for (int j = 0; j < rows.Count; j++)
                {
                    if ((Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value == "") || (Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value.ToUpper() == "SAMPLE")) continue;
                    if (Addedlist.Contains(rows[j][0].ToString())) continue;
                    string stage = "";
                    if (Regex.IsMatch(rows[j][5].ToString(), "^(35|36|37|78|97|98)$")) stage = "CorrectionsToVendor";
                    else if (Regex.IsMatch(rows[j][5].ToString(), "^(33|34)$")) stage = "RevisionsToVendor";
                    else if (Regex.IsMatch(rows[j][5].ToString(), "^(43)$")) stage = "PaginationToVendor";
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value;
                    if (!JRlist.Contains(Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value))
                    {
                        JRlist.Add(Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value);
                    }
                    JRStagelist.Add(Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value + '|' + stage);
                    xlWorkSheet.Cells[i, 3] = Regex.Match(rows[j][0].ToString(), @"^\d+").Groups[0].Value;
                    xlWorkSheet.Cells[i, 4] = rows[j][1].ToString();
                    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 6] = stage;
                    xlWorkSheet.Cells[i, 7] = rows[j][3].ToString();
                    xlWorkSheet.Cells[i, 8] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 9] = "";
                    xlWorkSheet.Cells[i, 10] = "";
                    xlWorkSheet.Cells[i, 11] = "";
                    Addedlist.Add(rows[j][0].ToString());
                    i++;
                    k++;
                    rcnt++;
                }              
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                rows = ds.Tables[0].Rows;
                for (int j = 0; j < rows.Count; j++)
                {
                    if ((Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value == "") || (Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value.ToUpper() == "SAMPLE")) continue;
                   if(Addedlist.Contains(rows[j][0].ToString())) continue;
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value;
                    if (!JRlist.Contains(Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value))
                    {
                        JRlist.Add(Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value);
                    }
                    xlWorkSheet.Cells[i, 3] = Regex.Match(rows[j][0].ToString(), @"^\d+").Groups[0].Value;
                    xlWorkSheet.Cells[i, 4] = rows[j][1].ToString();
                    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 6] = "Starter";
                    JRStagelist.Add(Regex.Match(rows[j][0].ToString(), @"[A-Za-z]+$").Groups[0].Value + "|Starter");
                    xlWorkSheet.Cells[i, 7] = rows[j][3].ToString();
                    xlWorkSheet.Cells[i, 8] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 9] = "";
                    xlWorkSheet.Cells[i, 10] = "";
                    xlWorkSheet.Cells[i, 11] = "";
                    Addedlist.Add(rows[j][0].ToString());
                    i++;
                    k++;
                    rcnt++;
                }              
                globalcnt += rows.Count;
                Xl.Range chartRange = xlWorkSheet.get_Range("A1", "K" + (rcnt + 1));
                CellAlignment(chartRange);
                chartRange = xlWorkSheet.get_Range("A1", "K1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                //***                
                if (JRlist.Count > 0)
                {
                    xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.Add();
                    xlWorkSheet.Name = "Summary";
                    //xlWorkSheet.Cells.NumberFormat = "@";
                    xlWorkSheet.Cells[3, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[3, 2] = "Column Labels";
                    xlWorkSheet.Cells[4, 1] = "Row Labels";
                    xlWorkSheet.Cells[4, 2] = "Starter";
                    xlWorkSheet.Cells[4, 3] = "CorrectionsToVendor";
                    xlWorkSheet.Cells[4, 4] = "RevisionsToVendor";
                    xlWorkSheet.Cells[4, 5] = "PaginationToVendor";
                    xlWorkSheet.Cells[4, 6] = "Grand Total";
                    chartRange = xlWorkSheet.get_Range("A3", "F4");
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                    i = 5;
                    foreach (string JID in JRlist)
                    {
                        int S = 0, CV = 0, RV = 0, PV = 0;
                        foreach (string Stage in JRStagelist)
                        {
                            if (Stage.Contains(JID))
                            {
                                if (Stage.Contains("Starter"))
                                {
                                    S++;
                                }
                                else if (Stage.Contains("CorrectionsToVendor"))
                                {
                                    CV++;
                                }
                                else if (Stage.Contains("RevisionsToVendor"))
                                {
                                    RV++;
                                }
                                else if (Stage.Contains("PaginationToVendor"))
                                {
                                    PV++;
                                }
                            }
                        }
                        xlWorkSheet.Cells[i, 1] = JID;
                        if (S > 0)
                        {
                            xlWorkSheet.Cells[i, 2] = S;
                        }
                        else xlWorkSheet.Cells[i, 2] = "";
                        if (CV > 0)
                        {
                            xlWorkSheet.Cells[i, 3] = CV;
                        }
                        else xlWorkSheet.Cells[i, 3] = "";
                        if (RV > 0)
                        {
                            xlWorkSheet.Cells[i, 4] = RV;
                        }
                        else xlWorkSheet.Cells[i, 4] = "";
                        if (PV > 0)
                        {
                            xlWorkSheet.Cells[i, 5] = PV;
                        }
                        else xlWorkSheet.Cells[i, 5] = "";
                        //chartRange = xlWorkSheet.Cells.get_Range(xlWorkSheet.Cells[i, 6]);
                        xlWorkSheet.Cells[i, 6] = string.Format("=SUM(B{0}:E{0})", i);
                        i++;
                    }
                    xlWorkSheet.Cells[i, 1] = "Grand Total";
                    xlWorkSheet.Cells[i, 2] = string.Format("=SUM(B5:B{0})", i - 1);
                    xlWorkSheet.Cells[i, 3] = string.Format("=SUM(C5:C{0})", i - 1);
                    xlWorkSheet.Cells[i, 4] = string.Format("=SUM(D5:D{0})", i - 1);
                    xlWorkSheet.Cells[i, 5] = string.Format("=SUM(E5:E{0})", i - 1);
                    xlWorkSheet.Cells[i, 6] = string.Format("=SUM(F5:F{0})", i - 1);
                    chartRange = xlWorkSheet.get_Range("A4", "F" + i);
                    CellAlignment(chartRange);
                    chartRange = xlWorkSheet.get_Range("A" + i, "F" + i);
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                }              
                if (globalcnt > 0)
                {
                    string fname = @"G:\PARTHIBAN\samples\MyFirstExcelSheet_" + DateTime.Now.ToString("ddMMyyyy_hhmmss") + @".xlsx";
                    xlWorkSheet.SaveAs(fname);
                    xlApp.Quit();
                    System.Diagnostics.Process.Start(fname);
                }
                else
                {
                    MessageBox.Show("No records found");
                }
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public bool CreateReport3_Final1()
        {
            try
            {
                foreach (Process P in Process.GetProcessesByName("EXCEL"))
                {
                    try
                    {
                        P.Kill();
                    }
                    catch (Exception e) { }
                }
                DBClass db = new DBClass();              
                //string Q1= " WITH T1 AS (SELECT DISTINCT Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID, CASE WHEN isnull(Proof_Pages,0)<>0 THEN Proof_Pages WHEN Artcl_TextFolios IS NULL OR Artcl_TextFolios='' THEN 0 ELSE Artcl_TextFolios END AS [Pages], Artcl_UploadedDt AS Artcl_UploadedDt, Artcl_Status AS Status, Artcl_ReceivedDt, Artcl_ScheduledDt  FROM Article,  Journal WHERE Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=99)  , T2 as (SELECT MAX(JRST_ID) AS maxid,JRA_ArticleID AS ArticleID FROM JR_Articles, JR_Main, JR_Stage_Tran, Journal where JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_ID AND JRM_JournalID=Jrnl_Id AND Jrnl_PublID=99 AND JRA_ArticleID IN(SELECT ISNULL(Artcl_ArticleId,'') AS ArticleID FROM Article,  Journal WHERE Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=99) GROUP BY JRA_ArticleID) SELECT DISTINCT t1.JrnlID, t1.ArticleID, t1.[Pages],  CASE WHEN t2.maxid IS NULL THEN T1.Status ELSE PrcsMst_Name END AS 'Last Stage Status',CASE WHEN t2.maxid IS NULL  THEN 'Starter'  WHEN  CHARINDEX('AU Corr',JRS_StageName)>0 THEN 'CorrectionsToVendor' WHEN  CHARINDEX('TU Corr',JRS_StageName)>0 THEN 'RevisionsToVendor' WHEN  CHARINDEX('Final Web',JRS_StageName)>0 THEN 'PaginationToVendor' WHEN  CHARINDEX('PAP',JRS_StageName)>0 THEN 'PaginationToVendor' ELSE '' END as 'Last Stage',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ReceivedDt ELSE JR_Stage_Tran.JRST_ReceivedDt END AS 'ReceivedDate',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ScheduledDt ELSE JR_Stage_Tran.JRST_ScheduledDt END AS 'DueDate',     Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end as UploadDt from T1 Left outer join T2 on t1.ArticleID=t2.ArticleID LEFT OUTER JOIN JR_Stage_Tran on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages ON JR_Stage_Tran.JRST_JRS_ID=JR_Stages.JRS_ID LEFT OUTER JOIN ProcessMst ON JRST_Status=PrcsMst_Id   order by ArticleID";
                string Q1="WITH T1 AS (SELECT DISTINCT Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID, CASE WHEN isnull(Proof_Pages,0)<>0 THEN Proof_Pages WHEN Artcl_TextFolios IS NULL OR Artcl_TextFolios='' THEN 0 ELSE Artcl_TextFolios END AS [Pages], Artcl_UploadedDt AS Artcl_UploadedDt, Artcl_Status AS Status, Artcl_ReceivedDt, Artcl_ScheduledDt  FROM Article,  Journal WHERE Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=99)  , T2 as (SELECT MAX(JRST_ID) AS maxid,JRA_ArticleID AS ArticleID FROM JR_Articles, JR_Main, JR_Stage_Tran, Journal where JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_ID AND JRM_JournalID=Jrnl_Id AND Jrnl_PublID=99 AND JRA_ArticleID IN(SELECT ISNULL(Artcl_ArticleId,'') AS ArticleID FROM Article,  Journal WHERE Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=99) GROUP BY JRA_ArticleID) SELECT DISTINCT t1.JrnlID, t1.ArticleID, t1.[Pages],  CASE WHEN t2.maxid IS NULL THEN T1.Status ELSE PrcsMst_Name END AS 'Last Stage Status',CASE WHEN t2.maxid IS NULL  THEN 'Starter'  WHEN  CHARINDEX('AU Corr',JRS_StageName)>0 THEN 'CorrectionsToVendor' WHEN  CHARINDEX('TU Corr',JRS_StageName)>0 THEN 'RevisionsToVendor' WHEN  CHARINDEX('Final Web',JRS_StageName)>0 THEN 'PaginationToVendor' WHEN  CHARINDEX('PAP',JRS_StageName)>0 THEN 'PaginationToVendor' ELSE '' END as 'Last Stage',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ReceivedDt ELSE JR_Stage_Tran.JRST_ReceivedDt END AS 'ReceivedDate',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ScheduledDt ELSE JR_Stage_Tran.JRST_ScheduledDt END AS 'DueDate',     Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end as UploadDt from T1 Left outer join T2 on t1.ArticleID=t2.ArticleID LEFT OUTER JOIN JR_Stage_Tran on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages ON JR_Stage_Tran.JRST_JRS_ID=JR_Stages.JRS_ID LEFT OUTER JOIN ProcessMst ON JRST_Status=PrcsMst_Id WHERE Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end=''  order by ArticleID";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rows = ds.Tables[0].Rows;
                Xl.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                Xl.Workbook xlWorkBook;
                Xl.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                System.Collections.ArrayList JRlist = new System.Collections.ArrayList();
                System.Collections.ArrayList JRStagelist = new System.Collections.ArrayList();               
                //***
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Name = "Comp. Report - WIP";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "Sr. No.";
                xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                xlWorkSheet.Cells[1, 3] = "Article ID";
                xlWorkSheet.Cells[1, 4] = "Curr. Activity";
                xlWorkSheet.Cells[1, 5] = "Pages";
                xlWorkSheet.Cells[1, 6] = "Submission";
                xlWorkSheet.Cells[1, 7] = "Recd Date";
                xlWorkSheet.Cells[1, 8] = "Due Date";
                xlWorkSheet.Cells[1, 9] = "Type";
                xlWorkSheet.Cells[1, 10] = "Date to be sent";
                xlWorkSheet.Cells[1, 11] = "Reasons for Delay";
                int i = 2, k = 1, rcnt = 0;
                if (rows.Count == 0)
                {
                    MessageBox.Show("No records found");
                    return true;
                }          
                for (int j = 0; j < rows.Count; j++)
                {
                    if ((rows[j][0].ToString() == "") || (rows[j][0].ToString() == "SAMPLE")||(Regex.Match(rows[j][1].ToString(), @"^\d+").Groups[0].Value=="")) continue;                   
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                    if (!JRlist.Contains(rows[j][0].ToString()))
                    {
                        JRlist.Add(rows[j][0].ToString());
                    }                  
                    xlWorkSheet.Cells[i, 3] = Regex.Match(rows[j][1].ToString(), @"^\d+").Groups[0].Value;
                    xlWorkSheet.Cells[i, 4] = rows[j][3].ToString();
                    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();
                    xlWorkSheet.Cells[i, 8] = rows[j][6].ToString();
                    string reason = "";
                    try
                    {
                        if (Convert.ToDateTime(rows[j][6].ToString()).ToString("dd-MM-yyyy") != Convert.ToDateTime(rows[j][7].ToString()).ToString("dd-MM-yyyy"))
                        {
                            reason = "Delay";
                        }
                        else reason = "On-time";

                    }
                    catch (Exception e) { reason = ""; }
                    xlWorkSheet.Cells[i, 9] = reason;
                    xlWorkSheet.Cells[i, 10] = "";
                    xlWorkSheet.Cells[i, 11] = "";
                    JRStagelist.Add(rows[j][0].ToString() + '|' + rows[j][3].ToString() + '|' +rows[j][4].ToString() + '|' + Convert.ToDateTime(rows[j][6].ToString()).ToString("dd-MMM-yyyy") + '|' + reason);
                    i++;
                    k++;
                    rcnt++;
                }              
                Xl.Range chartRange = xlWorkSheet.get_Range("A1", "K" + (rcnt + 1));
                CellAlignment(chartRange);
                chartRange = xlWorkSheet.get_Range("A1", "K1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                //***                
                if (JRlist.Count > 0)
                {
                    char[] alphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
                    xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.Add();
                    xlWorkSheet.Name = "Summary";
                    chartRange = xlWorkSheet.get_Range("A1" , "C1" );
                    chartRange.Merge();
                    chartRange.Font.Bold = true;
                    chartRange.Font.Size = 16;
                    xlWorkSheet.Cells[1, 1] = "Summary as of " + DateTime.Now.ToString("dd-MM-yyyy hh:mm");
                    //xlWorkSheet.Cells.NumberFormat = "@";
                    xlWorkSheet.Cells[3, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[3, 2] = "Column Labels";
                    xlWorkSheet.Cells[4, 1] = "Row Labels";
                    xlWorkSheet.Cells[4, 2] = "Starter";
                    xlWorkSheet.Cells[4, 3] = "CorrectionsToVendor";
                    xlWorkSheet.Cells[4, 4] = "RevisionsToVendor";
                    xlWorkSheet.Cells[4, 5] = "PaginationToVendor";
                    xlWorkSheet.Cells[4, 6] = "Grand Total";
                    chartRange = xlWorkSheet.get_Range("A3", "F4");
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                    i = 5;
                    foreach (string JID in JRlist)
                    {
                        int S = 0, CV = 0, RV = 0, PV = 0;
                        foreach (string Stage in JRStagelist)
                        {
                            if (Stage.Contains(JID))
                            {
                                if (Stage.Contains("Starter"))
                                {
                                    S++;
                                }
                                else if (Stage.Contains("CorrectionsToVendor"))
                                {
                                    CV++;
                                }
                                else if (Stage.Contains("RevisionsToVendor"))
                                {
                                    RV++;
                                }
                                else if (Stage.Contains("PaginationToVendor"))
                                {
                                    PV++;
                                }
                            }
                        }
                        xlWorkSheet.Cells[i, 1] = JID;
                        if (S > 0)
                        {
                            xlWorkSheet.Cells[i, 2] = S;
                        }
                        else xlWorkSheet.Cells[i, 2] = "";
                        if (CV > 0)
                        {
                            xlWorkSheet.Cells[i, 3] = CV;
                        }
                        else xlWorkSheet.Cells[i, 3] = "";
                        if (RV > 0)
                        {
                            xlWorkSheet.Cells[i, 4] = RV;
                        }
                        else xlWorkSheet.Cells[i, 4] = "";
                        if (PV > 0)
                        {
                            xlWorkSheet.Cells[i, 5] = PV;
                        }
                        else xlWorkSheet.Cells[i, 5] = "";
                        //chartRange = xlWorkSheet.Cells.get_Range(xlWorkSheet.Cells[i, 6]);
                        xlWorkSheet.Cells[i, 6] = string.Format("=SUM(B{0}:E{0})", i);
                        i++;
                    }
                    xlWorkSheet.Cells[i, 1] = "Grand Total";
                    xlWorkSheet.Cells[i, 2] = string.Format("=SUM(B5:B{0})", i - 1);
                    xlWorkSheet.Cells[i, 3] = string.Format("=SUM(C5:C{0})", i - 1);
                    xlWorkSheet.Cells[i, 4] = string.Format("=SUM(D5:D{0})", i - 1);
                    xlWorkSheet.Cells[i, 5] = string.Format("=SUM(E5:E{0})", i - 1);
                    xlWorkSheet.Cells[i, 6] = string.Format("=SUM(F5:F{0})", i - 1);
                    chartRange = xlWorkSheet.get_Range("A4", "F" + i);
                    CellAlignment(chartRange);
                    chartRange = xlWorkSheet.get_Range("A" + i, "F" + i);
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A1", "F" + i);
                    chartRange.Columns.AutoFit();
                    //***
                    int start = i + 3;
                    xlWorkSheet.Cells[start, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[start, 2] = "Column Labels";
                    xlWorkSheet.Cells[start + 1, 1] = "Row Labels";
                    int t=2;
                    foreach (string JID in JRlist)
                    {
                        xlWorkSheet.Cells[start + 1,t ] = JID;
                        t++;
                    }
                    xlWorkSheet.Cells[start + 1, t] = "Grand Total";
                    xlWorkSheet.Cells[start + 2, 1] = "On-time";
                    xlWorkSheet.Cells[start + 3, 1] = "Starter";
                    xlWorkSheet.Cells[start + 4, 1] = "CorrectionsToVendor";
                    xlWorkSheet.Cells[start + 5, 1] = "RevisionsToVendor";
                    xlWorkSheet.Cells[start + 6, 1] = "PaginationToVendor";
                    xlWorkSheet.Cells[start + 7, 1] = "Delay";
                    xlWorkSheet.Cells[start + 8, 1] = "Starter";
                    xlWorkSheet.Cells[start + 9, 1] = "CorrectionsToVendor";
                    xlWorkSheet.Cells[start + 10, 1] = "RevisionsToVendor";
                    xlWorkSheet.Cells[start + 11, 1] = "PaginationToVendor";
                    xlWorkSheet.Cells[start + 12, 1] = "(blank)";
                    xlWorkSheet.Cells[start + 13, 1] = "Starter";
                    xlWorkSheet.Cells[start + 14, 1] = "CorrectionsToVendor";
                    xlWorkSheet.Cells[start + 15, 1] = "RevisionsToVendor";
                    xlWorkSheet.Cells[start + 16, 1] = "PaginationToVendor";
                    xlWorkSheet.Cells[start + 17, 1] = "Grand Total";
                    for (int ccnt = 2; ccnt <=16; ccnt++)
                    {
                        xlWorkSheet.Cells[start + ccnt, t] = string.Format("=SUM(B{0}:{1}{0})", start + ccnt,alphabets[JRlist.Count]);
                    }    
                    i = 2;
                    foreach (string JID in JRlist)
                    {
                        int o=0,d=0,b=0,OS = 0, OCV = 0, ORV = 0, OPV = 0, DS = 0, DCV = 0,DRV = 0, DPV = 0,BS = 0, BCV = 0, BRV = 0, BPV = 0; ;
                        foreach (string Stage in JRStagelist)
                        {
                            if (Stage.Contains(JID))
                            {
                                if (Stage.Contains("On-time"))
                                {
                                    o++;
                                    if (Stage.Contains("Starter"))
                                    {
                                        OS++;
                                    }
                                    else if (Stage.Contains("CorrectionsToVendor"))
                                    {
                                        OCV++;
                                    }
                                    else if (Stage.Contains("RevisionsToVendor"))
                                    {
                                        ORV++;
                                    }
                                    else if (Stage.Contains("PaginationToVendor"))
                                    {
                                        OPV++;
                                    }
                                }
                                else if (Stage.Contains("Delay"))
                                {
                                    d++;
                                    if (Stage.Contains("Starter"))
                                    {
                                        DS++;
                                    }
                                    else if (Stage.Contains("CorrectionsToVendor"))
                                    {
                                        DCV++;
                                    }
                                    else if (Stage.Contains("RevisionsToVendor"))
                                    {
                                        DRV++;
                                    }
                                    else if (Stage.Contains("PaginationToVendor"))
                                    {
                                        DPV++;
                                    }
                                }
                                else if (Stage.Contains(""))
                                {
                                    b++;
                                    if (Stage.Contains("Starter"))
                                    {
                                        BS++;
                                    }
                                    else if (Stage.Contains("CorrectionsToVendor"))
                                    {
                                        BCV++;
                                    }
                                    else if (Stage.Contains("RevisionsToVendor"))
                                    {
                                        BRV++;
                                    }
                                    else if (Stage.Contains("PaginationToVendor"))
                                    {
                                        BPV++;
                                    }
                                }                             
                            }
                        }                      
                        if (o > 0) xlWorkSheet.Cells[start + 2,i] = o;                       
                        else xlWorkSheet.Cells[start + 2,i] = "";
                        if (OS > 0) xlWorkSheet.Cells[start + 3, i] = OS;
                        else xlWorkSheet.Cells[start + 3, i] = "";
                        if (OCV > 0) xlWorkSheet.Cells[start + 4,i] = OCV;                       
                        else xlWorkSheet.Cells[start + 4,i] = "";
                        if (ORV > 0)xlWorkSheet.Cells[start + 5,i] = ORV;                        
                        else xlWorkSheet.Cells[start + 5,i] = "";
                        if (OPV > 0)xlWorkSheet.Cells[start + 6,i] = OPV;
                        else xlWorkSheet.Cells[start + 6,i] = "";
                        if (d > 0) xlWorkSheet.Cells[start + 7,i] = d;
                        else xlWorkSheet.Cells[start + 7,i] = "";
                        if (DS > 0) xlWorkSheet.Cells[start + 8, i] = DS;
                        else xlWorkSheet.Cells[start + 8, i] = "";
                        if (DCV > 0) xlWorkSheet.Cells[start + 9,i] = DCV;
                        else xlWorkSheet.Cells[start + 9,i] = "";
                        if (DRV > 0) xlWorkSheet.Cells[start + 10,i] = DRV;
                        else xlWorkSheet.Cells[start + 10,i] = "";
                        if (DPV > 0) xlWorkSheet.Cells[start + 11,i] = DPV;
                        else xlWorkSheet.Cells[start + 11,i] = "";
                        if (b > 0) xlWorkSheet.Cells[start + 12, i] = b;
                        else xlWorkSheet.Cells[start + 12,i] = "";
                        if (b > 0) xlWorkSheet.Cells[start + 13, i] = BS;
                        else xlWorkSheet.Cells[start + 13, i] = "";
                        if (BCV > 0) xlWorkSheet.Cells[start + 14,i] = BCV;
                        else xlWorkSheet.Cells[start + 14,i] = "";
                        if (ORV > 0) xlWorkSheet.Cells[start + 15,i] = BRV;
                        else xlWorkSheet.Cells[start + 15,i] = "";
                        if (BPV > 0) xlWorkSheet.Cells[start + 16,i] = BPV;
                        else xlWorkSheet.Cells[start + 16,i] = "";
                        //xlWorkSheet.Cells[start + 16, i] = string.Format("=SUM(B{0}:B{0})", i);
                        i++;
                    }
                    for (int ccnt = 2; ccnt <= JRlist.Count + 2; ccnt++)
                    {
                        xlWorkSheet.Cells[start + 17, ccnt] = string.Format("={0}" + (start + 2) + "+{0}" + (start + 2 + 5) + "+{0}" + (start + 2+ 5+ 5), alphabets[ccnt - 1].ToString());
                  
                    }
                    chartRange = xlWorkSheet.get_Range("A" + start , alphabets[JRlist.Count + 1].ToString() + (start + 1));
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start +1) , alphabets[JRlist.Count + 1].ToString() + (start + 17));
                    CellAlignment(chartRange);                    
                    chartRange = xlWorkSheet.get_Range("A1", alphabets[JRlist.Count + 1].ToString() + start + 17);
                    chartRange.Columns.AutoFit();
                    //chartRange = xlWorkSheet.get_Range("A" + (start + 17), alphabets[JRlist.Count + 1].ToString() + start + 17);
                    //chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                    //***
                    start = start + 17 + 3;
                    xlWorkSheet.Cells[start, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[start, 2] = "Column Labels";
                    xlWorkSheet.Cells[start + 1, 1] = "Row Labels";
                    xlWorkSheet.Cells[start + 1, 2] = "Starter";
                    xlWorkSheet.Cells[start + 1, 3] = "CorrectionsToVendor";
                    xlWorkSheet.Cells[start + 1, 4] = "RevisionsToVendor";
                    xlWorkSheet.Cells[start + 1, 5] = "PaginationToVendor";
                    xlWorkSheet.Cells[start + 1, 6] = "(blank)";
                    xlWorkSheet.Cells[start + 1, 7] = "Grand Total";
                    t=2;
                    System.Collections.ArrayList CurrActlist = new System.Collections.ArrayList();
                    foreach (string Stage in JRStagelist)
                    {
                        if (!(CurrActlist.Contains(Stage.Split('|')[1])))
                        {
                            int s1 = 1, c1 = 1, r1 = 1, p1 = 1, b1 = 1;
                            CurrActlist.Add(Stage.Split('|')[1]);
                            xlWorkSheet.Cells[start + t, 1] = Stage.Split('|')[1];    
                            foreach (string Stage1 in JRStagelist)
                             {
                                if(Stage1.Contains('|' + Stage.Split('|')[1] + '|'))
                                    if (Stage1.Contains("Starter"))
                                    {         
                                        xlWorkSheet.Cells[start + t, 2] = s1;
                                        s1++;
                                    }
                                    else if (Stage1.Contains("CorrectionsToVendor"))
                                    {                       
                                        xlWorkSheet.Cells[start + t, 3] =c1;
                                        c1++;
                                    }
                                    else if (Stage1.Contains("RevisionsToVendor"))
                                    {                      
                                        xlWorkSheet.Cells[start + t, 4] = r1;
                                        r1++;
                                    }
                                    else if (Stage1.Contains("PaginationToVendor"))
                                    {                           
                                        xlWorkSheet.Cells[start + t, 5] = p1;
                                        p1++;
                                    }
                                    else if (Stage1.Split('|')[2]=="")
                                    {  
                                        xlWorkSheet.Cells[start + t, 6] =b1;
                                        b1++;
                                    }
                            }
                            t++;
                        }                       
                    }
                    //t = 3 + 1 + CurrActlist.Count;
                    xlWorkSheet.Cells[start + t, 1] = "Grand Total";
                    for (int ccnt = 2; ccnt <= CurrActlist.Count+2; ccnt++)
                    {
                        xlWorkSheet.Cells[start + ccnt, 7] = string.Format("=SUM(B{0}:F{0})", start + ccnt);
                    }
                    for (int ccnt = 2; ccnt <= 7; ccnt++)
                    {
                        string s0 = alphabets[ccnt - 1].ToString(), s1 = (start + 2).ToString(), s2 = (start + t - 1).ToString();
                        xlWorkSheet.Cells[start + t, ccnt] = string.Format("=SUM({0}{1}:{0}{2})", s0,s1,s2);                        
                    }
                    chartRange = xlWorkSheet.get_Range("A" + start, "G" + (start + 1));
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + 1), "G" + (start + t));
                    CellAlignment(chartRange);
                    chartRange = xlWorkSheet.get_Range("A1", "G" + start + t);
                    chartRange.Columns.AutoFit();
                    //chartRange = xlWorkSheet.get_Range("A" + (start + t), "G" + start + t);
                    //chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                    //***
                    start = start + 3 + 3 + CurrActlist.Count;
                    i = 1;
                    xlWorkSheet.Cells[start, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[start, 2] = "Column Labels";
                    xlWorkSheet.Cells[start + 1, 1] = "Row Labels";

                    foreach (string curr in CurrActlist)
                    {
                        xlWorkSheet.Cells[start + 1, i + 1] = curr;
                        i++;
                    }                  
                    t = 2;
                    foreach (string jid in JRlist)
                    {
                        xlWorkSheet.Cells[start + t, 1] = jid;
                        foreach (string Stage1 in JRStagelist)
                        {
                            if (Stage1.Contains(jid + '|'))
                                for (int cc = 0; cc < CurrActlist.Count; cc++)
                                {
                                    string curr = CurrActlist[cc].ToString();
                                    if (Stage1.Contains('|' + curr + '|'))
                                    {
                                        if ((xlWorkSheet.Cells[start + t, cc + 2] as Xl.Range).Value == null) xlWorkSheet.Cells[start + t, cc + 2] = 1;
                                        else xlWorkSheet.Cells[start + t, cc + 2] = Convert.ToDouble((xlWorkSheet.Cells[start + t, cc + 2] as Xl.Range).Value) + 1.0;

                                    }
                                }
                        }
                        t++;
                    }
                    xlWorkSheet.Cells[start + 1, i + 1] = "Grand Total";
                    xlWorkSheet.Cells[start + t, 1] = "Grand Total";                    
                    for (int ccnt = 2; ccnt <= JRlist.Count + 2 ; ccnt++)
                    {
                        xlWorkSheet.Cells[start + ccnt, CurrActlist.Count + 2] = string.Format("=SUM(B{0}:{1}{0})", start + ccnt, alphabets[CurrActlist.Count].ToString());
                    }
                    for (int ccnt = 2; ccnt <= CurrActlist.Count + 2; ccnt++)
                    {
                        string s0 = alphabets[ccnt - 1].ToString(), s1 = (start + 2).ToString(), s2 = (start + t - 1).ToString();
                        xlWorkSheet.Cells[start + t, ccnt] = string.Format("=SUM({0}{1}:{0}{2})", s0, s1, s2);
                    }
                    chartRange = xlWorkSheet.get_Range("A" + start, alphabets[CurrActlist.Count+1].ToString() + (start + 1));
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + 1), alphabets[CurrActlist.Count+1].ToString() + (start + t));
                    CellAlignment(chartRange);
                    chartRange = xlWorkSheet.get_Range("A1", alphabets[CurrActlist.Count+1].ToString() + start + t);
                    chartRange.Columns.AutoFit();
                    //chartRange = xlWorkSheet.get_Range("A" + (start + t), alphabets[CurrActlist.Count + 1].ToString() + start + t);
                    //chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                    //***
                    start = start + 3 + 3 + JRlist.Count;
                    System.Collections.ArrayList CurrDatlist = new System.Collections.ArrayList();
                    xlWorkSheet.Cells[start, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[start, 2] = "Column Labels";
                    xlWorkSheet.Cells[start + 1, 1] = "Row Labels";
                    foreach (string Stage in JRStagelist)
                    {
                        if (!(CurrDatlist.Contains(Stage.Split('|')[3])))
                        {                           
                            CurrDatlist.Add(Stage.Split('|')[3]);
                        }
                    }
                    i = 2;
                    foreach (string curr in CurrDatlist)
                    {
                        xlWorkSheet.Cells[start + 1, i] = curr;
                        i++;
                    }
                    t = 2;
                    foreach (string jid in JRlist)
                    {
                        xlWorkSheet.Cells[start + t, 1] = jid;
                        foreach (string Stage1 in JRStagelist)
                        {
                            if (Stage1.Contains(jid + '|'))
                                for (int cc = 0; cc < CurrDatlist.Count; cc++)
                                {
                                    string curr = CurrDatlist[cc].ToString();
                                    if (Stage1.Contains('|' + curr + '|'))
                                    {
                                        if ((xlWorkSheet.Cells[start + t, cc + 2] as Xl.Range).Value == null) xlWorkSheet.Cells[start + t, cc + 2] = 1;
                                        else xlWorkSheet.Cells[start + t, cc + 2] = Convert.ToDouble((xlWorkSheet.Cells[start + t, cc + 2] as Xl.Range).Value) + 1.0;

                                    }
                                }
                        }
                        t++;
                    }
                    xlWorkSheet.Cells[start + 1, i] = "Grand Total";
                    xlWorkSheet.Cells[start + t, 1] = "Grand Total";
                    for (int ccnt = 2; ccnt <= JRlist.Count + 2; ccnt++)
                    {
                        xlWorkSheet.Cells[start + ccnt, CurrDatlist.Count + 2] = string.Format("=SUM(B{0}:{1}{0})", start + ccnt, alphabets[CurrDatlist.Count].ToString());
                    }
                    for (int ccnt = 2; ccnt <= CurrDatlist.Count + 2; ccnt++)
                    {
                        string s0 = alphabets[ccnt - 1].ToString(), s1 = (start + 2).ToString(), s2 = (start + t - 1).ToString();
                        xlWorkSheet.Cells[start + t, ccnt] = string.Format("=SUM({0}{1}:{0}{2})", s0, s1, s2);
                    }
                    chartRange = xlWorkSheet.get_Range("A" + start, alphabets[CurrDatlist.Count + 1].ToString() + (start + 1));
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + 1), alphabets[CurrDatlist.Count + 1].ToString() + (start + t));
                    CellAlignment(chartRange);
                    chartRange = xlWorkSheet.get_Range("A1", alphabets[CurrDatlist.Count + 1].ToString() + start + t);
                    chartRange.Columns.AutoFit();
                    //chartRange = xlWorkSheet.get_Range("A" + (start + t), alphabets[CurrDatlist.Count + 1].ToString() + start + t);
                    //chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                    //***
                    start = start + 3 + 3 + JRlist.Count;
                    xlWorkSheet.Cells[start, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[start, 2] = "Column Labels";
                    xlWorkSheet.Cells[start + 1, 1] = "Row Labels";
                    xlWorkSheet.Cells[start + 1, 2] = "Starter";
                    xlWorkSheet.Cells[start + 1, 3] = "CorrectionsToVendor";
                    xlWorkSheet.Cells[start + 1, 4] = "RevisionsToVendor";
                    xlWorkSheet.Cells[start + 1, 5] = "PaginationToVendor";
                    xlWorkSheet.Cells[start + 1, 6] = "(blank)";
                    xlWorkSheet.Cells[start + 1, 7] = "Grand Total";
                    t = 2;
                    CurrDatlist.Clear();
                    foreach (string Stage in JRStagelist)
                    {
                        if (!(CurrDatlist.Contains(Stage.Split('|')[3])))
                        {
                            int s1 = 1, c1 = 1, r1 = 1, p1 = 1, b1 = 1;
                            CurrDatlist.Add(Stage.Split('|')[3]);
                            xlWorkSheet.Cells[start + t, 1] = Stage.Split('|')[3];
                            foreach (string Stage1 in JRStagelist)
                            {
                                if (Stage1.Contains('|' + Stage.Split('|')[3] + '|'))
                                    if (Stage1.Contains("Starter"))
                                    {
                                        xlWorkSheet.Cells[start + t, 2] = s1;
                                        s1++;
                                    }
                                    else if (Stage1.Contains("CorrectionsToVendor"))
                                    {
                                        xlWorkSheet.Cells[start + t, 3] = c1;
                                        c1++;
                                    }
                                    else if (Stage1.Contains("RevisionsToVendor"))
                                    {
                                        xlWorkSheet.Cells[start + t, 4] = r1;
                                        r1++;
                                    }
                                    else if (Stage1.Contains("PaginationToVendor"))
                                    {
                                        xlWorkSheet.Cells[start + t, 5] = p1;
                                        p1++;
                                    }
                                    else if (Stage1.Split('|')[2] == "")
                                    {
                                        xlWorkSheet.Cells[start + t, 6] = b1;
                                        b1++;
                                    }
                            }
                            t++;
                        }
                    }
                    //t = 3 + 1 + CurrActlist.Count;
                    xlWorkSheet.Cells[start + t, 1] = "Grand Total";
                    for (int ccnt = 2; ccnt <= CurrDatlist.Count + 2; ccnt++)
                    {
                        xlWorkSheet.Cells[start + ccnt, 7] = string.Format("=SUM(B{0}:F{0})", start + ccnt);
                    }
                    for (int ccnt = 2; ccnt <= 7; ccnt++)
                    {
                        string s0 = alphabets[ccnt - 1].ToString(), s1 = (start + 2).ToString(), s2 = (start + t - 1).ToString();
                        xlWorkSheet.Cells[start + t, ccnt] = string.Format("=SUM({0}{1}:{0}{2})", s0, s1, s2);
                    }
                    chartRange = xlWorkSheet.get_Range("A" + start, "G" + (start + 1));
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + 1), "G" + (start + t));
                    CellAlignment(chartRange);
                    chartRange = xlWorkSheet.get_Range("A1", "G" + start + t);
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + t), "G" + (start + t));
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbGray;
                    //***     
                }          
                    string fname = @"G:\PARTHIBAN\samples\AIP_Excel_Report_" + DateTime.Now.ToString("ddMMyyyy_hhmmss") + @".xlsx";
                    xlWorkSheet.SaveAs(fname);
                    xlApp.Quit();
                    System.Diagnostics.Process.Start(fname);            
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public bool CreateReport4()
        {
            try
            {               
                foreach (Process P in Process.GetProcessesByName("EXCEL"))
                {
                    try
                    {
                        P.Kill();
                    }
                    catch (Exception e) { }
                }
                DBClass db = new DBClass();
                //string Q1 = "WITH T1 AS (SELECT DISTINCT Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID, CASE WHEN isnull(Proof_Pages,0)<>0 THEN Proof_Pages WHEN Artcl_TextFolios IS NULL OR Artcl_TextFolios='' THEN 0 ELSE Artcl_TextFolios END AS [Pages], Artcl_UploadedDt AS Artcl_UploadedDt, Artcl_Status AS Status, Artcl_ReceivedDt, Artcl_ScheduledDt  FROM Article,  Journal WHERE Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=99)  , T2 as (SELECT MAX(JRST_ID) AS maxid,JRA_ArticleID AS ArticleID FROM JR_Articles, JR_Main, JR_Stage_Tran, Journal where JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_ID AND JRM_JournalID=Jrnl_Id AND Jrnl_PublID=99 AND JRA_ArticleID IN(SELECT ISNULL(Artcl_ArticleId,'') AS ArticleID FROM Article,  Journal WHERE Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=99) GROUP BY JRA_ArticleID) SELECT DISTINCT t1.JrnlID, t1.ArticleID, t1.[Pages],  CASE WHEN t2.maxid IS NULL THEN T1.Status ELSE PrcsMst_Name END AS 'Last Stage Status',CASE WHEN t2.maxid IS NULL  THEN 'Starter'  WHEN  CHARINDEX('AU Corr',JRS_StageName)>0 THEN 'CorrectionsToVendor' ELSE '' END as 'Last Stage',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ReceivedDt ELSE JR_Stage_Tran.JRST_ReceivedDt END AS 'ReceivedDate',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ScheduledDt ELSE JR_Stage_Tran.JRST_ScheduledDt END AS 'DueDate',     Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end as UploadDt from T1 Left outer join T2 on t1.ArticleID=t2.ArticleID LEFT OUTER JOIN JR_Stage_Tran on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages ON JR_Stage_Tran.JRST_JRS_ID=JR_Stages.JRS_ID LEFT OUTER JOIN ProcessMst ON JRST_Status=PrcsMst_Id WHERE Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end=''  order by ArticleID";
                string Q1 = "WITH T1 AS (SELECT DISTINCT Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID, CASE WHEN isnull(Proof_Pages,0)<>0 THEN Proof_Pages WHEN Artcl_TextFolios IS NULL OR Artcl_TextFolios='' THEN 0 ELSE Artcl_TextFolios END AS [Pages], Artcl_UploadedDt AS Artcl_UploadedDt, Artcl_Status AS Status, Artcl_ReceivedDt, Artcl_DueDtCats, Artcl_ScheduledDt,Artcl_PII  FROM Article,  Journal WHERE Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=99)  , T2 as (SELECT MAX(JRST_ID) AS maxid,JRA_ArticleID AS ArticleID FROM JR_Articles, JR_Main, JR_Stage_Tran, Journal where JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_ID AND JRM_JournalID=Jrnl_Id AND Jrnl_PublID=99 AND JRA_ArticleID IN(SELECT ISNULL(Artcl_ArticleId,'') AS ArticleID FROM Article,  Journal WHERE Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=99) GROUP BY JRA_ArticleID) SELECT DISTINCT t1.JrnlID, t1.ArticleID, t1.[Pages],  CASE WHEN t2.maxid IS NULL THEN T1.Status ELSE PrcsMst_Name END AS 'Last Stage Status',CASE WHEN t2.maxid IS NULL  THEN 'Starter'  WHEN  (CHARINDEX('AU Corr',JRS_StageName)>0 or CHARINDEX('TU Corr',JRS_StageName)>0 and t1.Artcl_PII='JPS_Workflow') THEN 'CorrectionsToVendor' ELSE '' END as 'Last Stage',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ReceivedDt ELSE JR_Stage_Tran.JRST_ReceivedDt END AS 'ReceivedDate',CASE WHEN t2.maxid IS NULL THEN (CASE WHEN T1.Artcl_DueDtCats IS NULL then T1.Artcl_ScheduledDt else T1.Artcl_DueDtCats END) ELSE (CASE WHEN JR_Stage_Tran.JRST_DueDtCats IS NULL then JR_Stage_Tran.JRST_ScheduledDt ELSE JR_Stage_Tran.JRST_DueDtCats END)  END AS 'DueDate',     Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end as UploadDt,isnull(t1.Artcl_PII,'') as Workflow  from T1 Left outer join T2 on t1.ArticleID=t2.ArticleID LEFT OUTER JOIN JR_Stage_Tran on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages ON JR_Stage_Tran.JRST_JRS_ID=JR_Stages.JRS_ID LEFT OUTER JOIN ProcessMst ON JRST_Status=PrcsMst_Id WHERE Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end=''  order by ArticleID";
                //with UL
                //string Q1 = "WITH T1 AS (SELECT DISTINCT Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID, CASE WHEN isnull(Proof_Pages,0)<>0 THEN Proof_Pages WHEN Artcl_TextFolios IS NULL OR Artcl_TextFolios='' THEN 0 ELSE Artcl_TextFolios END AS [Pages], Artcl_UploadedDt AS Artcl_UploadedDt, Artcl_Status AS Status, Artcl_ReceivedDt, Artcl_ScheduledDt  FROM Article,  Journal WHERE Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=99)  , T2 as (SELECT MAX(JRST_ID) AS maxid,JRA_ArticleID AS ArticleID FROM JR_Articles, JR_Main, JR_Stage_Tran, Journal where JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_ID AND JRM_JournalID=Jrnl_Id AND Jrnl_PublID=99 AND JRA_ArticleID IN(SELECT ISNULL(Artcl_ArticleId,'') AS ArticleID FROM Article,  Journal WHERE Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=99) GROUP BY JRA_ArticleID) SELECT DISTINCT t1.JrnlID, t1.ArticleID, t1.[Pages],  CASE WHEN t2.maxid IS NULL THEN T1.Status ELSE PrcsMst_Name END AS 'Last Stage Status',CASE WHEN t2.maxid IS NULL  THEN 'Starter'  WHEN  CHARINDEX('AU Corr',JRS_StageName)>0 THEN 'CorrectionsToVendor' ELSE '' END as 'Last Stage',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ReceivedDt ELSE JR_Stage_Tran.JRST_ReceivedDt END AS 'ReceivedDate',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ScheduledDt ELSE JR_Stage_Tran.JRST_ScheduledDt END AS 'DueDate',     Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end as UploadDt from T1 Left outer join T2 on t1.ArticleID=t2.ArticleID LEFT OUTER JOIN JR_Stage_Tran on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages ON JR_Stage_Tran.JRST_JRS_ID=JR_Stages.JRS_ID LEFT OUTER JOIN ProcessMst ON JRST_Status=PrcsMst_Id order by ArticleID";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rows = ds.Tables[0].Rows;
                Xl.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                Xl.Workbook xlWorkBook;
                Xl.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                System.Collections.ArrayList JRlist = new System.Collections.ArrayList();
                System.Collections.ArrayList JRStagelist = new System.Collections.ArrayList();
                //***
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Name = "Comp. Report - WIP";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "Sr. No.";
                xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                xlWorkSheet.Cells[1, 3] = "Article ID";
                xlWorkSheet.Cells[1, 4] = "Curr. Activity";
                xlWorkSheet.Cells[1, 5] = "Pages";
                xlWorkSheet.Cells[1, 6] = "Submission";
                xlWorkSheet.Cells[1, 7] = "Recd Date";
                xlWorkSheet.Cells[1, 8] = "Due Date";
                xlWorkSheet.Cells[1, 9] = "Type";
                xlWorkSheet.Cells[1, 10] = "Date to be sent";
                xlWorkSheet.Cells[1, 11] = "Reasons for Delay";
                int i = 2, k = 1, rcnt = 0;
                 CommonClass Cs = new CommonClass();
                if (rows.Count == 0)
                {
                    //MessageBox.Show("No records found");
                    Cs.SendMail("", "Dear Team,<Br/><Br/>No records found", "AIP", false, "AIP_Report");
                    return true;
                }
                for (int j = 0; j < rows.Count; j++)
                {
                    if ((rows[j][0].ToString() == "") || (rows[j][0].ToString() == "SAMPLE") || (Regex.Match(rows[j][1].ToString(), @"^\d+").Groups[0].Value == "" && rows[j][8].ToString() == "") || (rows[j][4].ToString() == ""))
                    {
                        continue;
                    }                  
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                    if (!JRlist.Contains(rows[j][0].ToString()))
                    {
                        JRlist.Add(rows[j][0].ToString());
                    }
                    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString(); //Regex.Match(rows[j][1].ToString(), @"^\d+").Groups[0].Value;
                    if (rows[j][3].ToString().ToUpper() == "CE-QC" || rows[j][3].ToString().ToUpper() == "CE")
                    {
                        xlWorkSheet.Cells[i, 4] = "CE";
                    }else if (rows[j][3].ToString().ToUpper() == "QC")
                    {
                        xlWorkSheet.Cells[i, 4] = "QC";
                    }
                    else if (rows[j][3].ToString().ToUpper() == "INCOMPLETE")
                    {
                        xlWorkSheet.Cells[i, 4] = "PR2";
                    }
                    else
                    {
                        xlWorkSheet.Cells[i, 4] = rows[j][3].ToString();
                    }                   
                    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();
                    xlWorkSheet.Cells[i, 8] = rows[j][6].ToString();
                    string reason = "";
                    try
                    {
                        if (Convert.ToDateTime(rows[j][6].ToString()).ToString("dd-MM-yyyy") != Convert.ToDateTime(rows[j][7].ToString()).ToString("dd-MM-yyyy"))
                        {
                            reason = "Delay";
                        }
                        else reason = "On-time";

                    }
                    catch (Exception e) { reason = "On-time"; }
                    xlWorkSheet.Cells[i, 9] = reason;
                    xlWorkSheet.Cells[i, 10] = "";
                    xlWorkSheet.Cells[i, 11] = "";
                    if (rows[j][3].ToString().ToUpper() == "CE-QC" || rows[j][3].ToString().ToUpper() == "CE")
                    {
                        JRStagelist.Add(rows[j][0].ToString() + "|CE|" + rows[j][4].ToString() + '|' + Convert.ToDateTime(rows[j][6].ToString()).ToString("dd-MMM-yyyy") + '|' + reason);
                    }
                    else if (rows[j][3].ToString().ToUpper() == "QC")
                    {
                        JRStagelist.Add(rows[j][0].ToString() + "|QC|" + rows[j][4].ToString() + '|' + Convert.ToDateTime(rows[j][6].ToString()).ToString("dd-MMM-yyyy") + '|' + reason);
                    }
                    else if (rows[j][3].ToString().ToUpper() == "INCOMPLETE")
                    {
                        JRStagelist.Add(rows[j][0].ToString() + "|PR2|" + rows[j][4].ToString() + '|' + Convert.ToDateTime(rows[j][6].ToString()).ToString("dd-MMM-yyyy") + '|' + reason);
                    }

                    else
                    {
                        JRStagelist.Add(rows[j][0].ToString() + '|' + rows[j][3].ToString() + '|' + rows[j][4].ToString() + '|' + Convert.ToDateTime(rows[j][6].ToString()).ToString("dd-MMM-yyyy") + '|' + reason);
                    }
                    i++;
                    k++;
                    rcnt++;
                }
                Xl.Range chartRange = xlWorkSheet.get_Range("A1", "K" + (rcnt + 1));
                CellAlignment(chartRange);
                chartRange = xlWorkSheet.get_Range("A1", "K1");
                chartRange.Font.Bold = true;
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                //***                
                if (JRlist.Count > 0)
                {
                    char[] alphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
                    xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.Add();
                    xlWorkSheet.Name = "Summary";
                    chartRange = xlWorkSheet.get_Range("A1", "C1");
                    chartRange.Merge();
                    chartRange.Font.Bold = true;
                    chartRange.Font.Size = 16;
                    xlWorkSheet.Cells[1, 1] = "Summary as of " + DateTime.Now.ToString("dd-MM-yyyy hh:mm");
                    //xlWorkSheet.Cells.NumberFormat = "@";
                    xlWorkSheet.Cells[3, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[3, 2] = "Column Labels";
                    xlWorkSheet.Cells[4, 1] = "Row Labels";
                    xlWorkSheet.Cells[4, 2] = "Starter";
                    xlWorkSheet.Cells[4, 3] = "CorrectionsToVendor";
                    //xlWorkSheet.Cells[4, 4] = "RevisionsToVendor";
                    //xlWorkSheet.Cells[4, 5] = "PaginationToVendor";
                    xlWorkSheet.Cells[4, 4] = "Grand Total";
                    chartRange = xlWorkSheet.get_Range("A3", "D4");
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    i = 5;                 
                    foreach (string JID in JRlist)
                    {
                        int S = 0, CV = 0;
                        foreach (string Stage in JRStagelist)
                        {
                            if (Stage.Contains(JID))
                            {
                                if (Stage.Contains("Starter"))
                                {
                                    S++;
                                }
                                else if (Stage.Contains("CorrectionsToVendor"))
                                {
                                    CV++;
                                }
                                //else if (Stage.Contains("RevisionsToVendor"))
                                //{
                                //    RV++;
                                //}
                                //else if (Stage.Contains("PaginationToVendor"))
                                //{
                                //    PV++;
                                //}
                            }
                        }
                        xlWorkSheet.Cells[i, 1] = JID;
                        if (S > 0)
                        {
                            xlWorkSheet.Cells[i, 2] = S;
                        }
                        else xlWorkSheet.Cells[i, 2] = "";
                        if (CV > 0)
                        {
                            xlWorkSheet.Cells[i, 3] = CV;
                        }
                        else xlWorkSheet.Cells[i, 3] = "";
                        //if (RV > 0)
                        //{
                        //    xlWorkSheet.Cells[i, 4] = RV;
                        //}
                        //else xlWorkSheet.Cells[i, 4] = "";
                        //if (PV > 0)
                        //{
                        //    xlWorkSheet.Cells[i, 5] = PV;
                        //}
                        //else xlWorkSheet.Cells[i, 5] = "";
                        //chartRange = xlWorkSheet.Cells.get_Range(xlWorkSheet.Cells[i, 6]);
                        xlWorkSheet.Cells[i, 4] = string.Format("=SUM(B{0}:C{0})", i);
                        i++;
                    }
                    xlWorkSheet.Cells[i, 1] = "Grand Total";
                    xlWorkSheet.Cells[i, 2] = string.Format("=SUM(B5:B{0})", i - 1);
                    xlWorkSheet.Cells[i, 3] = string.Format("=SUM(C5:C{0})", i - 1);
                    xlWorkSheet.Cells[i, 4] = string.Format("=SUM(D5:D{0})", i - 1);
                    //xlWorkSheet.Cells[i, 5] = string.Format("=SUM(E5:E{0})", i - 1);
                    //xlWorkSheet.Cells[i, 6] = string.Format("=SUM(F5:F{0})", i - 1);
                    //chartRange = xlWorkSheet.get_Range("A4", "F" + i);
                    //CellAlignment(chartRange);
                    //chartRange = xlWorkSheet.get_Range("A" + i, "F" + i);
                    //chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    //chartRange.Columns.AutoFit();
                    //chartRange = xlWorkSheet.get_Range("A1", "F" + i);
                    //chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A4", "D" + i);
                    CellAlignment(chartRange);
                    chartRange = xlWorkSheet.get_Range("A" + i, "D" + i);
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A1", "D" + i);
                    chartRange.Columns.AutoFit();
                    //***
                    int start = i + 3;
                    xlWorkSheet.Cells[start, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[start, 2] = "Column Labels";
                    xlWorkSheet.Cells[start + 1, 1] = "Row Labels";
                    int t = 2;
                    foreach (string JID in JRlist)
                    {
                        xlWorkSheet.Cells[start + 1, t] = JID;
                        t++;
                    }
                    xlWorkSheet.Cells[start + 1, t] = "Grand Total";
                    xlWorkSheet.Cells[start + 2, 1] = "On-time";
                    xlWorkSheet.Cells[start + 3, 1] = "Starter";
                    xlWorkSheet.Cells[start + 4, 1] = "CorrectionsToVendor";
                    //xlWorkSheet.Cells[start + 5, 1] = "RevisionsToVendor";
                    //xlWorkSheet.Cells[start + 6, 1] = "PaginationToVendor";
                    //xlWorkSheet.Cells[start + 7, 1] = "Delay";
                    //xlWorkSheet.Cells[start + 8, 1] = "Starter";
                    //xlWorkSheet.Cells[start + 9, 1] = "CorrectionsToVendor";
                    //xlWorkSheet.Cells[start + 10, 1] = "RevisionsToVendor";
                    //xlWorkSheet.Cells[start + 11, 1] = "PaginationToVendor";
                    //xlWorkSheet.Cells[start + 12, 1] = "(blank)";
                    //xlWorkSheet.Cells[start + 13, 1] = "Starter";
                    //xlWorkSheet.Cells[start + 14, 1] = "CorrectionsToVendor";
                    //xlWorkSheet.Cells[start + 15, 1] = "RevisionsToVendor";
                    //xlWorkSheet.Cells[start + 16, 1] = "PaginationToVendor";
                    //xlWorkSheet.Cells[start + 17, 1] = "Grand Total";
                    xlWorkSheet.Cells[start + 5, 1] = "Starter";
                    xlWorkSheet.Cells[start + 6, 1] = "Query Hold";
                    xlWorkSheet.Cells[start + 7, 1] = "CorrectionsToVendor";
                    xlWorkSheet.Cells[start + 8, 1] = "Query Released on";
                    xlWorkSheet.Cells[start + 9, 1] = "<Stage>";
                    xlWorkSheet.Cells[start + 10, 1] = "Grand Total";
                    //for (int ccnt = 2; ccnt <= 16; ccnt++)
                    for (int ccnt = 2; ccnt <= 9; ccnt++)
                    {
                        xlWorkSheet.Cells[start + ccnt, t] = string.Format("=SUM(B{0}:{1}{0})", start + ccnt, alphabets[JRlist.Count]);
                    }
                    i = 2;
                    foreach (string JID in JRlist)
                    {
                        int o = 0,  OS = 0, OCV = 0, ORV = 0, OPV = 0 ;
                        foreach (string Stage in JRStagelist)
                        {
                            if (Stage.Contains(JID))
                            {
                                if (Stage.Contains("On-time"))
                                {
                                    o++;
                                    if (Stage.Contains("Starter"))
                                    {
                                        OS++;
                                    }
                                    else if (Stage.Contains("CorrectionsToVendor"))
                                    {
                                        OCV++;
                                    }
                                    //else if (Stage.Contains("RevisionsToVendor"))
                                    //{
                                    //    ORV++;
                                    //}
                                    //else if (Stage.Contains("PaginationToVendor"))
                                    //{
                                    //    OPV++;
                                    //}
                                }
                                //else if (Stage.Contains("Delay"))
                                //{
                                //    d++;
                                //    if (Stage.Contains("Starter"))
                                //    {
                                //        DS++;
                                //    }
                                //    else if (Stage.Contains("CorrectionsToVendor"))
                                //    {
                                //        DCV++;
                                //    }
                                //    else if (Stage.Contains("RevisionsToVendor"))
                                //    {
                                //        DRV++;
                                //    }
                                //    else if (Stage.Contains("PaginationToVendor"))
                                //    {
                                //        DPV++;
                                //    }
                                //}
                                //else if (Stage.Contains(""))
                                //{
                                //    b++;
                                //    if (Stage.Contains("Starter"))
                                //    {
                                //        BS++;
                                //    }
                                //    else if (Stage.Contains("CorrectionsToVendor"))
                                //    {
                                //        BCV++;
                                //    }
                                //    else if (Stage.Contains("RevisionsToVendor"))
                                //    {
                                //        BRV++;
                                //    }
                                //    else if (Stage.Contains("PaginationToVendor"))
                                //    {
                                //        BPV++;
                                //    }
                                //}
                            }
                        }
                        if (o > 0) xlWorkSheet.Cells[start + 2, i] = o;
                        else xlWorkSheet.Cells[start + 2, i] = "";
                        if (OS > 0) xlWorkSheet.Cells[start + 3, i] = OS;
                        else xlWorkSheet.Cells[start + 3, i] = "";
                        if (OCV > 0) xlWorkSheet.Cells[start + 4, i] = OCV;
                        else xlWorkSheet.Cells[start + 4, i] = "";
                        if (ORV > 0) xlWorkSheet.Cells[start + 5, i] = ORV;
                        else xlWorkSheet.Cells[start + 5, i] = "";
                        if (OPV > 0) xlWorkSheet.Cells[start + 6, i] = OPV;
                        else xlWorkSheet.Cells[start + 6, i] = "";
                        //if (d > 0) xlWorkSheet.Cells[start + 7, i] = d;
                        //else xlWorkSheet.Cells[start + 7, i] = "";
                        //if (DS > 0) xlWorkSheet.Cells[start + 8, i] = DS;
                        //else xlWorkSheet.Cells[start + 8, i] = "";
                        //if (DCV > 0) xlWorkSheet.Cells[start + 9, i] = DCV;
                        //else xlWorkSheet.Cells[start + 9, i] = "";
                        //if (DRV > 0) xlWorkSheet.Cells[start + 10, i] = DRV;
                        //else xlWorkSheet.Cells[start + 10, i] = "";
                        //if (DPV > 0) xlWorkSheet.Cells[start + 11, i] = DPV;
                        //else xlWorkSheet.Cells[start + 11, i] = "";
                        //if (b > 0) xlWorkSheet.Cells[start + 12, i] = b;
                        //else xlWorkSheet.Cells[start + 12, i] = "";
                        //if (b > 0) xlWorkSheet.Cells[start + 13, i] = BS;
                        //else xlWorkSheet.Cells[start + 13, i] = "";
                        //if (BCV > 0) xlWorkSheet.Cells[start + 14, i] = BCV;
                        //else xlWorkSheet.Cells[start + 14, i] = "";
                        //if (ORV > 0) xlWorkSheet.Cells[start + 15, i] = BRV;
                        //else xlWorkSheet.Cells[start + 15, i] = "";
                        //if (BPV > 0) xlWorkSheet.Cells[start + 16, i] = BPV;
                        //else xlWorkSheet.Cells[start + 16, i] = "";
                        //xlWorkSheet.Cells[start + 16, i] = string.Format("=SUM(B{0}:B{0})", i);
                        i++;
                    }
                    for (int ccnt = 2; ccnt <= JRlist.Count + 2; ccnt++)
                    {
                        //xlWorkSheet.Cells[start + 17, ccnt] = string.Format("={0}" + (start + 2) + "+{0}" + (start + 2 + 5) + "+{0}" + (start + 2 + 5 + 5), alphabets[ccnt - 1].ToString());
                        xlWorkSheet.Cells[start + 10, ccnt] = string.Format("={0}" + (start + 2) + "+{0}" + (start + 2 + 5) + "+{0}" + (start + 2 + 5 + 5), alphabets[ccnt - 1].ToString());

                    }
                    chartRange = xlWorkSheet.get_Range("A" + start, alphabets[JRlist.Count + 1].ToString() + (start + 1));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    chartRange.Columns.AutoFit();
                    //chartRange = xlWorkSheet.get_Range("A" + (start + 1), alphabets[JRlist.Count + 1].ToString() + (start + 17));
                    chartRange = xlWorkSheet.get_Range("A" + (start + 1), alphabets[JRlist.Count + 1].ToString() + (start + 10));
                    CellAlignment(chartRange);
                    //chartRange = xlWorkSheet.get_Range("A1", alphabets[JRlist.Count + 1].ToString() + start + 17);
                    chartRange = xlWorkSheet.get_Range("A1", alphabets[JRlist.Count + 1].ToString() + start + 10);
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + 10), alphabets[JRlist.Count + 1].ToString() + (start + 10));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    //***
                    //start = start + 17 + 3;
                    start = start + 10 + 3;
                    xlWorkSheet.Cells[start, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[start, 2] = "Column Labels";
                    xlWorkSheet.Cells[start + 1, 1] = "Row Labels";
                    xlWorkSheet.Cells[start + 1, 2] = "Starter";
                    xlWorkSheet.Cells[start + 1, 3] = "CorrectionsToVendor";
                    //xlWorkSheet.Cells[start + 1, 4] = "RevisionsToVendor";
                    //xlWorkSheet.Cells[start + 1, 5] = "PaginationToVendor";
                    xlWorkSheet.Cells[start + 1, 4] = "(blank)";
                    xlWorkSheet.Cells[start + 1, 5] = "Grand Total";
                    t = 2;
                    System.Collections.ArrayList CurrActlist = new System.Collections.ArrayList();
                    foreach (string Stage in JRStagelist)
                    {
                        if (!(CurrActlist.Contains(Stage.Split('|')[1])))
                        {
                            int s1 = 1, c1 = 1, r1 = 1, p1 = 1, b1 = 1;
                            CurrActlist.Add(Stage.Split('|')[1]);
                            xlWorkSheet.Cells[start + t, 1] = Stage.Split('|')[1];
                            foreach (string Stage1 in JRStagelist)
                            {
                                if (Stage1.Contains('|' + Stage.Split('|')[1] + '|'))
                                    if (Stage1.Contains("Starter"))
                                    {
                                        xlWorkSheet.Cells[start + t, 2] = s1;
                                        s1++;
                                    }
                                    else if (Stage1.Contains("CorrectionsToVendor"))
                                    {
                                        xlWorkSheet.Cells[start + t, 3] = c1;
                                        c1++;
                                    }
                                    //else if (Stage1.Contains("RevisionsToVendor"))
                                    //{
                                    //    xlWorkSheet.Cells[start + t, 4] = r1;
                                    //    r1++;
                                    //}
                                    //else if (Stage1.Contains("PaginationToVendor"))
                                    //{
                                    //    xlWorkSheet.Cells[start + t, 5] = p1;
                                    //    p1++;
                                    //}
                                    else if (Stage1.Split('|')[2] == "")
                                    {
                                        xlWorkSheet.Cells[start + t, 4] = b1;
                                        b1++;
                                    }
                            }
                            t++;
                        }
                    }
                    //t = 3 + 1 + CurrActlist.Count;
                    xlWorkSheet.Cells[start + t, 1] = "Grand Total";
                    for (int ccnt = 2; ccnt <= CurrActlist.Count + 2; ccnt++)
                    {
                        //xlWorkSheet.Cells[start + ccnt, 7] = string.Format("=SUM(B{0}:F{0})", start + ccnt);
                        xlWorkSheet.Cells[start + ccnt, 5] = string.Format("=SUM(B{0}:D{0})", start + ccnt);
                    }
                    for (int ccnt = 2; ccnt <= 5; ccnt++)
                    {
                        string s0 = alphabets[ccnt - 1].ToString(), s1 = (start + 2).ToString(), s2 = (start + t - 1).ToString();
                        xlWorkSheet.Cells[start + t, ccnt] = string.Format("=SUM({0}{1}:{0}{2})", s0, s1, s2);
                    }
                    chartRange = xlWorkSheet.get_Range("A" + start, "E" + (start + 1));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + 1), "E" + (start + t));
                    CellAlignment(chartRange);
                    chartRange = xlWorkSheet.get_Range("A1", "E" + start + t);
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + t), "E" + (start + t));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    //***
                    start = start + 3 + 3 + CurrActlist.Count;
                    i = 1;
                    xlWorkSheet.Cells[start, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[start, 2] = "Column Labels";
                    xlWorkSheet.Cells[start + 1, 1] = "Row Labels";

                    foreach (string curr in CurrActlist)
                    {
                        xlWorkSheet.Cells[start + 1, i + 1] = curr;
                        i++;
                    }
                    t = 2;
                    foreach (string jid in JRlist)
                    {
                        xlWorkSheet.Cells[start + t, 1] = jid;
                        foreach (string Stage1 in JRStagelist)
                        {
                            if (Stage1.Contains(jid + '|'))
                                for (int cc = 0; cc < CurrActlist.Count; cc++)
                                {
                                    string curr = CurrActlist[cc].ToString();
                                    if (Stage1.Contains('|' + curr + '|'))
                                    {
                                        if ((xlWorkSheet.Cells[start + t, cc + 2] as Xl.Range).Value == null) xlWorkSheet.Cells[start + t, cc + 2] = 1;
                                        else xlWorkSheet.Cells[start + t, cc + 2] = Convert.ToDouble((xlWorkSheet.Cells[start + t, cc + 2] as Xl.Range).Value) + 1.0;

                                    }
                                }
                        }
                        t++;
                    }
                    xlWorkSheet.Cells[start + 1, i + 1] = "Grand Total";
                    xlWorkSheet.Cells[start + t, 1] = "Grand Total";
                    for (int ccnt = 2; ccnt <= JRlist.Count + 2; ccnt++)
                    {
                        xlWorkSheet.Cells[start + ccnt, CurrActlist.Count + 2] = string.Format("=SUM(B{0}:{1}{0})", start + ccnt, alphabets[CurrActlist.Count].ToString());
                    }
                    for (int ccnt = 2; ccnt <= CurrActlist.Count + 2; ccnt++)
                    {
                        string s0 = alphabets[ccnt - 1].ToString(), s1 = (start + 2).ToString(), s2 = (start + t - 1).ToString();
                        xlWorkSheet.Cells[start + t, ccnt] = string.Format("=SUM({0}{1}:{0}{2})", s0, s1, s2);
                    }
                    chartRange = xlWorkSheet.get_Range("A" + start, alphabets[CurrActlist.Count + 1].ToString() + (start + 1));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + 1), alphabets[CurrActlist.Count + 1].ToString() + (start + t));
                    CellAlignment(chartRange);
                    chartRange = xlWorkSheet.get_Range("A1", alphabets[CurrActlist.Count + 1].ToString() + start + t);
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + t), alphabets[CurrActlist.Count + 1].ToString() + (start + t));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    //***
                    start = start + 3 + 3 + JRlist.Count;
                    System.Collections.ArrayList CurrDatlist = new System.Collections.ArrayList();
                    xlWorkSheet.Cells[start, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[start, 2] = "Column Labels";
                    xlWorkSheet.Cells[start + 1, 1] = "Row Labels";
                    foreach (string Stage in JRStagelist)
                    {
                        if (!(CurrDatlist.Contains(Stage.Split('|')[3])))
                        {
                            CurrDatlist.Add(Stage.Split('|')[3]);
                        }
                    }
                    i = 2;
                    foreach (string curr in CurrDatlist)
                    {
                        xlWorkSheet.Cells[start + 1, i] = curr;
                        i++;
                    }
                    t = 2;
                    foreach (string jid in JRlist)
                    {
                        xlWorkSheet.Cells[start + t, 1] = jid;
                        foreach (string Stage1 in JRStagelist)
                        {
                            if (Stage1.Contains(jid + '|'))
                                for (int cc = 0; cc < CurrDatlist.Count; cc++)
                                {
                                    string curr = CurrDatlist[cc].ToString();
                                    if (Stage1.Contains('|' + curr + '|'))
                                    {
                                        if ((xlWorkSheet.Cells[start + t, cc + 2] as Xl.Range).Value == null) xlWorkSheet.Cells[start + t, cc + 2] = 1;
                                        else xlWorkSheet.Cells[start + t, cc + 2] = Convert.ToDouble((xlWorkSheet.Cells[start + t, cc + 2] as Xl.Range).Value) + 1.0;

                                    }
                                }
                        }
                        t++;
                    }
                    xlWorkSheet.Cells[start + 1, i] = "Grand Total";
                    xlWorkSheet.Cells[start + t, 1] = "Grand Total";
                    for (int ccnt = 2; ccnt <= JRlist.Count + 2; ccnt++)
                    {
                        xlWorkSheet.Cells[start + ccnt, CurrDatlist.Count + 2] = string.Format("=SUM(B{0}:{1}{0})", start + ccnt, alphabets[CurrDatlist.Count].ToString());
                    }
                    for (int ccnt = 2; ccnt <= CurrDatlist.Count + 2; ccnt++)
                    {
                        string s0 = alphabets[ccnt - 1].ToString(), s1 = (start + 2).ToString(), s2 = (start + t - 1).ToString();
                        xlWorkSheet.Cells[start + t, ccnt] = string.Format("=SUM({0}{1}:{0}{2})", s0, s1, s2);
                    }
                    chartRange = xlWorkSheet.get_Range("A" + start, alphabets[CurrDatlist.Count + 1].ToString() + (start + 1));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + 1), alphabets[CurrDatlist.Count + 1].ToString() + (start + t));
                    CellAlignment(chartRange);
                    chartRange = xlWorkSheet.get_Range("A1", alphabets[CurrDatlist.Count + 1].ToString() + start + t);
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + t), alphabets[CurrDatlist.Count + 1].ToString() + (start + t));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    //***
                    start = start + 3 + 3 + JRlist.Count;
                    xlWorkSheet.Cells[start, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[start, 2] = "Column Labels";
                    xlWorkSheet.Cells[start + 1, 1] = "Row Labels";
                    xlWorkSheet.Cells[start + 1, 2] = "Starter";
                    xlWorkSheet.Cells[start + 1, 3] = "CorrectionsToVendor";
                    //xlWorkSheet.Cells[start + 1, 4] = "RevisionsToVendor";
                    //xlWorkSheet.Cells[start + 1, 5] = "PaginationToVendor";
                    xlWorkSheet.Cells[start + 1, 4] = "(blank)";
                    xlWorkSheet.Cells[start + 1, 5] = "Grand Total";
                    t = 2;
                    CurrDatlist.Clear();
                    foreach (string Stage in JRStagelist)
                    {
                        if (!(CurrDatlist.Contains(Stage.Split('|')[3])))
                        {
                            int s1 = 1, c1 = 1,  b1 = 1;
                            CurrDatlist.Add(Stage.Split('|')[3]);
                            xlWorkSheet.Cells[start + t, 1] = Stage.Split('|')[3];
                            foreach (string Stage1 in JRStagelist)
                            {
                                if (Stage1.Contains('|' + Stage.Split('|')[3] + '|'))
                                    if (Stage1.Contains("Starter"))
                                    {
                                        xlWorkSheet.Cells[start + t, 2] = s1;
                                        s1++;
                                    }
                                    else if (Stage1.Contains("CorrectionsToVendor"))
                                    {
                                        xlWorkSheet.Cells[start + t, 3] = c1;
                                        c1++;
                                    }
                                    //else if (Stage1.Contains("RevisionsToVendor"))
                                    //{
                                    //    xlWorkSheet.Cells[start + t, 4] = r1;
                                    //    r1++;
                                    //}
                                    //else if (Stage1.Contains("PaginationToVendor"))
                                    //{
                                    //    xlWorkSheet.Cells[start + t, 5] = p1;
                                    //    p1++;
                                    //}
                                    else if (Stage1.Split('|')[2] == "")
                                    {
                                        xlWorkSheet.Cells[start + t, 4] = b1;
                                        b1++;
                                    }
                            }
                            t++;
                        }
                    }
                    //t = 3 + 1 + CurrActlist.Count;
                    xlWorkSheet.Cells[start + t, 1] = "Grand Total";
                    for (int ccnt = 2; ccnt <= CurrDatlist.Count + 2; ccnt++)
                    {
                        xlWorkSheet.Cells[start + ccnt, 5] = string.Format("=SUM(B{0}:D{0})", start + ccnt);
                    }
                    for (int ccnt = 2; ccnt <= 5; ccnt++)
                    {
                        string s0 = alphabets[ccnt - 1].ToString(), s1 = (start + 2).ToString(), s2 = (start + t - 1).ToString();
                        xlWorkSheet.Cells[start + t, ccnt] = string.Format("=SUM({0}{1}:{0}{2})", s0, s1, s2);
                    }
                    chartRange = xlWorkSheet.get_Range("A" + start, "E" + (start + 1));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + 1), "E" + (start + t));
                    CellAlignment(chartRange);
                    chartRange = xlWorkSheet.get_Range("A1", "E" + (start + t));
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + t), "E" + (start + t));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    //***     
                }
                if(!(Directory.Exists(System.Environment.CurrentDirectory + @"\AIP_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\AIP_Report\");
                string fname = System.Environment.CurrentDirectory + @"\AIP_Report\AIP_Excel_Report_" + DateTime.Now.ToString("ddMMyyyy_hhmmss") + @".xlsx";
                xlWorkSheet.SaveAs(fname);
                xlApp.Quit();
                System.Threading.Thread.Sleep(5000);               
                Cs.SendMail("", "Dear Team,<Br/><Br/>Kindly find the attached today's report", "AIP", false, "AIP_Report", fname);
                System.Threading.Thread.Sleep(5000);
                //System.Diagnostics.Process.Start(fname);
                return true;
            }
            catch (Exception e)
            {
                MessageBox.Show("Error: " + e.Message + "\n" + e.StackTrace); 
                return false;
            }
        }

        public bool CreateReport()
        {
            try
            {
                foreach (Process P in Process.GetProcessesByName("EXCEL"))
                {
                    try
                    {
                        P.Kill();
                    }
                    catch (Exception e) { }
                }
                DBClass db = new DBClass();
                //string Q1 = "WITH T1 AS (SELECT DISTINCT Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID, CASE WHEN isnull(Proof_Pages,0)<>0 THEN Proof_Pages WHEN Artcl_TextFolios IS NULL OR Artcl_TextFolios='' THEN 0 ELSE Artcl_TextFolios END AS [Pages], Artcl_UploadedDt AS Artcl_UploadedDt, Artcl_Status AS Status, Artcl_ReceivedDt, Artcl_DueDtCats, Artcl_ScheduledDt,isnull(Artcl_PII,'') as Artcl_PII FROM Article,  Journal WHERE Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=99)  , T2 as (SELECT MAX(JRST_ID) AS maxid,JRA_ArticleID AS ArticleID FROM JR_Articles, JR_Main, JR_Stage_Tran, Journal where JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_ID AND JRM_JournalID=Jrnl_Id AND Jrnl_PublID=99 AND JRA_ArticleID IN(SELECT ISNULL(Artcl_ArticleId,'') AS ArticleID FROM Article,  Journal WHERE Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=99) GROUP BY JRA_ArticleID) SELECT DISTINCT t1.JrnlID, t1.ArticleID, t1.[Pages],  CASE WHEN t2.maxid IS NULL THEN T1.Status ELSE PrcsMst_Name END AS 'Last Stage Status',CASE WHEN t2.maxid IS NULL  THEN 'Starter'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0 and t1.Artcl_PII='') or (CHARINDEX('TU',JRS_StageName)>0 and t1.Artcl_PII='JPS_Workflow')) THEN 'CorrectionsToVendor'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0 and t1.Artcl_PII='JPS_Workflow') or (CHARINDEX('TU',JRS_StageName)>0 and t1.Artcl_PII='')) THEN 'RevisionsToVendor'  WHEN  CHARINDEX('Final Web',JRS_StageName)>0  THEN 'Finaldeliverables' ELSE '' END as 'Last Stage',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ReceivedDt ELSE JR_Stage_Tran.JRST_ReceivedDt END AS 'ReceivedDate',CASE WHEN t2.maxid IS NULL THEN (CASE WHEN T1.Artcl_DueDtCats IS NULL then T1.Artcl_ScheduledDt else T1.Artcl_DueDtCats END) ELSE (CASE WHEN JR_Stage_Tran.JRST_DueDtCats IS NULL then JR_Stage_Tran.JRST_ScheduledDt ELSE JR_Stage_Tran.JRST_DueDtCats END)  END AS 'DueDate',     Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end as UploadDt,isnull(t1.Artcl_PII,'') as Workflow  from T1 Left outer join T2 on t1.ArticleID=t2.ArticleID LEFT OUTER JOIN JR_Stage_Tran on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages ON JR_Stage_Tran.JRST_JRS_ID=JR_Stages.JRS_ID LEFT OUTER JOIN ProcessMst ON JRST_Status=PrcsMst_Id WHERE Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end=''  order by ArticleID";
                string Q1 = "SSP_AutoReport 5";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rows = ds.Tables[0].Rows;
                Xl.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                Xl.Workbook xlWorkBook;
                Xl.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                System.Collections.ArrayList JRlist = new System.Collections.ArrayList();
                System.Collections.ArrayList JRStagelist = new System.Collections.ArrayList();
                //***
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Name = "Comp. Report - WIP";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "Sr. No.";
                xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                xlWorkSheet.Cells[1, 3] = "Article ID";
                xlWorkSheet.Cells[1, 4] = "Curr. Activity";
                xlWorkSheet.Cells[1, 5] = "Pages";
                xlWorkSheet.Cells[1, 6] = "Submission";
                xlWorkSheet.Cells[1, 7] = "Recd Date";
                xlWorkSheet.Cells[1, 8] = "Due Date";
                xlWorkSheet.Cells[1, 9] = "Type";
                xlWorkSheet.Cells[1, 10] = "Date to be sent";
                xlWorkSheet.Cells[1, 11] = "Reasons for Delay";
                int i = 2, k = 1, rcnt = 0;
                CommonClass Cs = new CommonClass();
                if (rows.Count == 0)
                {
                    //MessageBox.Show("No records found");
                    Cs.SendMail("", "Dear Team,<Br/><Br/>No records found", "AIP", false, "AIP_Report");
                    return true;
                }
                for (int j = 0; j < rows.Count; j++)
                {
                    if ((rows[j][0].ToString() == "") || (rows[j][0].ToString() == "SAMPLE") || (Regex.Match(rows[j][1].ToString(), @"^\d+").Groups[0].Value == "" && rows[j][8].ToString() == "") || (rows[j][4].ToString() == ""))
                    {
                        continue;
                    }
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                    if (!JRlist.Contains(rows[j][0].ToString()))
                    {
                        JRlist.Add(rows[j][0].ToString());
                    }
                    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString(); //Regex.Match(rows[j][1].ToString(), @"^\d+").Groups[0].Value;
                    if (rows[j][3].ToString().ToUpper() == "CE-QC" || rows[j][3].ToString().ToUpper() == "CE")
                    {
                        xlWorkSheet.Cells[i, 4] = "CE";
                    }
                    else if (rows[j][3].ToString().ToUpper() == "QC")
                    {
                        xlWorkSheet.Cells[i, 4] = "QC";
                    }
                    else if (rows[j][3].ToString().ToUpper() == "INCOMPLETE")
                    {
                        xlWorkSheet.Cells[i, 4] = "PR2";
                    }
                    else
                    {
                        xlWorkSheet.Cells[i, 4] = rows[j][3].ToString();
                    }
                    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();
                    xlWorkSheet.Cells[i, 8] = rows[j][6].ToString();
                    string reason = "";
                    try
                    {
                        if (Convert.ToDateTime(rows[j][6].ToString()).ToString("dd-MM-yyyy") != Convert.ToDateTime(rows[j][7].ToString()).ToString("dd-MM-yyyy"))
                        {
                            reason = "Delay";
                        }
                        else reason = "On-time";

                    }
                    catch (Exception e) { reason = "On-time"; }
                    xlWorkSheet.Cells[i, 9] = reason;
                    xlWorkSheet.Cells[i, 10] = "";
                    xlWorkSheet.Cells[i, 11] = "";
                    if (rows[j][3].ToString().ToUpper() == "CE-QC" || rows[j][3].ToString().ToUpper() == "CE")
                    {
                        JRStagelist.Add(rows[j][0].ToString() + "|CE|" + rows[j][4].ToString() + '|' + Convert.ToDateTime(rows[j][6].ToString()).ToString("dd-MMM-yyyy") + '|' + reason);
                    }
                    else if (rows[j][3].ToString().ToUpper() == "QC")
                    {
                        JRStagelist.Add(rows[j][0].ToString() + "|QC|" + rows[j][4].ToString() + '|' + Convert.ToDateTime(rows[j][6].ToString()).ToString("dd-MMM-yyyy") + '|' + reason);
                    }
                    else if (rows[j][3].ToString().ToUpper() == "INCOMPLETE")
                    {
                        JRStagelist.Add(rows[j][0].ToString() + "|PR2|" + rows[j][4].ToString() + '|' + Convert.ToDateTime(rows[j][6].ToString()).ToString("dd-MMM-yyyy") + '|' + reason);
                    }

                    else
                    {
                        JRStagelist.Add(rows[j][0].ToString() + '|' + rows[j][3].ToString() + '|' + rows[j][4].ToString() + '|' + Convert.ToDateTime(rows[j][6].ToString()).ToString("dd-MMM-yyyy") + '|' + reason);
                    }
                    i++;
                    k++;
                    rcnt++;
                }
                Xl.Range chartRange = xlWorkSheet.get_Range("A1", "K" + (rcnt + 1));
                CellAlignment(chartRange);
                chartRange = xlWorkSheet.get_Range("A1", "K1");
                chartRange.Font.Bold = true;
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                //***                
                if (JRlist.Count > 0)
                {
                    char[] alphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
                    xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.Add();
                    xlWorkSheet.Name = "Summary";
                    chartRange = xlWorkSheet.get_Range("A1", "E1");
                    chartRange.Merge();
                    chartRange.Font.Bold = true;
                    chartRange.Font.Size = 16;
                    xlWorkSheet.Cells[1, 1] = "Summary as of " + DateTime.Now.ToString("dd-MM-yyyy hh:mm");
                    //xlWorkSheet.Cells.NumberFormat = "@";
                    xlWorkSheet.Cells[3, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[3, 2] = "Column Labels";
                    xlWorkSheet.Cells[4, 1] = "Row Labels";
                    xlWorkSheet.Cells[4, 2] = "Starter";
                    xlWorkSheet.Cells[4, 3] = "CorrectionsToVendor";
                    xlWorkSheet.Cells[4, 4] = "RevisionsToVendor";
                    xlWorkSheet.Cells[4, 5] = "Finaldeliverables";
                    xlWorkSheet.Cells[4, 6] = "Grand Total";
                    chartRange = xlWorkSheet.get_Range("A3", "F4");
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    i = 5;
                    foreach (string JID in JRlist)
                    {
                        int S = 0, CV = 0, RV = 0, PV = 0;
                        foreach (string Stage in JRStagelist)
                        {
                            if (Stage.Contains(JID))
                            {
                                if (Stage.Contains("Starter"))
                                {
                                    S++;
                                }
                                else if (Stage.Contains("CorrectionsToVendor"))
                                {
                                    CV++;
                                }
                                else if (Stage.Contains("RevisionsToVendor"))
                                {
                                    RV++;
                                }
                                else if (Stage.Contains("Finaldeliverables"))
                                {
                                    PV++;
                                }
                                //else
                                //{
                                //    MessageBox.Show("Error: \n" );
                                //}
                            }
                        }
                        xlWorkSheet.Cells[i, 1] = JID;
                        if (S > 0)
                        {
                            xlWorkSheet.Cells[i, 2] = S;
                        }
                        else xlWorkSheet.Cells[i, 2] = "";
                        if (CV > 0)
                        {
                            xlWorkSheet.Cells[i, 3] = CV;
                        }
                        else xlWorkSheet.Cells[i, 3] = "";
                        if (RV > 0)
                        {
                            xlWorkSheet.Cells[i, 4] = RV;
                        }
                        else xlWorkSheet.Cells[i, 4] = "";
                        if (PV > 0)
                        {
                            xlWorkSheet.Cells[i, 5] = PV;
                        }
                        else xlWorkSheet.Cells[i, 5] = "";
                        //chartRange = xlWorkSheet.Cells.get_Range(xlWorkSheet.Cells[i, 6]);
                        xlWorkSheet.Cells[i, 6] = string.Format("=SUM(B{0}:E{0})", i);
                        i++;
                    }
                    xlWorkSheet.Cells[i, 1] = "Grand Total";
                    xlWorkSheet.Cells[i, 2] = string.Format("=SUM(B5:B{0})", i - 1);
                    xlWorkSheet.Cells[i, 3] = string.Format("=SUM(C5:C{0})", i - 1);
                    xlWorkSheet.Cells[i, 4] = string.Format("=SUM(D5:D{0})", i - 1);
                    xlWorkSheet.Cells[i, 5] = string.Format("=SUM(E5:E{0})", i - 1);
                    xlWorkSheet.Cells[i, 6] = string.Format("=SUM(F5:F{0})", i - 1);
                    chartRange = xlWorkSheet.get_Range("A4", "F" + i);
                    CellAlignment(chartRange);
                    chartRange = xlWorkSheet.get_Range("A" + i, "F" + i);
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A1", "F" + i);
                    chartRange.Columns.AutoFit();
                    //chartRange = xlWorkSheet.get_Range("A4", "D" + i);
                    //CellAlignment(chartRange);
                    //chartRange = xlWorkSheet.get_Range("A" + i, "D" + i);
                    //chartRange.Font.Bold = true;
                    //chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    //chartRange.Columns.AutoFit();
                    //chartRange = xlWorkSheet.get_Range("A1", "D" + i);
                    //chartRange.Columns.AutoFit();
                    //***
                    int start = i + 3;
                    xlWorkSheet.Cells[start, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[start, 2] = "Column Labels";
                    xlWorkSheet.Cells[start + 1, 1] = "Row Labels";
                    int t = 2;
                    foreach (string JID in JRlist)
                    {
                        xlWorkSheet.Cells[start + 1, t] = JID;
                        t++;
                    }
                    xlWorkSheet.Cells[start + 1, t] = "Grand Total";
                    xlWorkSheet.Cells[start + 2, 1] = "On-time";
                    xlWorkSheet.Cells[start + 3, 1] = "Starter";
                    xlWorkSheet.Cells[start + 4, 1] = "CorrectionsToVendor";
                    xlWorkSheet.Cells[start + 5, 1] = "RevisionsToVendor";
                    xlWorkSheet.Cells[start + 6, 1] = "Finaldeliverables";
                    //xlWorkSheet.Cells[start + 7, 1] = "Delay";
                    //xlWorkSheet.Cells[start + 8, 1] = "Starter";
                    //xlWorkSheet.Cells[start + 9, 1] = "CorrectionsToVendor";
                    //xlWorkSheet.Cells[start + 10, 1] = "RevisionsToVendor";
                    //xlWorkSheet.Cells[start + 11, 1] = "PaginationToVendor";
                    //xlWorkSheet.Cells[start + 12, 1] = "(blank)";
                    //xlWorkSheet.Cells[start + 13, 1] = "Starter";
                    //xlWorkSheet.Cells[start + 14, 1] = "CorrectionsToVendor";
                    //xlWorkSheet.Cells[start + 15, 1] = "RevisionsToVendor";
                    //xlWorkSheet.Cells[start + 16, 1] = "PaginationToVendor";
                    //xlWorkSheet.Cells[start + 17, 1] = "Grand Total";
                    xlWorkSheet.Cells[start + 7, 1] = "Starter";
                    xlWorkSheet.Cells[start + 8, 1] = "Query Hold";
                    xlWorkSheet.Cells[start + 9, 1] = "CorrectionsToVendor";
                    xlWorkSheet.Cells[start + 10, 1] = "Query Released on";
                    xlWorkSheet.Cells[start + 11, 1] = "<Stage>";
                    xlWorkSheet.Cells[start + 12, 1] = "Grand Total";
                    //for (int ccnt = 2; ccnt <= 16; ccnt++)
                    for (int ccnt = 2; ccnt <= 11; ccnt++)
                    {
                        xlWorkSheet.Cells[start + ccnt, t] = string.Format("=SUM(B{0}:{1}{0})", start + ccnt, alphabets[JRlist.Count]);
                    }
                    i = 2;
                    foreach (string JID in JRlist)
                    {
                        int o = 0, OS = 0, OCV = 0, ORV = 0, OPV = 0;
                        foreach (string Stage in JRStagelist)
                        {
                            if (Stage.Contains(JID))
                            {
                                if (Stage.Contains("On-time"))
                                {
                                    o++;
                                    if (Stage.Contains("Starter"))
                                    {
                                        OS++;
                                    }
                                    else if (Stage.Contains("CorrectionsToVendor"))
                                    {
                                        OCV++;
                                    }
                                    else if (Stage.Contains("RevisionsToVendor"))
                                    {
                                        ORV++;
                                    }
                                    else if (Stage.Contains("Finaldeliverables"))
                                    {
                                        OPV++;
                                    }
                                }
                                //else if (Stage.Contains("Delay"))
                                //{
                                //    d++;
                                //    if (Stage.Contains("Starter"))
                                //    {
                                //        DS++;
                                //    }
                                //    else if (Stage.Contains("CorrectionsToVendor"))
                                //    {
                                //        DCV++;
                                //    }
                                //    else if (Stage.Contains("RevisionsToVendor"))
                                //    {
                                //        DRV++;
                                //    }
                                //    else if (Stage.Contains("PaginationToVendor"))
                                //    {
                                //        DPV++;
                                //    }
                                //}
                                //else if (Stage.Contains(""))
                                //{
                                //    b++;
                                //    if (Stage.Contains("Starter"))
                                //    {
                                //        BS++;
                                //    }
                                //    else if (Stage.Contains("CorrectionsToVendor"))
                                //    {
                                //        BCV++;
                                //    }
                                //    else if (Stage.Contains("RevisionsToVendor"))
                                //    {
                                //        BRV++;
                                //    }
                                //    else if (Stage.Contains("PaginationToVendor"))
                                //    {
                                //        BPV++;
                                //    }
                                //}
                            }
                        }
                        if (o > 0) xlWorkSheet.Cells[start + 2, i] = o;
                        else xlWorkSheet.Cells[start + 2, i] = "";
                        if (OS > 0) xlWorkSheet.Cells[start + 3, i] = OS;
                        else xlWorkSheet.Cells[start + 3, i] = "";
                        if (OCV > 0) xlWorkSheet.Cells[start + 4, i] = OCV;
                        else xlWorkSheet.Cells[start + 4, i] = "";
                        if (ORV > 0) xlWorkSheet.Cells[start + 5, i] = ORV;
                        else xlWorkSheet.Cells[start + 5, i] = "";
                        if (OPV > 0) xlWorkSheet.Cells[start + 6, i] = OPV;
                        else xlWorkSheet.Cells[start + 6, i] = "";
                        //if (d > 0) xlWorkSheet.Cells[start + 7, i] = d;
                        //else xlWorkSheet.Cells[start + 7, i] = "";
                        //if (DS > 0) xlWorkSheet.Cells[start + 8, i] = DS;
                        //else xlWorkSheet.Cells[start + 8, i] = "";
                        //if (DCV > 0) xlWorkSheet.Cells[start + 9, i] = DCV;
                        //else xlWorkSheet.Cells[start + 9, i] = "";
                        //if (DRV > 0) xlWorkSheet.Cells[start + 10, i] = DRV;
                        //else xlWorkSheet.Cells[start + 10, i] = "";
                        //if (DPV > 0) xlWorkSheet.Cells[start + 11, i] = DPV;
                        //else xlWorkSheet.Cells[start + 11, i] = "";
                        //if (b > 0) xlWorkSheet.Cells[start + 12, i] = b;
                        //else xlWorkSheet.Cells[start + 12, i] = "";
                        //if (b > 0) xlWorkSheet.Cells[start + 13, i] = BS;
                        //else xlWorkSheet.Cells[start + 13, i] = "";
                        //if (BCV > 0) xlWorkSheet.Cells[start + 14, i] = BCV;
                        //else xlWorkSheet.Cells[start + 14, i] = "";
                        //if (ORV > 0) xlWorkSheet.Cells[start + 15, i] = BRV;
                        //else xlWorkSheet.Cells[start + 15, i] = "";
                        //if (BPV > 0) xlWorkSheet.Cells[start + 16, i] = BPV;
                        //else xlWorkSheet.Cells[start + 16, i] = "";
                        //xlWorkSheet.Cells[start + 16, i] = string.Format("=SUM(B{0}:B{0})", i);
                        i++;
                    }
                    for (int ccnt = 2; ccnt <= JRlist.Count + 2; ccnt++)
                    {
                        //xlWorkSheet.Cells[start + 17, ccnt] = string.Format("={0}" + (start + 2) + "+{0}" + (start + 2 + 5) + "+{0}" + (start + 2 + 5 + 5), alphabets[ccnt - 1].ToString());
                        xlWorkSheet.Cells[start + 12, ccnt] = string.Format("={0}" + (start + 3) + "+{0}" + (start + 4) + "+{0}" + (start + 5) + "+{0}" + (start + 6), alphabets[ccnt - 1].ToString());

                    }
                    chartRange = xlWorkSheet.get_Range("A" + start, alphabets[JRlist.Count + 1].ToString() + (start + 1));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    chartRange.Columns.AutoFit();
                    //chartRange = xlWorkSheet.get_Range("A" + (start + 1), alphabets[JRlist.Count + 1].ToString() + (start + 17));
                    chartRange = xlWorkSheet.get_Range("A" + (start + 1), alphabets[JRlist.Count + 1].ToString() + (start + 12));
                    CellAlignment(chartRange);
                    //chartRange = xlWorkSheet.get_Range("A1", alphabets[JRlist.Count + 1].ToString() + start + 17);
                    chartRange = xlWorkSheet.get_Range("A1", alphabets[JRlist.Count + 1].ToString() + start + 12);
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + 10), alphabets[JRlist.Count + 1].ToString() + (start + 12));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    //***
                    //start = start + 17 + 3;
                    start = start + 12 + 3;
                    xlWorkSheet.Cells[start, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[start, 2] = "Column Labels";
                    xlWorkSheet.Cells[start + 1, 1] = "Row Labels";
                    xlWorkSheet.Cells[start + 1, 2] = "Starter";
                    xlWorkSheet.Cells[start + 1, 3] = "CorrectionsToVendor";
                    xlWorkSheet.Cells[start + 1, 4] = "RevisionsToVendor";
                    xlWorkSheet.Cells[start + 1, 5] = "Finaldeliverables";
                    xlWorkSheet.Cells[start + 1, 6] = "(blank)";
                    xlWorkSheet.Cells[start + 1, 7] = "Grand Total";
                    t = 2;
                    System.Collections.ArrayList CurrActlist = new System.Collections.ArrayList();
                    foreach (string Stage in JRStagelist)
                    {
                        if (!(CurrActlist.Contains(Stage.Split('|')[1])))
                        {
                            int s1 = 1, c1 = 1, r1 = 1, p1 = 1, b1 = 1;
                            CurrActlist.Add(Stage.Split('|')[1]);
                            xlWorkSheet.Cells[start + t, 1] = Stage.Split('|')[1];
                            foreach (string Stage1 in JRStagelist)
                            {
                                if (Stage1.Contains('|' + Stage.Split('|')[1] + '|'))
                                    if (Stage1.Contains("Starter"))
                                    {
                                        xlWorkSheet.Cells[start + t, 2] = s1;
                                        s1++;
                                    }
                                    else if (Stage1.Contains("CorrectionsToVendor"))
                                    {
                                        xlWorkSheet.Cells[start + t, 3] = c1;
                                        c1++;
                                    }
                                    else if (Stage1.Contains("RevisionsToVendor"))
                                    {
                                        xlWorkSheet.Cells[start + t, 4] = r1;
                                        r1++;
                                    }
                                    else if (Stage1.Contains("Finaldeliverables"))
                                    {
                                        xlWorkSheet.Cells[start + t, 5] = p1;
                                        p1++;
                                    }
                                    else if (Stage1.Split('|')[2] == "")
                                    {
                                        xlWorkSheet.Cells[start + t, 6] = b1;
                                        b1++;
                                    }
                            }
                            t++;
                        }
                    }
                    //t = 3 + 1 + CurrActlist.Count;
                    xlWorkSheet.Cells[start + t, 1] = "Grand Total";
                    for (int ccnt = 2; ccnt <= CurrActlist.Count + 2; ccnt++)
                    {
                        xlWorkSheet.Cells[start + ccnt, 7] = string.Format("=SUM(B{0}:F{0})", start + ccnt);
                        //xlWorkSheet.Cells[start + ccnt, 5] = string.Format("=SUM(B{0}:D{0})", start + ccnt);
                    }
                    for (int ccnt = 2; ccnt <= 7; ccnt++)
                    {
                        string s0 = alphabets[ccnt - 1].ToString(), s1 = (start + 2).ToString(), s2 = (start + t - 1).ToString();
                        xlWorkSheet.Cells[start + t, ccnt] = string.Format("=SUM({0}{1}:{0}{2})", s0, s1, s2);
                    }
                    chartRange = xlWorkSheet.get_Range("A" + start, "G" + (start + 1));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + 1), "G" + (start + t));
                    CellAlignment(chartRange);
                    chartRange = xlWorkSheet.get_Range("A1", "G" + start + t);
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + t), "G" + (start + t));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    //***
                    start = start + 3 + 3 + CurrActlist.Count;
                    i = 1;
                    xlWorkSheet.Cells[start, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[start, 2] = "Column Labels";
                    xlWorkSheet.Cells[start + 1, 1] = "Row Labels";

                    foreach (string curr in CurrActlist)
                    {
                        xlWorkSheet.Cells[start + 1, i + 1] = curr;
                        i++;
                    }
                    t = 2;
                    foreach (string jid in JRlist)
                    {
                        xlWorkSheet.Cells[start + t, 1] = jid;
                        foreach (string Stage1 in JRStagelist)
                        {
                            if (Stage1.Contains(jid + '|'))
                                for (int cc = 0; cc < CurrActlist.Count; cc++)
                                {
                                    string curr = CurrActlist[cc].ToString();
                                    if (Stage1.Contains('|' + curr + '|'))
                                    {
                                        if ((xlWorkSheet.Cells[start + t, cc + 2] as Xl.Range).Value == null) xlWorkSheet.Cells[start + t, cc + 2] = 1;
                                        else xlWorkSheet.Cells[start + t, cc + 2] = Convert.ToDouble((xlWorkSheet.Cells[start + t, cc + 2] as Xl.Range).Value) + 1.0;

                                    }
                                }
                        }
                        t++;
                    }
                    xlWorkSheet.Cells[start + 1, i + 1] = "Grand Total";
                    xlWorkSheet.Cells[start + t, 1] = "Grand Total";
                    for (int ccnt = 2; ccnt <= JRlist.Count + 2; ccnt++)
                    {
                        xlWorkSheet.Cells[start + ccnt, CurrActlist.Count + 2] = string.Format("=SUM(B{0}:{1}{0})", start + ccnt, alphabets[CurrActlist.Count].ToString());
                    }
                    for (int ccnt = 2; ccnt <= CurrActlist.Count + 2; ccnt++)
                    {
                        string s0 = alphabets[ccnt - 1].ToString(), s1 = (start + 2).ToString(), s2 = (start + t - 1).ToString();
                        xlWorkSheet.Cells[start + t, ccnt] = string.Format("=SUM({0}{1}:{0}{2})", s0, s1, s2);
                    }
                    chartRange = xlWorkSheet.get_Range("A" + start, alphabets[CurrActlist.Count + 1].ToString() + (start + 1));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + 1), alphabets[CurrActlist.Count + 1].ToString() + (start + t));
                    CellAlignment(chartRange);
                    chartRange = xlWorkSheet.get_Range("A1", alphabets[CurrActlist.Count + 1].ToString() + start + t);
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + t), alphabets[CurrActlist.Count + 1].ToString() + (start + t));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    //***
                    start = start + 3 + 3 + JRlist.Count;
                    System.Collections.ArrayList CurrDatlist = new System.Collections.ArrayList();
                    xlWorkSheet.Cells[start, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[start, 2] = "Column Labels";
                    xlWorkSheet.Cells[start + 1, 1] = "Row Labels";
                    foreach (string Stage in JRStagelist)
                    {
                        if (!(CurrDatlist.Contains(Stage.Split('|')[3])))
                        {
                            CurrDatlist.Add(Stage.Split('|')[3]);
                        }
                    }
                    i = 2;
                    foreach (string curr in CurrDatlist)
                    {
                        xlWorkSheet.Cells[start + 1, i] = curr;
                        i++;
                    }
                    t = 2;
                    foreach (string jid in JRlist)
                    {
                        xlWorkSheet.Cells[start + t, 1] = jid;
                        foreach (string Stage1 in JRStagelist)
                        {
                            if (Stage1.Contains(jid + '|'))
                                for (int cc = 0; cc < CurrDatlist.Count; cc++)
                                {
                                    string curr = CurrDatlist[cc].ToString();
                                    if (Stage1.Contains('|' + curr + '|'))
                                    {
                                        if ((xlWorkSheet.Cells[start + t, cc + 2] as Xl.Range).Value == null) xlWorkSheet.Cells[start + t, cc + 2] = 1;
                                        else xlWorkSheet.Cells[start + t, cc + 2] = Convert.ToDouble((xlWorkSheet.Cells[start + t, cc + 2] as Xl.Range).Value) + 1.0;

                                    }
                                }
                        }
                        t++;
                    }
                    xlWorkSheet.Cells[start + 1, i] = "Grand Total";
                    xlWorkSheet.Cells[start + t, 1] = "Grand Total";
                    for (int ccnt = 2; ccnt <= JRlist.Count + 2; ccnt++)
                    {
                        xlWorkSheet.Cells[start + ccnt, CurrDatlist.Count + 2] = string.Format("=SUM(B{0}:{1}{0})", start + ccnt, alphabets[CurrDatlist.Count].ToString());
                    }
                    for (int ccnt = 2; ccnt <= CurrDatlist.Count + 2; ccnt++)
                    {
                        string s0 = alphabets[ccnt - 1].ToString(), s1 = (start + 2).ToString(), s2 = (start + t - 1).ToString();
                        xlWorkSheet.Cells[start + t, ccnt] = string.Format("=SUM({0}{1}:{0}{2})", s0, s1, s2);
                    }
                    chartRange = xlWorkSheet.get_Range("A" + start, alphabets[CurrDatlist.Count + 1].ToString() + (start + 1));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + 1), alphabets[CurrDatlist.Count + 1].ToString() + (start + t));
                    CellAlignment(chartRange);
                    chartRange = xlWorkSheet.get_Range("A1", alphabets[CurrDatlist.Count + 1].ToString() + start + t);
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + t), alphabets[CurrDatlist.Count + 1].ToString() + (start + t));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    //***
                    start = start + 3 + 3 + JRlist.Count;
                    xlWorkSheet.Cells[start, 1] = "Count of Article ID";
                    xlWorkSheet.Cells[start, 2] = "Column Labels";
                    xlWorkSheet.Cells[start + 1, 1] = "Row Labels";
                    xlWorkSheet.Cells[start + 1, 2] = "Starter";
                    xlWorkSheet.Cells[start + 1, 3] = "CorrectionsToVendor";
                    xlWorkSheet.Cells[start + 1, 4] = "RevisionsToVendor";
                    xlWorkSheet.Cells[start + 1, 5] = "Finaldeliverables";
                    xlWorkSheet.Cells[start + 1, 6] = "(blank)";
                    xlWorkSheet.Cells[start + 1, 7] = "Grand Total";
                    t = 2;
                    CurrDatlist.Clear();
                    foreach (string Stage in JRStagelist)
                    {
                        if (!(CurrDatlist.Contains(Stage.Split('|')[3])))
                        {
                            int s1 = 1, c1 = 1, b1 = 1, r1 = 1, p1 = 1;
                            CurrDatlist.Add(Stage.Split('|')[3]);
                            xlWorkSheet.Cells[start + t, 1] = Stage.Split('|')[3];
                            foreach (string Stage1 in JRStagelist)
                            {
                                if (Stage1.Contains('|' + Stage.Split('|')[3] + '|'))
                                    if (Stage1.Contains("Starter"))
                                    {
                                        xlWorkSheet.Cells[start + t, 2] = s1;
                                        s1++;
                                    }
                                    else if (Stage1.Contains("CorrectionsToVendor"))
                                    {
                                        xlWorkSheet.Cells[start + t, 3] = c1;
                                        c1++;
                                    }
                                    else if (Stage1.Contains("RevisionsToVendor"))
                                    {
                                        xlWorkSheet.Cells[start + t, 4] = r1;
                                        r1++;
                                    }
                                    else if (Stage1.Contains("Finaldeliverables"))
                                    {
                                        xlWorkSheet.Cells[start + t, 5] = p1;
                                        p1++;
                                    }
                                    else if (Stage1.Split('|')[2] == "")
                                    {
                                        xlWorkSheet.Cells[start + t, 6] = b1;
                                        b1++;
                                    }
                            }
                            t++;
                        }
                    }
                    //t = 3 + 1 + CurrActlist.Count;
                    xlWorkSheet.Cells[start + t, 1] = "Grand Total";
                    for (int ccnt = 2; ccnt <= CurrDatlist.Count + 2; ccnt++)
                    {
                        xlWorkSheet.Cells[start + ccnt, 7] = string.Format("=SUM(B{0}:F{0})", start + ccnt);
                    }
                    for (int ccnt = 2; ccnt <= 7; ccnt++)
                    {
                        string s0 = alphabets[ccnt - 1].ToString(), s1 = (start + 2).ToString(), s2 = (start + t - 1).ToString();
                        xlWorkSheet.Cells[start + t, ccnt] = string.Format("=SUM({0}{1}:{0}{2})", s0, s1, s2);
                    }
                    chartRange = xlWorkSheet.get_Range("A" + start, "G" + (start + 1));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + 1), "G" + (start + t));
                    CellAlignment(chartRange);
                    chartRange = xlWorkSheet.get_Range("A1", "G" + (start + t));
                    chartRange.Columns.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A" + (start + t), "G" + (start + t));
                    chartRange.Font.Bold = true;
                    chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    //***     
                }
                if (!(Directory.Exists(System.Environment.CurrentDirectory + @"\AIP_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\AIP_Report\");
                string fname = System.Environment.CurrentDirectory + @"\AIP_Report\AIP_Excel_Report_" + DateTime.Now.ToString("ddMMyyyy_hhmmss") + @".xlsx";
                xlWorkSheet.SaveAs(fname);
                xlApp.Quit();
                System.Threading.Thread.Sleep(5000);
                Cs.SendMail("", "Dear Team,<Br/><Br/>Kindly find the attached today's report", "AIP", false, "AIP_Report", fname);
                System.Threading.Thread.Sleep(5000);
                //System.Diagnostics.Process.Start(fname);
                return true;
            }
            catch (Exception e)
            {
                //MessageBox.Show("Error: " + e.Message + "\n" + e.StackTrace);
                System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("Rajasekar@novatechset.com", "tiworkflow@novatechset.com", "AIP_Excel_Report: " + DateTime.Today.ToString("dd/MM/yyyy"), "Error while generating report: " + e.Message + "<Br/>" + e.StackTrace + "<Br/><Br/>Regards,<Br/>TechSupport.");
                System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                MM.IsBodyHtml = true;
                client.Send(MM);
                return false;
            }
        }

        public bool SAGETATSPEEDReport()
        {
            try
            {
                foreach (Process P in Process.GetProcessesByName("EXCEL"))
                {
                    try
                    {
                        P.Kill();
                    }
                    catch (Exception e) { }
                }
                DBClass db = new DBClass();
                //string Q1 = File.ReadAllText(@"C:\Users\2083\Desktop\Sage\SAGESPEED_new2_Updated.sql");
                //string Q1 = File.ReadAllText(@"C:\Users\2083\Desktop\Sage\SAGESPEED_new2_Updated_condition.sql");
                //string Q1 = File.ReadAllText(@"D:\SARAVANAKUMAR\SVN\Smart\Automation_Tools\Auto_Reports_Tool\Auto_Reports_Tool\SupportingDocs\SAGESPEED_new2_Updated_dtcd1.sql");
                //string Q1 = File.ReadAllText(System.Environment.CurrentDirectory + @"\AIP_Report\SAGESPEED_new1.sql");
                string Q1 = "SSP_Sage_TTP_Report";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rows = ds.Tables[0].Rows;
                Xl.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                Xl.Workbook xlWorkBook;
                Xl.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlApp.Workbooks.Add(misValue);               
                System.Collections.ArrayList JRlist = new System.Collections.ArrayList();
                System.Collections.ArrayList JRStagelist = new System.Collections.ArrayList();
                //***
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Name = "PAP Report";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "S.no";
                xlWorkSheet.Cells[1, 2] = "Journal";
                xlWorkSheet.Cells[1, 3] = "Articleid";
                xlWorkSheet.Cells[1, 4] = "First proofs";
                Xl.Range chartRange = xlWorkSheet.get_Range("D1", "J1");
                chartRange.Merge();
                xlWorkSheet.Cells[1, 11] = "Time taken - Author/Editor";
                chartRange = xlWorkSheet.get_Range("K1", "M1");
                chartRange.Merge();
                xlWorkSheet.Cells[1, 14] = "Author corrections";
                chartRange = xlWorkSheet.get_Range("N1", "P1");
                chartRange.Merge();
                xlWorkSheet.Cells[1, 17] = "Any further corrections to PAP approval";
                chartRange = xlWorkSheet.get_Range("Q1", "T1");
                chartRange.Merge();
                xlWorkSheet.Cells[1, 21] = "PAP";
                chartRange = xlWorkSheet.get_Range("U1", "W1");
                chartRange.Merge();
                xlWorkSheet.Cells[1, 24] = "Total TTP";
                xlWorkSheet.Cells[1, 25] = "PM";
                xlWorkSheet.Cells[1, 26] = "Pages";
                xlWorkSheet.Cells[2, 4] = "MS Recd date";
                xlWorkSheet.Cells[2, 5] = "CE/XML sent date";
                xlWorkSheet.Cells[2, 6] = "CE/XML TAT";
                xlWorkSheet.Cells[2, 7] = "Reason for delay - CE";
                xlWorkSheet.Cells[2, 8] = "Proof sent Date";
                xlWorkSheet.Cells[2, 9] = "Proof TAT";
                xlWorkSheet.Cells[2, 10] = "Reason for delay - Prod.";
                xlWorkSheet.Cells[2, 11] = "Receipt of auth/ed corr";
                xlWorkSheet.Cells[2, 12] = "Time taken - auth/ed";
                xlWorkSheet.Cells[2, 13] = "Reason for delay - auth/ed";
                xlWorkSheet.Cells[2, 14] = "Rev. Proof sent date";
                xlWorkSheet.Cells[2, 15] = "Auth/ed corrs - TAT";
                xlWorkSheet.Cells[2, 16] = "Reason for delay - Corrs";
                xlWorkSheet.Cells[2, 17] = "Proj. Mgr Corrs";
                xlWorkSheet.Cells[2, 18] = "PAP approval date";
                xlWorkSheet.Cells[2, 19] = "TAT";
                xlWorkSheet.Cells[2, 20] = "Reason for delay";
                xlWorkSheet.Cells[2, 21] = "PAP Uploaded Date";
                xlWorkSheet.Cells[2, 22] = "TAT";
                xlWorkSheet.Cells[2, 23] = "Reason for the delay";
                int i = 3, k = 1, rcnt = 0;
                CommonClass Cs = new CommonClass();
                if (rows.Count == 0)
                {
                    //MessageBox.Show("No records found");
                    Cs.SendMail("", "Dear Team,<Br/><Br/>No records found", "SAGE", false, "SPS_Report");
                    return true;
                }
                for (int j = 0; j < rows.Count; j++)
                {                   
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();                  
                    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();
                    xlWorkSheet.Cells[i, 4] = rows[j][2].ToString();                  
                    xlWorkSheet.Cells[i, 5] = rows[j][3].ToString();
                    if (rows[j][4].ToString() != "")
                    {
                        if (Convert.ToInt32(rows[j][4].ToString()) < 0)
                        {
                            xlWorkSheet.Cells[i, 6] = 0;
                        }
                        else
                        {
                            xlWorkSheet.Cells[i, 6] = Convert.ToInt32(rows[j][4].ToString());
                        }
                    }
                    else xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 7] = "";
                    xlWorkSheet.Cells[i, 8] = rows[j][5].ToString();                 
                    if (rows[j][6].ToString() != "")
                    {
                        if (Convert.ToInt32(rows[j][6].ToString()) < 0)
                        {
                            xlWorkSheet.Cells[i, 9] = 0;
                        }
                        else
                        {
                            xlWorkSheet.Cells[i, 9] = Convert.ToInt32(rows[j][6].ToString());
                        }
                    }
                    else xlWorkSheet.Cells[i, 9] = rows[j][6].ToString();
                    xlWorkSheet.Cells[i, 10] = "";
                    xlWorkSheet.Cells[i, 11] = rows[j][7].ToString();                  
                    if (rows[j][8].ToString() != "")
                    {
                        if (Convert.ToInt32(rows[j][8].ToString()) < 0)
                        {
                            xlWorkSheet.Cells[i, 12] = 0;
                        }
                        else
                        {
                            xlWorkSheet.Cells[i, 12] = Convert.ToInt32(rows[j][8].ToString());
                        }
                    }
                    else xlWorkSheet.Cells[i, 12] = rows[j][8].ToString();
                    xlWorkSheet.Cells[i, 13] = "";
                    xlWorkSheet.Cells[i, 14] = rows[j][9].ToString();                    
                    if (rows[j][10].ToString() != "")
                    {
                        if (Convert.ToInt32(rows[j][10].ToString()) < 0)
                        {
                            xlWorkSheet.Cells[i, 15] = 0;
                        }
                        else
                        {
                            xlWorkSheet.Cells[i, 15] = Convert.ToInt32(rows[j][10].ToString());
                        }
                    }
                    else xlWorkSheet.Cells[i, 15] = rows[j][10].ToString();
                    xlWorkSheet.Cells[i, 16] = "";
                    xlWorkSheet.Cells[i, 17] = rows[j][11].ToString();
                    xlWorkSheet.Cells[i, 18] = rows[j][12].ToString();                  
                    if (rows[j][13].ToString() != "")
                    {
                        if (Convert.ToInt32(rows[j][13].ToString()) < 0)
                        {
                            xlWorkSheet.Cells[i, 19] = 0;
                        }
                        else
                        {
                            xlWorkSheet.Cells[i, 19] = Convert.ToInt32(rows[j][13].ToString());
                        }
                    }
                    else xlWorkSheet.Cells[i, 19] = rows[j][13].ToString(); //"1";
                    xlWorkSheet.Cells[i, 20] = "";
                    xlWorkSheet.Cells[i, 21] = rows[j][14].ToString();                  
                    if (rows[j][15].ToString() != "")
                    {
                        if (Convert.ToInt32(rows[j][15].ToString()) < 0)
                        {
                            xlWorkSheet.Cells[i, 22] = 0;
                        }
                        else
                        {
                            xlWorkSheet.Cells[i, 22] = Convert.ToInt32(rows[j][15].ToString());
                        }
                    }
                    else xlWorkSheet.Cells[i, 22] = rows[j][15].ToString();
                    xlWorkSheet.Cells[i, 23] = "";                  
                    if (rows[j][16].ToString() != "")
                    {
                        if (Convert.ToInt32(rows[j][16].ToString()) < 0)
                        {
                            xlWorkSheet.Cells[i, 24] = 0;
                        }
                        else
                        {
                            xlWorkSheet.Cells[i, 24] = Convert.ToInt32(rows[j][16].ToString());
                        }
                    }
                    else xlWorkSheet.Cells[i, 24] = rows[j][16].ToString();
                    xlWorkSheet.Cells[i, 25] = rows[j][17].ToString();
                    xlWorkSheet.Cells[i, 26] = rows[j][18].ToString();
                    i++;
                    k++;
                    rcnt++;
                }
                chartRange = xlWorkSheet.get_Range("A1", "Z" + (i - 1));
                CellAlignment(chartRange);
                chartRange = xlWorkSheet.get_Range("A1", "Z2");
                chartRange.Font.Bold = true;
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;

                xlWorkSheet.Cells[i + 1, 4] = "Responsibility: Pre-edit, Copyedit, Production Teams";
                chartRange = xlWorkSheet.get_Range("D" + (i + 1), "J" + (i + 1));
                chartRange.Merge();
                chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
                xlWorkSheet.Cells[i + 1, 11] = "Responsibility: Project Management";
                chartRange = xlWorkSheet.get_Range("K" + (i + 1), "M" + (i + 1));
                chartRange.Merge();
                chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
                xlWorkSheet.Cells[i + 1, 14] = "Responsibility: Production Team";
                chartRange = xlWorkSheet.get_Range("N" + (i + 1), "P" + (i + 1));
                chartRange.Merge();
                chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
                xlWorkSheet.Cells[i + 1, 17] = "Responsibility: Project Management and Production Teams";
                chartRange = xlWorkSheet.get_Range("Q" + (i + 1), "T" + (i + 1));
                chartRange.Merge();
                chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
                xlWorkSheet.Cells[i + 1, 21] = "Responsibility: PAP/Online Team";
                chartRange = xlWorkSheet.get_Range("U" + (i + 1), "W" + (i + 1));
                chartRange.Merge();
                chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;

                chartRange = xlWorkSheet.get_Range("D1", "J1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
                chartRange = xlWorkSheet.get_Range("K1", "M1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
                chartRange = xlWorkSheet.get_Range("N1", "P1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
                chartRange = xlWorkSheet.get_Range("Q1", "T1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;              
                chartRange = xlWorkSheet.get_Range("U1", "W1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;

                if (!(Directory.Exists(System.Environment.CurrentDirectory + @"\SAGE_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\SAGE_Report\");
                string fname = System.Environment.CurrentDirectory + @"\SAGE_Report\SAGE_TTP_Report_" + DateTime.Now.ToString("ddMMyyyy_HHmmss") + @".xlsx";
                xlWorkSheet.SaveAs(fname);
                xlApp.Quit();
                System.Threading.Thread.Sleep(5000);
                Cs.SendMail("", "Dear Team,<Br/><Br/>Kindly find the attached today's report", "SAGE", false, "SPS_Report", fname,"SAGE TTP Report");
                System.Threading.Thread.Sleep(5000);
                //System.Diagnostics.Process.Start(fname);
                return true;
            }
            catch (Exception e)
            {
                //MessageBox.Show("Error: " + e.Message + "\n" + e.StackTrace);
                System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("Rajasekar@novatechset.com", "tiworkflow@novatechset.com", "SAGE TTP Report: " + DateTime.Today.ToString("dd/MM/yyyy"), "Error while generating report: " + e.Message + "<Br/>" + e.StackTrace + "<Br/><Br/>Regards,<Br/>TechSupport.");
                System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                MM.IsBodyHtml = true;
                client.Send(MM);
                return false;
            }
        }
       public bool CUPTATSPEEDReport()
        {
            try
            {
                foreach (Process P in Process.GetProcessesByName("EXCEL"))
                {
                    try
                    {
                        P.Kill();
                    }
                    catch (Exception e) { }
                }
                DBClass db = new DBClass();
                //string Q1 = File.ReadAllText(@"C:\Users\2083\Desktop\Sage\SAGESPEED_new2_Updated.sql");
                //string Q1 = File.ReadAllText(@"C:\Users\2083\Desktop\Sage\SAGESPEED_new2_Updated_condition.sql");
                //string Q1 = File.ReadAllText(@"D:\SARAVANAKUMAR\SVN\Smart\Automation_Tools\Auto_Reports_Tool\Auto_Reports_Tool\SupportingDocs\SAGESPEED_new2_Updated_dtcd1.sql");
                //string Q1 = File.ReadAllText(System.Environment.CurrentDirectory + @"\AIP_Report\SAGESPEED_new1.sql");
                string Q1 = "SSP_Cup_TTP_Report";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rows = ds.Tables[0].Rows;
                Xl.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                Xl.Workbook xlWorkBook;
                Xl.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                System.Collections.ArrayList JRlist = new System.Collections.ArrayList();
                System.Collections.ArrayList JRStagelist = new System.Collections.ArrayList();
                //***
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Name = "PAP Report";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "S.no";
                xlWorkSheet.Cells[1, 2] = "Journal";
                xlWorkSheet.Cells[1, 3] = "Articleid";
                xlWorkSheet.Cells[1, 4] = "Article Type";
                xlWorkSheet.Cells[1, 5] = "First proofs";
                Xl.Range chartRange = xlWorkSheet.get_Range("E1", "K1");
                chartRange.Merge();
                xlWorkSheet.Cells[1, 12] = "Time taken - Author/Editor";
                chartRange = xlWorkSheet.get_Range("L1", "Q1");
                chartRange.Merge();
                xlWorkSheet.Cells[1, 14] = "Author corrections";
                chartRange = xlWorkSheet.get_Range("R1", "U1");
                chartRange.Merge();
                xlWorkSheet.Cells[1, 18] = "Any further corrections to PAP approval";
                chartRange = xlWorkSheet.get_Range("V1", "AC1");
                chartRange.Merge();
                xlWorkSheet.Cells[1, 22] = "Incremental/FWD";

                xlWorkSheet.Cells[1, 30] = "Total TTP";
                xlWorkSheet.Cells[1, 31] = "PM";
                xlWorkSheet.Cells[1, 32] = "Pages";
                xlWorkSheet.Cells[1, 33] = "Reason for delay";
                xlWorkSheet.Cells[2, 5] = "MS Recd date";
                xlWorkSheet.Cells[2, 6] = "CE/XML sent date";
                xlWorkSheet.Cells[2, 7] = "CE/XML TAT";
                xlWorkSheet.Cells[2, 8] = "Reason for delay - CE";
                xlWorkSheet.Cells[2, 9] = "Proof sent Date";
                xlWorkSheet.Cells[2, 10] = "Proof TAT";
                xlWorkSheet.Cells[2, 11] = "Reason for delay - Prod.";
                xlWorkSheet.Cells[2, 12] = "Receipt of auth/ed corr";
                xlWorkSheet.Cells[2, 13] = "Time taken - auth/ed";
                xlWorkSheet.Cells[2, 14] = "Reason for delay - auth/ed";
                xlWorkSheet.Cells[2, 15] = "Rev. Proof sent date";
                xlWorkSheet.Cells[2, 16] = "Auth/ed corrs - TAT";
                xlWorkSheet.Cells[2, 17] = "Reason for delay - Corrs";
                xlWorkSheet.Cells[2, 18] = "Proj. Mgr Corrs";
                xlWorkSheet.Cells[2, 19] = "PAP approval date";
                xlWorkSheet.Cells[2, 20] = "TAT";
                xlWorkSheet.Cells[2, 21] = "Reason for delay";
                xlWorkSheet.Cells[2, 22] = "Incremental Received Date";
                xlWorkSheet.Cells[2, 23] = "Incremental Uploaded Date";
                xlWorkSheet.Cells[2, 24] = "Incremental TAT";
                xlWorkSheet.Cells[2, 25] = "Reason for the delay";
                xlWorkSheet.Cells[2, 26] = "FWD Received Date";
                xlWorkSheet.Cells[2, 27] = "FWD Uploaded Date";
                xlWorkSheet.Cells[2, 28] = "FWD TAT";
                xlWorkSheet.Cells[2, 29] = "Reason for the delay";
                int i = 3, k = 1, rcnt = 0;
                CommonClass Cs = new CommonClass();
                if (rows.Count == 0)
                {
                    //MessageBox.Show("No records found");
                    Cs.SendMail("", "Dear Team,<Br/><Br/>No records found", "CUP", false, "CUP_Report");
                    return true;
                }
                for (int j = 0; j < rows.Count; j++)
                {
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();//Journal
                    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();//Articleid
                    xlWorkSheet.Cells[i, 4] = rows[j][2].ToString();//Article type
                    xlWorkSheet.Cells[i, 5] = rows[j][3].ToString();//MS Recd date
                    xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();//CE/XML sent date
                    xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();//CE/XML TAT
                    xlWorkSheet.Cells[i, 8] = "";//"Reason for delay - CE"
                    xlWorkSheet.Cells[i, 9] = rows[j][6].ToString();//Proof sent Date
                    xlWorkSheet.Cells[i, 10] = rows[j][7].ToString(); //Proof TAT
                    xlWorkSheet.Cells[i, 11] = "";//Reason for delay - Prod.
                    xlWorkSheet.Cells[i, 12] = rows[j][8].ToString();//Receipt of auth/ed corr 
                    xlWorkSheet.Cells[i, 13] = rows[j][9].ToString();//Time taken - auth/ed
                    xlWorkSheet.Cells[i, 14] = "";//Reason for delay - auth/ed
                    xlWorkSheet.Cells[i, 15] = rows[j][10].ToString();//Rev. Proof sent date
                    xlWorkSheet.Cells[i, 16] = rows[j][11].ToString();//Auth/ed corrs - TAT
                    xlWorkSheet.Cells[i, 17] = "";//Reason for delay - Corrs
                    xlWorkSheet.Cells[i, 18] = rows[j][12].ToString();//Proj. Mgr Corrs
                    xlWorkSheet.Cells[i, 19] = rows[j][13].ToString();//PAP approval date
                    xlWorkSheet.Cells[i, 20] = rows[j][14].ToString();//TAT
                    xlWorkSheet.Cells[i, 21] = "";//Reason for delay
                    xlWorkSheet.Cells[i, 22] = rows[j][15].ToString();//Incremental Received Date
                    xlWorkSheet.Cells[i, 23] = rows[j][16].ToString();//Incremental Uploaded Date
                    xlWorkSheet.Cells[i, 24] = rows[j][17].ToString();//Incremental TAT
                    xlWorkSheet.Cells[i, 25] = "";//Reason for the delay
                    xlWorkSheet.Cells[i, 26] = rows[j][18].ToString();//FWD Received Date
                    xlWorkSheet.Cells[i, 27] = rows[j][19].ToString();//FWD Uploaded Date
                    xlWorkSheet.Cells[i, 28] = rows[j][20].ToString();//FWD TAT
                    xlWorkSheet.Cells[i, 29] = "";//Reason
                    xlWorkSheet.Cells[i, 30] = rows[j][21].ToString();//Total TTP
                    xlWorkSheet.Cells[i, 31] = rows[j][22].ToString();//PM
                    xlWorkSheet.Cells[i, 32] = rows[j][23].ToString();//Pages
                    xlWorkSheet.Cells[i, 33] = "";//Reason

                    /*xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();
                    xlWorkSheet.Cells[i, 4] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 5] = rows[j][3].ToString();
                    if (rows[j][4].ToString() != "")
                    {
                        if (Convert.ToInt32(rows[j][4].ToString()) < 0)
                        {
                            xlWorkSheet.Cells[i, 6] = 0;
                        }
                        else
                        {
                            xlWorkSheet.Cells[i, 6] = Convert.ToInt32(rows[j][4].ToString());
                        }
                    }
                    else xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 7] = "";
                    xlWorkSheet.Cells[i, 8] = rows[j][5].ToString();
                    if (rows[j][6].ToString() != "")
                    {
                        if (Convert.ToInt32(rows[j][6].ToString()) < 0)
                        {
                            xlWorkSheet.Cells[i, 9] = 0;
                        }
                        else
                        {
                            xlWorkSheet.Cells[i, 9] = Convert.ToInt32(rows[j][6].ToString());
                        }
                    }
                    else xlWorkSheet.Cells[i, 9] = rows[j][6].ToString();
                    xlWorkSheet.Cells[i, 10] = "";
                    xlWorkSheet.Cells[i, 11] = rows[j][7].ToString();
                    if (rows[j][8].ToString() != "")
                    {
                        if (Convert.ToInt32(rows[j][8].ToString()) < 0)
                        {
                            xlWorkSheet.Cells[i, 12] = 0;
                        }
                        else
                        {
                            xlWorkSheet.Cells[i, 12] = Convert.ToInt32(rows[j][8].ToString());
                        }
                    }
                    else xlWorkSheet.Cells[i, 12] = rows[j][8].ToString();
                    xlWorkSheet.Cells[i, 13] = "";
                    xlWorkSheet.Cells[i, 14] = rows[j][9].ToString();
                    if (rows[j][10].ToString() != "")
                    {
                        if (Convert.ToInt32(rows[j][10].ToString()) < 0)
                        {
                            xlWorkSheet.Cells[i, 15] = 0;
                        }
                        else
                        {
                            xlWorkSheet.Cells[i, 15] = Convert.ToInt32(rows[j][10].ToString());
                        }
                    }
                    else xlWorkSheet.Cells[i, 15] = rows[j][10].ToString();
                    xlWorkSheet.Cells[i, 16] = "";
                    xlWorkSheet.Cells[i, 17] = rows[j][11].ToString();
                    xlWorkSheet.Cells[i, 18] = rows[j][12].ToString();
                    if (rows[j][13].ToString() != "")
                    {
                        if (Convert.ToInt32(rows[j][13].ToString()) < 0)
                        {
                            xlWorkSheet.Cells[i, 19] = 0;
                        }
                        else
                        {
                            xlWorkSheet.Cells[i, 19] = Convert.ToInt32(rows[j][13].ToString());
                        }
                    }
                    else xlWorkSheet.Cells[i, 19] = rows[j][13].ToString(); //"1";
                    xlWorkSheet.Cells[i, 20] = "";
                    xlWorkSheet.Cells[i, 21] = rows[j][14].ToString();
                    if (rows[j][15].ToString() != "")
                    {
                        if (Convert.ToInt32(rows[j][15].ToString()) < 0)
                        {
                            xlWorkSheet.Cells[i, 22] = 0;
                        }
                        else
                        {
                            xlWorkSheet.Cells[i, 22] = Convert.ToInt32(rows[j][15].ToString());
                        }
                    }
                    else xlWorkSheet.Cells[i, 22] = rows[j][15].ToString();
                    xlWorkSheet.Cells[i, 23] = "";
                    if (rows[j][16].ToString() != "")
                    {
                        if (Convert.ToInt32(rows[j][16].ToString()) < 0)
                        {
                            xlWorkSheet.Cells[i, 24] = 0;
                        }
                        else
                        {
                            xlWorkSheet.Cells[i, 24] = Convert.ToInt32(rows[j][16].ToString());
                        }
                    }
                    else xlWorkSheet.Cells[i, 24] = rows[j][16].ToString();
                    xlWorkSheet.Cells[i, 25] = rows[j][17].ToString();
                    xlWorkSheet.Cells[i, 26] = rows[j][18].ToString();*/
                    i++;
                    k++;
                    rcnt++;
                }
                chartRange = xlWorkSheet.get_Range("A1", "AG" + (i - 1));
                CellAlignment(chartRange);
                chartRange = xlWorkSheet.get_Range("A1", "AG2");
                chartRange.Font.Bold = true;
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;

                xlWorkSheet.Cells[i + 1, 4] = "Responsibility: Pre-edit, Copyedit, Production Teams";
                chartRange = xlWorkSheet.get_Range("D" + (i + 1), "J" + (i + 1));
                chartRange.Merge();
                chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
                xlWorkSheet.Cells[i + 1, 11] = "Responsibility: Project Management";
                chartRange = xlWorkSheet.get_Range("K" + (i + 1), "M" + (i + 1));
                chartRange.Merge();
                chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
                xlWorkSheet.Cells[i + 1, 14] = "Responsibility: Production Team";
                chartRange = xlWorkSheet.get_Range("N" + (i + 1), "P" + (i + 1));
                chartRange.Merge();
                chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
                xlWorkSheet.Cells[i + 1, 17] = "Responsibility: Project Management and Production Teams";
                chartRange = xlWorkSheet.get_Range("Q" + (i + 1), "T" + (i + 1));
                chartRange.Merge();
                chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
                xlWorkSheet.Cells[i + 1, 21] = "Responsibility: PAP/Online Team";
                chartRange = xlWorkSheet.get_Range("U" + (i + 1), "Z" + (i + 1));
                chartRange.Merge();
                chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;

                chartRange = xlWorkSheet.get_Range("E1", "K1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
                chartRange = xlWorkSheet.get_Range("L1", "N1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
                chartRange = xlWorkSheet.get_Range("O1", "Q1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
                chartRange = xlWorkSheet.get_Range("R1", "U1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
                chartRange = xlWorkSheet.get_Range("V1", "AC1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
                chartRange = xlWorkSheet.get_Range("AD1", "AG1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
                
                if (!(Directory.Exists(System.Environment.CurrentDirectory + @"\CUP_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\CUP_Report\");
                string fname = System.Environment.CurrentDirectory + @"\CUP_Report\CUP_TTP_Report_" + DateTime.Now.ToString("ddMMyyyy") + @".xlsx";
                xlWorkSheet.SaveAs(fname);
                xlApp.Quit();
                System.Threading.Thread.Sleep(5000);
                Cs.SendMail("", "Dear Team,<Br/><Br/>Kindly find the attached today's report", "CUP", false, "CUP_TTP_Report", fname, "CUP TTP Report");
                System.Threading.Thread.Sleep(5000);
                //System.Diagnostics.Process.Start(fname);
                return true;
            }
            catch (Exception e)
            {
                //MessageBox.Show("Error: " + e.Message + "\n" + e.StackTrace);
                System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("saravanakumar@novatechset.com", "tiworkflow@novatechset.com", "CUP_TTP_Report: " + DateTime.Today.ToString("dd/MM/yyyy"), "Error while generating report: " + e.Message + "<Br/>" + e.StackTrace + "<Br/><Br/>Regards,<Br/>TechSupport.");
                System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                MM.IsBodyHtml = true;
                client.Send(MM);
                return false;
            }
        }

       public bool APSTATSPEEDReport()
       {
           try
           {
               foreach (Process P in Process.GetProcessesByName("EXCEL"))
               {
                   try
                   {
                       P.Kill();
                   }
                   catch (Exception e) { }
               }
               DBClass db = new DBClass();
               //string Q1 = File.ReadAllText(@"C:\Users\2083\Desktop\Sage\SAGESPEED_new2_Updated.sql");
               //string Q1 = File.ReadAllText(@"C:\Users\2083\Desktop\Sage\SAGESPEED_new2_Updated_condition.sql");
               //string Q1 = File.ReadAllText(@"D:\SARAVANAKUMAR\SVN\Smart\Automation_Tools\Auto_Reports_Tool\Auto_Reports_Tool\SupportingDocs\SAGESPEED_new2_Updated_dtcd1.sql");
               //string Q1 = File.ReadAllText(System.Environment.CurrentDirectory + @"\AIP_Report\SAGESPEED_new1.sql");
               string Q1 = "SSP_APS_TTP_Report";
               db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
               db.dt = new DataTable();
               db.Sqladptr.Fill(db.dt);
               db.CloseConnection();
               DataSet ds = new DataSet("New_DataSet");
               ds.Tables.Add(db.dt);
               var rows = ds.Tables[0].Rows;
               Xl.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
               Xl.Workbook xlWorkBook;
               Xl.Worksheet xlWorkSheet;
               object misValue = System.Reflection.Missing.Value;
               xlWorkBook = xlApp.Workbooks.Add(misValue);
               System.Collections.ArrayList JRlist = new System.Collections.ArrayList();
               System.Collections.ArrayList JRStagelist = new System.Collections.ArrayList();
               //***
               xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.get_Item(1);
               xlWorkSheet.Name = "PAP Report";
               xlWorkSheet.Cells.NumberFormat = "@";
               xlWorkSheet.Cells[1, 1] = "S.no";
               xlWorkSheet.Cells[1, 2] = "Journal";
               xlWorkSheet.Cells[1, 3] = "Articleid";
               xlWorkSheet.Cells[1, 4] = "Article Type";
               xlWorkSheet.Cells[1, 5] = "First proofs";
               Xl.Range chartRange = xlWorkSheet.get_Range("E1", "K1");
               chartRange.Merge();
               xlWorkSheet.Cells[1, 12] = "Time taken - Author/Editor";
               chartRange = xlWorkSheet.get_Range("L1", "Q1");
               chartRange.Merge();
               xlWorkSheet.Cells[1, 14] = "Author corrections";
               chartRange = xlWorkSheet.get_Range("R1", "U1");
               chartRange.Merge();
               xlWorkSheet.Cells[1, 18] = "Any further corrections to PAP approval";
               chartRange = xlWorkSheet.get_Range("V1", "AC1");
               chartRange.Merge();
               xlWorkSheet.Cells[1, 22] = "Incremental/FWD";

               xlWorkSheet.Cells[1, 30] = "Total TTP";
               xlWorkSheet.Cells[1, 31] = "PM";
               xlWorkSheet.Cells[1, 32] = "Pages";
               xlWorkSheet.Cells[1, 33] = "Reason for delay";
               xlWorkSheet.Cells[2, 5] = "MS Recd date";
               xlWorkSheet.Cells[2, 6] = "CE/XML sent date";
               xlWorkSheet.Cells[2, 7] = "CE/XML TAT";
               xlWorkSheet.Cells[2, 8] = "Reason for delay - CE";
               xlWorkSheet.Cells[2, 9] = "Proof sent Date";
               xlWorkSheet.Cells[2, 10] = "Proof TAT";
               xlWorkSheet.Cells[2, 11] = "Reason for delay - Prod.";
               xlWorkSheet.Cells[2, 12] = "Receipt of auth/ed corr";
               xlWorkSheet.Cells[2, 13] = "Time taken - auth/ed";
               xlWorkSheet.Cells[2, 14] = "Reason for delay - auth/ed";
               xlWorkSheet.Cells[2, 15] = "Rev. Proof sent date";
               xlWorkSheet.Cells[2, 16] = "Auth/ed corrs - TAT";
               xlWorkSheet.Cells[2, 17] = "Reason for delay - Corrs";
               xlWorkSheet.Cells[2, 18] = "Proj. Mgr Corrs";
               xlWorkSheet.Cells[2, 19] = "PAP approval date";
               xlWorkSheet.Cells[2, 20] = "TAT";
               xlWorkSheet.Cells[2, 21] = "Reason for delay";
               xlWorkSheet.Cells[2, 22] = "PAP Received Date";
               xlWorkSheet.Cells[2, 23] = "PAP Uploaded Date";
               xlWorkSheet.Cells[2, 24] = "PAP TAT";
               xlWorkSheet.Cells[2, 25] = "Reason for the delay";
               xlWorkSheet.Cells[2, 26] = "FWD Received Date";
               xlWorkSheet.Cells[2, 27] = "FWD Uploaded Date";
               xlWorkSheet.Cells[2, 28] = "FWD TAT";
               xlWorkSheet.Cells[2, 29] = "Reason for the delay";
               int i = 3, k = 1, rcnt = 0;
               CommonClass Cs = new CommonClass();
               if (rows.Count == 0)
               {
                   //MessageBox.Show("No records found");
                   Cs.SendMail("", "Dear Team,<Br/><Br/>No records found", "APS", false, "APS_Report");
                   return true;
               }
               for (int j = 0; j < rows.Count; j++)
               {
                   xlWorkSheet.Cells[i, 1] = k;
                   xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();//Journal
                   xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();//Articleid
                   xlWorkSheet.Cells[i, 4] = rows[j][2].ToString();//Article type
                   xlWorkSheet.Cells[i, 5] = rows[j][3].ToString();//MS Recd date
                   xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();//CE/XML sent date
                   xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();//CE/XML TAT
                   xlWorkSheet.Cells[i, 8] = "";//"Reason for delay - CE"
                   xlWorkSheet.Cells[i, 9] = rows[j][6].ToString();//Proof sent Date
                   xlWorkSheet.Cells[i, 10] = rows[j][7].ToString(); //Proof TAT
                   xlWorkSheet.Cells[i, 11] = "";//Reason for delay - Prod.
                   xlWorkSheet.Cells[i, 12] = rows[j][8].ToString();//Receipt of auth/ed corr 
                   xlWorkSheet.Cells[i, 13] = rows[j][9].ToString();//Time taken - auth/ed
                   xlWorkSheet.Cells[i, 14] = "";//Reason for delay - auth/ed
                   xlWorkSheet.Cells[i, 15] = rows[j][10].ToString();//Rev. Proof sent date
                   xlWorkSheet.Cells[i, 16] = rows[j][11].ToString();//Auth/ed corrs - TAT
                   xlWorkSheet.Cells[i, 17] = "";//Reason for delay - Corrs
                   xlWorkSheet.Cells[i, 18] = rows[j][12].ToString();//Proj. Mgr Corrs
                   xlWorkSheet.Cells[i, 19] = rows[j][13].ToString();//PAP approval date
                   xlWorkSheet.Cells[i, 20] = rows[j][14].ToString();//TAT
                   xlWorkSheet.Cells[i, 21] = "";//Reason for delay
                   xlWorkSheet.Cells[i, 22] = rows[j][15].ToString();//PAP Received Date
                   xlWorkSheet.Cells[i, 23] = rows[j][16].ToString();//PAP Uploaded Date
                   xlWorkSheet.Cells[i, 24] = rows[j][17].ToString();//PAP TAT
                   xlWorkSheet.Cells[i, 25] = "";//Reason for the delay
                   xlWorkSheet.Cells[i, 26] = rows[j][18].ToString();//FWD Received Date
                   xlWorkSheet.Cells[i, 27] = rows[j][19].ToString();//FWD Uploaded Date
                   xlWorkSheet.Cells[i, 28] = rows[j][20].ToString();//FWD TAT
                   xlWorkSheet.Cells[i, 29] = "";//Reason
                   xlWorkSheet.Cells[i, 30] = rows[j][21].ToString();//Total TTP
                   xlWorkSheet.Cells[i, 31] = rows[j][22].ToString();//PM
                   xlWorkSheet.Cells[i, 32] = rows[j][23].ToString();//Pages
                   xlWorkSheet.Cells[i, 33] = "";//Reason

                   i++;
                   k++;
                   rcnt++;
               }
               chartRange = xlWorkSheet.get_Range("A1", "AG" + (i - 1));
               CellAlignment(chartRange);
               chartRange = xlWorkSheet.get_Range("A1", "AG2");
               chartRange.Font.Bold = true;
               chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;

               xlWorkSheet.Cells[i + 1, 4] = "Responsibility: Pre-edit, Copyedit, Production Teams";
               chartRange = xlWorkSheet.get_Range("D" + (i + 1), "J" + (i + 1));
               chartRange.Merge();
               chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
               xlWorkSheet.Cells[i + 1, 11] = "Responsibility: Project Management";
               chartRange = xlWorkSheet.get_Range("K" + (i + 1), "M" + (i + 1));
               chartRange.Merge();
               chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
               xlWorkSheet.Cells[i + 1, 14] = "Responsibility: Production Team";
               chartRange = xlWorkSheet.get_Range("N" + (i + 1), "P" + (i + 1));
               chartRange.Merge();
               chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
               xlWorkSheet.Cells[i + 1, 17] = "Responsibility: Project Management and Production Teams";
               chartRange = xlWorkSheet.get_Range("Q" + (i + 1), "T" + (i + 1));
               chartRange.Merge();
               chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
               xlWorkSheet.Cells[i + 1, 21] = "Responsibility: PAP/Online Team";
               chartRange = xlWorkSheet.get_Range("U" + (i + 1), "Z" + (i + 1));
               chartRange.Merge();
               chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;

               chartRange = xlWorkSheet.get_Range("E1", "K1");
               chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
               chartRange = xlWorkSheet.get_Range("L1", "N1");
               chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
               chartRange = xlWorkSheet.get_Range("O1", "Q1");
               chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
               chartRange = xlWorkSheet.get_Range("R1", "U1");
               chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
               chartRange = xlWorkSheet.get_Range("V1", "AC1");
               chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
               chartRange = xlWorkSheet.get_Range("AD1", "AG1");
               chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;

               if (!(Directory.Exists(System.Environment.CurrentDirectory + @"\APS_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\APS_Report\");
               string fname = System.Environment.CurrentDirectory + @"\APS_Report\APS_TTP_Report_" + DateTime.Now.ToString("ddMMyyyy") + @".xlsx";
               xlWorkSheet.SaveAs(fname);
               xlApp.Quit();
               System.Threading.Thread.Sleep(5000);
               Cs.SendMail("", "Dear Team,<Br/><Br/>Kindly find the attached today's report", "APS", false, "APS_TTP_Report", fname, "APS TTP Report");
               System.Threading.Thread.Sleep(5000);
               //System.Diagnostics.Process.Start(fname);
               return true;
           }
           catch (Exception e)
           {
               //MessageBox.Show("Error: " + e.Message + "\n" + e.StackTrace);
               System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("saravanakumar@novatechset.com", "tiworkflow@novatechset.com", "APS_TTP_Report: " + DateTime.Today.ToString("dd/MM/yyyy"), "Error while generating report: " + e.Message + "<Br/>" + e.StackTrace + "<Br/><Br/>Regards,<Br/>TechSupport.");
               System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
               MM.IsBodyHtml = true;
               client.Send(MM);
               return false;
           }
       }
       
        public bool AIPTATSPEEDReport()
       {
           try
           {
               foreach (Process P in Process.GetProcessesByName("EXCEL"))
               {
                   try
                   {
                       P.Kill();
                   }
                   catch (Exception e) { }
               }
               DBClass db = new DBClass();
               
               string Q1 = "SSP_AIP_TTP_Report";
               db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
               db.dt = new DataTable();
               db.Sqladptr.Fill(db.dt);
               db.CloseConnection();
               DataSet ds = new DataSet("New_DataSet");
               ds.Tables.Add(db.dt);
               var rows = ds.Tables[0].Rows;
               Xl.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
               Xl.Workbook xlWorkBook;
               Xl.Worksheet xlWorkSheet;
               object misValue = System.Reflection.Missing.Value;
               xlWorkBook = xlApp.Workbooks.Add(misValue);
               System.Collections.ArrayList JRlist = new System.Collections.ArrayList();
               System.Collections.ArrayList JRStagelist = new System.Collections.ArrayList();
               //***
               xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.get_Item(1);
               xlWorkSheet.Name = "PAP Report";
               xlWorkSheet.Cells.NumberFormat = "@";
               xlWorkSheet.Cells[1, 1] = "S.no";
               xlWorkSheet.Cells[1, 2] = "Journal";
               xlWorkSheet.Cells[1, 3] = "Articleid";
               xlWorkSheet.Cells[1, 4] = "Article Type";
               xlWorkSheet.Cells[1, 5] = "First proofs";
               Xl.Range chartRange = xlWorkSheet.get_Range("E1", "K1");
               chartRange.Merge();
               xlWorkSheet.Cells[1, 12] = "Time taken - Author/Editor";
               chartRange = xlWorkSheet.get_Range("L1", "Q1");
               chartRange.Merge();
               xlWorkSheet.Cells[1, 14] = "Author corrections";
               chartRange = xlWorkSheet.get_Range("R1", "U1");
               chartRange.Merge();
               xlWorkSheet.Cells[1, 18] = "Any further corrections to PAP approval";
               chartRange = xlWorkSheet.get_Range("V1", "AC1");
               chartRange.Merge();
               xlWorkSheet.Cells[1, 22] = "Incremental/FWD";

               xlWorkSheet.Cells[1, 30] = "Total TTP";
               xlWorkSheet.Cells[1, 31] = "PM";
               xlWorkSheet.Cells[1, 32] = "Pages";
               xlWorkSheet.Cells[1, 33] = "Reason for delay";
               xlWorkSheet.Cells[2, 5] = "MS Recd date";
               xlWorkSheet.Cells[2, 6] = "CE/XML sent date";
               xlWorkSheet.Cells[2, 7] = "CE/XML TAT";
               xlWorkSheet.Cells[2, 8] = "Reason for delay - CE";
               xlWorkSheet.Cells[2, 9] = "Proof sent Date";
               xlWorkSheet.Cells[2, 10] = "Proof TAT";
               xlWorkSheet.Cells[2, 11] = "Reason for delay - Prod.";
               xlWorkSheet.Cells[2, 12] = "Receipt of auth/ed corr";
               xlWorkSheet.Cells[2, 13] = "Time taken - auth/ed";
               xlWorkSheet.Cells[2, 14] = "Reason for delay - auth/ed";
               xlWorkSheet.Cells[2, 15] = "Rev. Proof sent date";
               xlWorkSheet.Cells[2, 16] = "Auth/ed corrs - TAT";
               xlWorkSheet.Cells[2, 17] = "Reason for delay - Corrs";
               xlWorkSheet.Cells[2, 18] = "Proj. Mgr Corrs";
               xlWorkSheet.Cells[2, 19] = "PAP approval date";
               xlWorkSheet.Cells[2, 20] = "TAT";
               xlWorkSheet.Cells[2, 21] = "Reason for delay";
               xlWorkSheet.Cells[2, 22] = "PAP Received Date";
               xlWorkSheet.Cells[2, 23] = "PAP Uploaded Date";
               xlWorkSheet.Cells[2, 24] = "PAP TAT";
               xlWorkSheet.Cells[2, 25] = "Reason for the delay";
               xlWorkSheet.Cells[2, 26] = "FWD Received Date";
               xlWorkSheet.Cells[2, 27] = "FWD Uploaded Date";
               xlWorkSheet.Cells[2, 28] = "FWD TAT";
               xlWorkSheet.Cells[2, 29] = "Reason for the delay";
               int i = 3, k = 1, rcnt = 0;
               CommonClass Cs = new CommonClass();
               if (rows.Count == 0)
               {
                   //MessageBox.Show("No records found");
                   Cs.SendMail("", "Dear Team,<Br/><Br/>No records found", "AIP", false, "AIP_Report");
                   return true;
               }
               for (int j = 0; j < rows.Count; j++)
               {
                   xlWorkSheet.Cells[i, 1] = k;
                   xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();//Journal
                   xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();//Articleid
                   xlWorkSheet.Cells[i, 4] = rows[j][2].ToString();//Article type
                   xlWorkSheet.Cells[i, 5] = rows[j][3].ToString();//MS Recd date
                   xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();//CE/XML sent date
                   xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();//CE/XML TAT
                   xlWorkSheet.Cells[i, 8] = "";//"Reason for delay - CE"
                   xlWorkSheet.Cells[i, 9] = rows[j][6].ToString();//Proof sent Date
                   xlWorkSheet.Cells[i, 10] = rows[j][7].ToString(); //Proof TAT
                   xlWorkSheet.Cells[i, 11] = "";//Reason for delay - Prod.
                   xlWorkSheet.Cells[i, 12] = rows[j][8].ToString();//Receipt of auth/ed corr 
                   xlWorkSheet.Cells[i, 13] = rows[j][9].ToString();//Time taken - auth/ed
                   xlWorkSheet.Cells[i, 14] = "";//Reason for delay - auth/ed
                   xlWorkSheet.Cells[i, 15] = rows[j][10].ToString();//Rev. Proof sent date
                   xlWorkSheet.Cells[i, 16] = rows[j][11].ToString();//Auth/ed corrs - TAT
                   xlWorkSheet.Cells[i, 17] = "";//Reason for delay - Corrs
                   xlWorkSheet.Cells[i, 18] = rows[j][12].ToString();//Proj. Mgr Corrs
                   xlWorkSheet.Cells[i, 19] = rows[j][13].ToString();//PAP approval date
                   xlWorkSheet.Cells[i, 20] = rows[j][14].ToString();//TAT
                   xlWorkSheet.Cells[i, 21] = "";//Reason for delay
                   xlWorkSheet.Cells[i, 22] = rows[j][15].ToString();//PAP Received Date
                   xlWorkSheet.Cells[i, 23] = rows[j][16].ToString();//PAP Uploaded Date
                   xlWorkSheet.Cells[i, 24] = rows[j][17].ToString();//PAP TAT
                   xlWorkSheet.Cells[i, 25] = "";//Reason for the delay
                   xlWorkSheet.Cells[i, 26] = rows[j][18].ToString();//FWD Received Date
                   xlWorkSheet.Cells[i, 27] = rows[j][19].ToString();//FWD Uploaded Date
                   xlWorkSheet.Cells[i, 28] = rows[j][20].ToString();//FWD TAT
                   xlWorkSheet.Cells[i, 29] = "";//Reason
                   xlWorkSheet.Cells[i, 30] = rows[j][21].ToString();//Total TTP
                   xlWorkSheet.Cells[i, 31] = rows[j][22].ToString();//PM
                   xlWorkSheet.Cells[i, 32] = rows[j][23].ToString();//Pages
                   xlWorkSheet.Cells[i, 33] = "";//Reason

                   i++;
                   k++;
                   rcnt++;
               }
               chartRange = xlWorkSheet.get_Range("A1", "AG" + (i - 1));
               CellAlignment(chartRange);
               chartRange = xlWorkSheet.get_Range("A1", "AG2");
               chartRange.Font.Bold = true;
               chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;

               xlWorkSheet.Cells[i + 1, 4] = "Responsibility: Pre-edit, Copyedit, Production Teams";
               chartRange = xlWorkSheet.get_Range("D" + (i + 1), "J" + (i + 1));
               chartRange.Merge();
               chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
               xlWorkSheet.Cells[i + 1, 11] = "Responsibility: Project Management";
               chartRange = xlWorkSheet.get_Range("K" + (i + 1), "M" + (i + 1));
               chartRange.Merge();
               chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
               xlWorkSheet.Cells[i + 1, 14] = "Responsibility: Production Team";
               chartRange = xlWorkSheet.get_Range("N" + (i + 1), "P" + (i + 1));
               chartRange.Merge();
               chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
               xlWorkSheet.Cells[i + 1, 17] = "Responsibility: Project Management and Production Teams";
               chartRange = xlWorkSheet.get_Range("Q" + (i + 1), "T" + (i + 1));
               chartRange.Merge();
               chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
               xlWorkSheet.Cells[i + 1, 21] = "Responsibility: PAP/Online Team";
               chartRange = xlWorkSheet.get_Range("U" + (i + 1), "Z" + (i + 1));
               chartRange.Merge();
               chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;

               chartRange = xlWorkSheet.get_Range("E1", "K1");
               chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
               chartRange = xlWorkSheet.get_Range("L1", "N1");
               chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
               chartRange = xlWorkSheet.get_Range("O1", "Q1");
               chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
               chartRange = xlWorkSheet.get_Range("R1", "U1");
               chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
               chartRange = xlWorkSheet.get_Range("V1", "AC1");
               chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
               chartRange = xlWorkSheet.get_Range("AD1", "AG1");
               chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;

               if (!(Directory.Exists(System.Environment.CurrentDirectory + @"\AIP_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\AIP_Report\");
               string fname = System.Environment.CurrentDirectory + @"\AIP_Report\AIP_TTP_Report_" + DateTime.Now.ToString("ddMMyyyy") + @".xlsx";
               xlWorkSheet.SaveAs(fname);
               xlApp.Quit();
               System.Threading.Thread.Sleep(5000);
               Cs.SendMail("", "Dear Team,<Br/><Br/>Kindly find the attached today's report", "AIP", false, "AIP_TTP_Report", fname, "AIP TTP Report");
               System.Threading.Thread.Sleep(5000);
               //System.Diagnostics.Process.Start(fname);
               return true;
           }
           catch (Exception e)
           {
               //MessageBox.Show("Error: " + e.Message + "\n" + e.StackTrace);
               System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("saravanakumar@novatechset.com", "tiworkflow@novatechset.com", "AIP_TTP_Report: " + DateTime.Today.ToString("dd/MM/yyyy"), "Error while generating report: " + e.Message + "<Br/>" + e.StackTrace + "<Br/><Br/>Regards,<Br/>TechSupport.");
               System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
               MM.IsBodyHtml = true;
               client.Send(MM);
               return false;
           }
       }

        public bool FrontiersTATSPEEDReport()
        {
            try
            {
                foreach (Process P in Process.GetProcessesByName("EXCEL"))
                {
                    try
                    {
                        P.Kill();
                    }
                    catch (Exception e) { }
                }
                DBClass db = new DBClass();
                string Q1 = "SSP_Frontiers_TTP_Report";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rows = ds.Tables[0].Rows;
                Xl.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                Xl.Workbook xlWorkBook;
                Xl.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                System.Collections.ArrayList JRlist = new System.Collections.ArrayList();
                System.Collections.ArrayList JRStagelist = new System.Collections.ArrayList();
                //***
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Name = "PP Report";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "S.no";
                xlWorkSheet.Cells[1, 2] = "Journal";
                xlWorkSheet.Cells[1, 3] = "Articleid";
                xlWorkSheet.Cells[1, 4] = "Article type";
                xlWorkSheet.Cells[1, 5] = "First proofs";
                Xl.Range chartRange = xlWorkSheet.get_Range("E1", "H1");
                chartRange.Merge();
                xlWorkSheet.Cells[1, 9] = "Author corrections";
                chartRange = xlWorkSheet.get_Range("I1", "L1");
                chartRange.Merge();
                xlWorkSheet.Cells[1, 14] = "Further Author corrections";
                chartRange = xlWorkSheet.get_Range("M1", "R1");
                chartRange.Merge();
                xlWorkSheet.Cells[1, 20] = "Publisher Proof";
                chartRange = xlWorkSheet.get_Range("S1", "V1");
                chartRange.Merge();
                xlWorkSheet.Cells[1, 24] = "Publisher Proof Corrections";
                chartRange = xlWorkSheet.get_Range("W1", "AD1");
                chartRange.Merge();

                xlWorkSheet.Cells[1, 31] = "Final Web Delivery";
                chartRange = xlWorkSheet.get_Range("AE1", "AI1");
                chartRange.Merge();

                xlWorkSheet.Cells[1, 36] = "Total TTP";
                xlWorkSheet.Cells[1, 37] = "Reason for the delay";
                xlWorkSheet.Cells[1, 38] = "Pages";
                xlWorkSheet.Cells[1, 39] = "Level";

                xlWorkSheet.Cells[2, 5] = "Received Date";
                xlWorkSheet.Cells[2, 6] = "Sent date";
                xlWorkSheet.Cells[2, 7] = "TAT";
                xlWorkSheet.Cells[2, 8] = "Reason for delay";

                xlWorkSheet.Cells[2, 9] = "Received date";
                xlWorkSheet.Cells[2, 10] = "AU Uploaded";
                xlWorkSheet.Cells[2, 11] = "TAT";
                xlWorkSheet.Cells[2, 12] = "Reason for delay";

                xlWorkSheet.Cells[2, 13] = "AU1 Received date";
                xlWorkSheet.Cells[2, 14] = "AU1 Uploaded date";
                xlWorkSheet.Cells[2, 15] = "TAT";

                xlWorkSheet.Cells[2, 16] = "AU2 Received date";
                xlWorkSheet.Cells[2, 17] = "AU2 Uploaded date";
                xlWorkSheet.Cells[2, 18] = "TAT";

                xlWorkSheet.Cells[2, 19] = "PP Received date";
                xlWorkSheet.Cells[2, 20] = "PP Uploaded date";
                xlWorkSheet.Cells[2, 21] = "TAT";
                xlWorkSheet.Cells[2, 22] = "Reason for the delay";

                xlWorkSheet.Cells[2, 23] = "PP1 Received date";
                xlWorkSheet.Cells[2, 24] = "PP1 Uploaded date";
                xlWorkSheet.Cells[2, 25] = "TAT";
                xlWorkSheet.Cells[2, 26] = "Reason for the delay";

                xlWorkSheet.Cells[2, 27] = "PP2 Received date";
                xlWorkSheet.Cells[2, 28] = "PP2 Uploaded date";
                xlWorkSheet.Cells[2, 29] = "TAT";
                xlWorkSheet.Cells[2, 30] = "Reason for the delay";

                xlWorkSheet.Cells[2, 31] = "FWD Received date";
                xlWorkSheet.Cells[2, 32] = "FWD Uploaded date";
                xlWorkSheet.Cells[2, 33] = "Publishing Day/Date";
                xlWorkSheet.Cells[2, 34] = "TAT";
                xlWorkSheet.Cells[2, 35] = "Reason for the delay";

                int i = 3, k = 1, rcnt = 0;
                CommonClass Cs = new CommonClass();
                if (rows.Count == 0)
                {
                    //MessageBox.Show("No records found");
                    Cs.SendMail("", "Dear Team,<Br/><Br/>No records found", "Frontiers", false, "SPS_Report");
                    return true;
                }
                for (int j = 0; j < rows.Count; j++)
                {
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();//Journal
                    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();//Articleid
                    xlWorkSheet.Cells[i, 4] = rows[j][2].ToString();//Article type
                    xlWorkSheet.Cells[i, 5] = rows[j][3].ToString();//Received date
                    xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();//Sent date
                    xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();//FP TAT
                    xlWorkSheet.Cells[i, 8] = ""; //Reason for delay
                    xlWorkSheet.Cells[i, 9] = rows[j][6].ToString();//AU Received date 
                    xlWorkSheet.Cells[i, 10] = rows[j][7].ToString();//AU Uploaded date
                    xlWorkSheet.Cells[i, 11] = rows[j][8].ToString();//AU TAT
                    xlWorkSheet.Cells[i, 12] = "";
                    xlWorkSheet.Cells[i, 13] = rows[j][9].ToString();//AU1 Received date
                    xlWorkSheet.Cells[i, 14] = rows[j][10].ToString();//AU1 Uploaded date
                    xlWorkSheet.Cells[i, 15] = rows[j][11].ToString();//AU1 TAT
                    xlWorkSheet.Cells[i, 16] = rows[j][12].ToString();//AU2 Uploaded date
                    xlWorkSheet.Cells[i, 17] = rows[j][13].ToString();//AU2 Uploaded date
                    xlWorkSheet.Cells[i, 18] = rows[j][14].ToString();//AU2 TAT
                    xlWorkSheet.Cells[i, 19] = rows[j][15].ToString();//PP Received date
                    xlWorkSheet.Cells[i, 20] = rows[j][16].ToString();//PP Uploaded date
                    xlWorkSheet.Cells[i, 21] = rows[j][17].ToString();//PP TAT
                    xlWorkSheet.Cells[i, 22] = "";
                    xlWorkSheet.Cells[i, 23] = rows[j][18].ToString();//PP1 Received date
                    xlWorkSheet.Cells[i, 24] = rows[j][19].ToString();//PP1 Uploaded date
                    xlWorkSheet.Cells[i, 25] = rows[j][20].ToString();//PP1 TAT
                    xlWorkSheet.Cells[i, 26] = "";
                    xlWorkSheet.Cells[i, 27] = rows[j][21].ToString();//PP2 Received date
                    xlWorkSheet.Cells[i, 28] = rows[j][22].ToString();//PP2 Uploaded date
                    xlWorkSheet.Cells[i, 29] = rows[j][23].ToString();//PP2 TAT
                    xlWorkSheet.Cells[i, 30] = "";//Reason for delay

                    xlWorkSheet.Cells[i, 31] = rows[j][24].ToString();//FWD Received date
                    xlWorkSheet.Cells[i, 32] = rows[j][25].ToString();//FWD Uploaded date
                    xlWorkSheet.Cells[i, 33] = rows[j][26].ToString();//Publishing Day/Date
                    xlWorkSheet.Cells[i, 34] = rows[j][27].ToString();//TAT
                    xlWorkSheet.Cells[i, 35] = "";//Reason for delay

                    xlWorkSheet.Cells[i, 36] = rows[j][28].ToString();//Total TTP
                    xlWorkSheet.Cells[i, 37] = "";//Reason for delay
                    xlWorkSheet.Cells[i, 38] = rows[j][29].ToString();//Pages
                    xlWorkSheet.Cells[i, 39] = rows[j][30].ToString();//CE LEVEL

                    //if (rows[j][4].ToString() != "")
                    //{
                    //    if (Convert.ToInt32(rows[j][4].ToString()) < 0)
                    //    {
                    //        xlWorkSheet.Cells[i, 6] = 0;
                    //    }
                    //    else
                    //    {
                    //        xlWorkSheet.Cells[i, 6] = Convert.ToInt32(rows[j][4].ToString());
                    //    }
                    //}
                    //else xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();
                    //xlWorkSheet.Cells[i, 7] = "";
                    //xlWorkSheet.Cells[i, 8] = rows[j][5].ToString();
                    //if (rows[j][6].ToString() != "")
                    //{
                    //    if (Convert.ToInt32(rows[j][6].ToString()) < 0)
                    //    {
                    //        xlWorkSheet.Cells[i, 9] = 0;
                    //    }
                    //    else
                    //    {
                    //        xlWorkSheet.Cells[i, 9] = Convert.ToInt32(rows[j][6].ToString());
                    //    }
                    //}
                    //else xlWorkSheet.Cells[i, 9] = rows[j][6].ToString();
                    //xlWorkSheet.Cells[i, 10] = "";
                    //xlWorkSheet.Cells[i, 11] = rows[j][7].ToString();
                    //if (rows[j][8].ToString() != "")
                    //{
                    //    if (Convert.ToInt32(rows[j][8].ToString()) < 0)
                    //    {
                    //        xlWorkSheet.Cells[i, 12] = 0;
                    //    }
                    //    else
                    //    {
                    //        xlWorkSheet.Cells[i, 12] = Convert.ToInt32(rows[j][8].ToString());
                    //    }
                    //}
                    //else xlWorkSheet.Cells[i, 12] = rows[j][8].ToString();
                    //xlWorkSheet.Cells[i, 13] = "";
                    //xlWorkSheet.Cells[i, 14] = rows[j][9].ToString();
                    //if (rows[j][10].ToString() != "")
                    //{
                    //    if (Convert.ToInt32(rows[j][10].ToString()) < 0)
                    //    {
                    //        xlWorkSheet.Cells[i, 15] = 0;
                    //    }
                    //    else
                    //    {
                    //        xlWorkSheet.Cells[i, 15] = Convert.ToInt32(rows[j][10].ToString());
                    //    }
                    //}
                    //else xlWorkSheet.Cells[i, 15] = rows[j][10].ToString();
                    //xlWorkSheet.Cells[i, 16] = "";
                    //xlWorkSheet.Cells[i, 17] = rows[j][11].ToString();
                    //xlWorkSheet.Cells[i, 18] = rows[j][12].ToString();
                    //if (rows[j][13].ToString() != "")
                    //{
                    //    if (Convert.ToInt32(rows[j][13].ToString()) < 0)
                    //    {
                    //        xlWorkSheet.Cells[i, 19] = 0;
                    //    }
                    //    else
                    //    {
                    //        xlWorkSheet.Cells[i, 19] = Convert.ToInt32(rows[j][13].ToString());
                    //    }
                    //}
                    //else xlWorkSheet.Cells[i, 19] = rows[j][13].ToString(); //"1";
                    //xlWorkSheet.Cells[i, 20] = "";
                    //xlWorkSheet.Cells[i, 21] = rows[j][14].ToString();
                    //if (rows[j][15].ToString() != "")
                    //{
                    //    if (Convert.ToInt32(rows[j][15].ToString()) < 0)
                    //    {
                    //        xlWorkSheet.Cells[i, 22] = 0;
                    //    }
                    //    else
                    //    {
                    //        xlWorkSheet.Cells[i, 22] = Convert.ToInt32(rows[j][15].ToString());
                    //    }
                    //}
                    //else xlWorkSheet.Cells[i, 22] = rows[j][15].ToString();
                    //xlWorkSheet.Cells[i, 23] = "";
                    //if (rows[j][16].ToString() != "")
                    //{
                    //    if (Convert.ToInt32(rows[j][16].ToString()) < 0)
                    //    {
                    //        xlWorkSheet.Cells[i, 24] = 0;
                    //    }
                    //    else
                    //    {
                    //        xlWorkSheet.Cells[i, 24] = Convert.ToInt32(rows[j][16].ToString());
                    //    }
                    //}
                    //else xlWorkSheet.Cells[i, 24] = rows[j][16].ToString();
                    //xlWorkSheet.Cells[i, 25] = rows[j][17].ToString();
                    //xlWorkSheet.Cells[i, 26] = rows[j][18].ToString();
                    i++;
                    k++;
                    rcnt++;
                }
                chartRange = xlWorkSheet.get_Range("A1", "AM" + (i - 1));
                CellAlignment(chartRange);
                chartRange = xlWorkSheet.get_Range("A1", "AM2");
                chartRange.Font.Bold = true;
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;

                //xlWorkSheet.Cells[i + 1, 5] = "Responsibility: Pre-edit, Copyedit, Production Teams";
                //chartRange = xlWorkSheet.get_Range("E" + (i + 1), "H" + (i + 1));
                //chartRange.Merge();
                //chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
                //xlWorkSheet.Cells[i + 1, 11] = "Responsibility: Project Management";
                //chartRange = xlWorkSheet.get_Range("I" + (i + 1), "L" + (i + 1));
                //chartRange.Merge();
                //chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
                //xlWorkSheet.Cells[i + 1, 14] = "Responsibility: Production Team";
                //chartRange = xlWorkSheet.get_Range("M" + (i + 1), "R" + (i + 1));
                //chartRange.Merge();
                //chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
                //xlWorkSheet.Cells[i + 1, 17] = "Responsibility: Project Management and Production Teams";
                //chartRange = xlWorkSheet.get_Range("S" + (i + 1), "V" + (i + 1));
                //chartRange.Merge();
                //chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
                //xlWorkSheet.Cells[i + 1, 21] = "Responsibility: PAP/Online Team";
                //chartRange = xlWorkSheet.get_Range("W" + (i + 1), "AD" + (i + 1));
                //chartRange.Merge();
                //chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;

                chartRange = xlWorkSheet.get_Range("E1", "H1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
                chartRange = xlWorkSheet.get_Range("I1", "L1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
                chartRange = xlWorkSheet.get_Range("M1", "R1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
                chartRange = xlWorkSheet.get_Range("S1", "V1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
                chartRange = xlWorkSheet.get_Range("W1", "AD1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbCornflowerBlue;
                chartRange = xlWorkSheet.get_Range("AE1", "AI1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbDarkOliveGreen;
                if (!(Directory.Exists(System.Environment.CurrentDirectory + @"\Frontiers_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\AIP_Report\");
                string fname = System.Environment.CurrentDirectory + @"\Frontiers_Report\Frontiers_Excel_Report_" + DateTime.Now.ToString("ddMMyyyy") + @".xlsx";
                xlWorkSheet.SaveAs(fname);
                xlApp.Quit();
                System.Threading.Thread.Sleep(5000);
                Cs.SendMail("", "Dear Team,<Br/><Br/>Kindly find the attached today's report", "Frontiers", false, "SPS_Report", fname, "Frontiers TTP Report");
                System.Threading.Thread.Sleep(5000);
                //System.Diagnostics.Process.Start(fname);
                return true;
            }
            catch (Exception e)
            {
                //MessageBox.Show("Error: " + e.Message + "\n" + e.StackTrace);
                System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("saravanakumar@novatechset.com", "tiworkflow@novatechset.com", "Frontiers_Excel_Report: " + DateTime.Today.ToString("dd/MM/yyyy"), "Error while generating report: " + e.Message + "<Br/>" + e.StackTrace + "<Br/><Br/>Regards,<Br/>TechSupport.");
                System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                MM.IsBodyHtml = true;
                client.Send(MM);
                return false;
            }
        }
        
        public bool SAGE_PM_CreateReport()
        {
            try
            {
                foreach (Process P in Process.GetProcessesByName("EXCEL"))
                {
                    try
                    {
                        P.Kill();
                    }
                    catch (Exception e) { }
                }
                DBClass db = new DBClass();
                //string Q1 = "WITH T1 AS (SELECT DISTINCT Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID,ArtType_Name, CASE WHEN isnull(Proof_Pages,0)<>0 THEN Proof_Pages WHEN Artcl_TextFolios IS NULL OR Artcl_TextFolios='' THEN 0 ELSE Artcl_TextFolios END AS [Pages], Artcl_UploadedDt AS Artcl_UploadedDt, Artcl_Status AS Status, Artcl_ReceivedDt, Artcl_DueDtCats, Artcl_ScheduledDt,isnull(Artcl_PII,'') as Artcl_PII FROM Article,  Journal,ArticleTypes WHERE Artcl_JrnlId=Jrnl_Id and Artcl_ArtType=ArtType_ID  AND Jrnl_PublID=4 and CHARINDEX('_',Artcl_ArticleId)=0)  , T2 as (SELECT MAX(JRST_ID) AS maxid,JRA_ArticleID AS ArticleID FROM JR_Articles, JR_Main, JR_Stage_Tran, Journal where JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_ID AND JRM_JournalID=Jrnl_Id AND Jrnl_PublID=4 AND JRA_ArticleID IN(SELECT ISNULL(Artcl_ArticleId,'') AS ArticleID FROM Article,  Journal,ArticleTypes WHERE   Artcl_ArtType=ArtType_ID and Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=4and CHARINDEX('_',Artcl_ArticleId)=0) GROUP BY JRA_ArticleID) SELECT DISTINCT t1.JrnlID, t1.ArticleID, t1.[Pages],  CASE WHEN t2.maxid IS NULL THEN T1.Status ELSE PrcsMst_Name END AS 'Last Stage Status',CASE WHEN t2.maxid IS NULL  THEN 'First Proof'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0) or (CHARINDEX('PM',JRS_StageName)>0)) THEN 'Author/PM Correction'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0) or (CHARINDEX('PM',JRS_StageName)>0)) THEN 'Author/PM Correction'  WHEN  CHARINDEX('PAP',JRS_StageName)>0  THEN 'PAP' ELSE '' END as 'Last Stage',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ReceivedDt ELSE JR_Stage_Tran.JRST_ReceivedDt END AS 'ReceivedDate',CASE WHEN t2.maxid IS NULL THEN (CASE WHEN T1.Artcl_DueDtCats<T1.Artcl_ScheduledDt then T1.Artcl_ScheduledDt else T1.Artcl_DueDtCats END) ELSE (CASE WHEN JR_Stage_Tran.JRST_DueDtCats IS NULL then JR_Stage_Tran.JRST_ScheduledDt ELSE JR_Stage_Tran.JRST_DueDtCats END)  END AS 'DueDate',     Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end as UploadDt,isnull(t1.Artcl_PII,'') as Workflow,t1.ArtType_Name  from T1 Left outer join T2 on t1.ArticleID=t2.ArticleID LEFT OUTER JOIN JR_Stage_Tran on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages ON JR_Stage_Tran.JRST_JRS_ID=JR_Stages.JRS_ID LEFT OUTER JOIN ProcessMst ON JRST_Status=PrcsMst_Id WHERE Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end=''  order by ArticleID";
                //string Q1 = "WITH T1 AS (SELECT DISTINCT Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID,ArtType_Name, CASE WHEN isnull(Proof_Pages,0)<>0 THEN Proof_Pages WHEN Artcl_TextFolios IS NULL OR Artcl_TextFolios='' THEN 0 ELSE Artcl_TextFolios END AS [Pages], Artcl_UploadedDt AS Artcl_UploadedDt, Artcl_Status AS Status, Artcl_ReceivedDt, Artcl_DueDtCats, Artcl_ScheduledDt,isnull(Artcl_PII,'') as Artcl_PII,Jrnl_Contact FROM Article,  Journal,ArticleTypes WHERE Artcl_JrnlId=Jrnl_Id and Artcl_ArtType=ArtType_ID  AND Jrnl_PublID=4 and CHARINDEX('_',Artcl_ArticleId)=0)  , T2 as (SELECT MAX(JRST_ID) AS maxid,JRA_ArticleID AS ArticleID FROM JR_Articles, JR_Main, JR_Stage_Tran, Journal where JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_ID AND JRM_JournalID=Jrnl_Id AND Jrnl_PublID=4 AND JRA_ArticleID IN(SELECT ISNULL(Artcl_ArticleId,'') AS ArticleID FROM Article,  Journal,ArticleTypes WHERE   Artcl_ArtType=ArtType_ID and Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=4and CHARINDEX('_',Artcl_ArticleId)=0) GROUP BY JRA_ArticleID) SELECT DISTINCT t1.JrnlID, t1.ArticleID, t1.[Pages],  CASE WHEN t2.maxid IS NULL THEN T1.Status ELSE PrcsMst_Name END AS 'Last Stage Status',CASE WHEN t2.maxid IS NULL  THEN 'First Proof'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0) or (CHARINDEX('PM',JRS_StageName)>0)) THEN 'Author/PM Correction'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0) or (CHARINDEX('PM',JRS_StageName)>0)) THEN 'Author/PM Correction'  WHEN  CHARINDEX('PAP',JRS_StageName)>0  THEN 'PAP' ELSE '' END as 'Last Stage',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ReceivedDt ELSE JR_Stage_Tran.JRST_ReceivedDt END AS 'ReceivedDate',CASE WHEN t2.maxid IS NULL THEN (CASE WHEN T1.Artcl_DueDtCats<T1.Artcl_ScheduledDt then T1.Artcl_ScheduledDt else T1.Artcl_DueDtCats END) ELSE (CASE WHEN JR_Stage_Tran.JRST_DueDtCats IS NULL then JR_Stage_Tran.JRST_ScheduledDt ELSE JR_Stage_Tran.JRST_DueDtCats END)  END AS 'DueDate',     Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end as UploadDt,isnull(t1.Artcl_PII,'') as Workflow,t1.ArtType_Name,Jrnl_Contact  from T1 Left outer join T2 on t1.ArticleID=t2.ArticleID LEFT OUTER JOIN JR_Stage_Tran on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages ON JR_Stage_Tran.JRST_JRS_ID=JR_Stages.JRS_ID LEFT OUTER JOIN ProcessMst ON JRST_Status=PrcsMst_Id WHERE Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end=''  order by ArticleID";
                string Q1 = "SSP_AutoReport 8";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rows = ds.Tables[0].Rows;
                Xl.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                Xl.Workbook xlWorkBook;
                Xl.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                System.Collections.ArrayList JRlist = new System.Collections.ArrayList();
                System.Collections.ArrayList JRStagelist = new System.Collections.ArrayList();
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Name = "Comp. Report - WIP";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "Sr. No.";
                xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                xlWorkSheet.Cells[1, 3] = "Article ID";
                xlWorkSheet.Cells[1, 4] = "Curr. Activity";
                xlWorkSheet.Cells[1, 5] = "Pages";
                xlWorkSheet.Cells[1, 6] = "Submission";
                xlWorkSheet.Cells[1, 7] = "Recd Date";
                xlWorkSheet.Cells[1, 8] = "Due Date";
                xlWorkSheet.Cells[1, 9] = "Article Type";
                xlWorkSheet.Cells[1, 10] = "CopyRight";
                xlWorkSheet.Cells[1, 11] = "Days from MS Received";
                xlWorkSheet.Cells[1, 12] = "PM";
                int i = 2, k = 1, rcnt = 0;
                CommonClass Cs = new CommonClass();
                if (rows.Count == 0)
                {
                    Cs.SendMail("", "Dear Team,<Br/><Br/>No records found", "SAGE", false, "SAGE_Report");
                    return true;
                }
                for (int j = 0; j < rows.Count; j++)
                {
                    if ((rows[j][0].ToString() == "") || (rows[j][0].ToString() == "SAMPLE") || (rows[j][4].ToString() == ""))
                    {
                        continue;
                    }
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                    if (!JRlist.Contains(rows[j][0].ToString()))
                    {
                        JRlist.Add(rows[j][0].ToString());
                    }
                    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();
                    if (rows[j][3].ToString().ToUpper() == "CE-QC" || rows[j][3].ToString().ToUpper() == "CE")
                    {
                        xlWorkSheet.Cells[i, 4] = "CE";
                    }
                    else if (rows[j][3].ToString().ToUpper() == "QC")
                    {
                        xlWorkSheet.Cells[i, 4] = "QC";
                    }
                    else if (rows[j][3].ToString().ToUpper() == "INCOMPLETE")
                    {
                        xlWorkSheet.Cells[i, 4] = "PR2";
                    }
                    else
                    {
                        xlWorkSheet.Cells[i, 4] = rows[j][3].ToString();
                    }
                    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();
                    xlWorkSheet.Cells[i, 8] = rows[j][6].ToString();
                    try
                    {
                        if (Convert.ToDateTime(rows[j][6].ToString()).Date < DateTime.Today.Date)
                        {
                            Xl.Range chartRange1 = xlWorkSheet.get_Range("A" + i.ToString(), "L" + i.ToString());
                            chartRange1.Interior.Color = Xl.XlRgbColor.rgbBisque;
                        }
                    }
                    catch (Exception e) { }
                    xlWorkSheet.Cells[i, 9] = rows[j][9].ToString();
                    xlWorkSheet.Cells[i, 10] = "";
                    try
                    {
                        xlWorkSheet.Cells[i, 11] = Cs.ReturnDays(Convert.ToDateTime(rows[j][5].ToString()).Date, db, DateTime.Today);
                    }
                    catch (Exception e) { }
                    xlWorkSheet.Cells[i, 12] = rows[j][10].ToString();
                    i++;
                    k++;
                    rcnt++;
                }
                Xl.Range chartRange = xlWorkSheet.get_Range("A1", "L" + (rcnt + 1));
                CellAlignment(chartRange);
                chartRange = xlWorkSheet.get_Range("A1", "L1");
                chartRange.Font.Bold = true;
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                //***
                //JRlist = new System.Collections.ArrayList();
                //JRStagelist = new System.Collections.ArrayList();
                //xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.Add();
                ////xlWorkSheet.Name = "In Progress Comp. Report - WIP";
                //xlWorkSheet.Cells.NumberFormat = "@";
                //xlWorkSheet.Cells[1, 1] = "Sr. No.";
                //xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                //xlWorkSheet.Cells[1, 3] = "Article ID";
                //xlWorkSheet.Cells[1, 4] = "Curr. Activity";
                //xlWorkSheet.Cells[1, 5] = "Pages";
                //xlWorkSheet.Cells[1, 6] = "Submission";
                //xlWorkSheet.Cells[1, 7] = "Recd Date";
                //xlWorkSheet.Cells[1, 8] = "Due Date";
                //xlWorkSheet.Cells[1, 9] = "Article Type";
                //xlWorkSheet.Cells[1, 10] = "CopyRight";
                //xlWorkSheet.Cells[1, 11] = "Days from MS Received";
                //xlWorkSheet.Cells[1, 12] = "PM";
                //i = 2; k = 1; rcnt = 0;
                //for (int j = 0; j < rows.Count; j++)
                //{
                //    if ((rows[j][0].ToString() == "") || (rows[j][0].ToString() == "SAMPLE") || (rows[j][4].ToString() == "") || rows[j][3].ToString().ToUpper() == "HOLD")
                //    {
                //        continue;
                //    }
                //    xlWorkSheet.Cells[i, 1] = k;
                //    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                //    if (!JRlist.Contains(rows[j][0].ToString()))
                //    {
                //        JRlist.Add(rows[j][0].ToString());
                //    }
                //    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();
                //    if (rows[j][3].ToString().ToUpper() == "CE-QC" || rows[j][3].ToString().ToUpper() == "CE")
                //    {
                //        xlWorkSheet.Cells[i, 4] = "CE";
                //    }
                //    else if (rows[j][3].ToString().ToUpper() == "QC")
                //    {
                //        xlWorkSheet.Cells[i, 4] = "QC";
                //    }
                //    else if (rows[j][3].ToString().ToUpper() == "INCOMPLETE")
                //    {
                //        xlWorkSheet.Cells[i, 4] = "PR2";
                //    }
                //    else
                //    {
                //        xlWorkSheet.Cells[i, 4] = rows[j][3].ToString();
                //    }
                //    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                //    xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();
                //    xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();
                //    xlWorkSheet.Cells[i, 8] = rows[j][6].ToString();
                //    try
                //    {
                //        if (Convert.ToDateTime(rows[j][6].ToString()).Date < DateTime.Today.Date)
                //        {
                //            Xl.Range chartRange1 = xlWorkSheet.get_Range("A" + i.ToString(), "L" + i.ToString());
                //            chartRange1.Interior.Color = Xl.XlRgbColor.rgbBisque;
                //        }
                //    }
                //    catch (Exception e) { }
                //    xlWorkSheet.Cells[i, 9] = rows[j][9].ToString();
                //    xlWorkSheet.Cells[i, 10] = "";
                //    try
                //    {
                //        xlWorkSheet.Cells[i, 11] = Cs.ReturnDays(Convert.ToDateTime(rows[j][5].ToString()).Date, db, DateTime.Today);
                //    }
                //    catch (Exception e) { }
                //    xlWorkSheet.Cells[i, 12] = rows[j][10].ToString();
                //    i++;
                //    k++;
                //    rcnt++;
                //}
                //chartRange = xlWorkSheet.get_Range("A1", "L" + (rcnt + 1));
                //CellAlignment(chartRange);
                //chartRange = xlWorkSheet.get_Range("A1", "L1");
                //chartRange.Font.Bold = true;
                //chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                //***
                //JRlist = new System.Collections.ArrayList();
                //JRStagelist = new System.Collections.ArrayList();
                //xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.Add();
                ////xlWorkSheet.Name = "On Hold Comp. Report - WIP";
                //xlWorkSheet.Cells.NumberFormat = "@";
                //xlWorkSheet.Cells[1, 1] = "Sr. No.";
                //xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                //xlWorkSheet.Cells[1, 3] = "Article ID";
                //xlWorkSheet.Cells[1, 4] = "Curr. Activity";
                //xlWorkSheet.Cells[1, 5] = "Pages";
                //xlWorkSheet.Cells[1, 6] = "Submission";
                //xlWorkSheet.Cells[1, 7] = "Recd Date";
                //xlWorkSheet.Cells[1, 8] = "Due Date";
                //xlWorkSheet.Cells[1, 9] = "Article Type";
                //xlWorkSheet.Cells[1, 10] = "CopyRight";
                //xlWorkSheet.Cells[1, 11] = "Days from MS Received";
                //xlWorkSheet.Cells[1, 12] = "PM";
                //i = 2; k = 1; rcnt = 0;
                //for (int j = 0; j < rows.Count; j++)
                //{
                //    if ((rows[j][0].ToString() == "") || (rows[j][0].ToString() == "SAMPLE") || (rows[j][4].ToString() == "") || rows[j][3].ToString().ToUpper() != "HOLD")
                //    {
                //        continue;
                //    }
                //    xlWorkSheet.Cells[i, 1] = k;
                //    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                //    if (!JRlist.Contains(rows[j][0].ToString()))
                //    {
                //        JRlist.Add(rows[j][0].ToString());
                //    }
                //    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();
                //    if (rows[j][3].ToString().ToUpper() == "CE-QC" || rows[j][3].ToString().ToUpper() == "CE")
                //    {
                //        xlWorkSheet.Cells[i, 4] = "CE";
                //    }
                //    else if (rows[j][3].ToString().ToUpper() == "QC")
                //    {
                //        xlWorkSheet.Cells[i, 4] = "QC";
                //    }
                //    else if (rows[j][3].ToString().ToUpper() == "INCOMPLETE")
                //    {
                //        xlWorkSheet.Cells[i, 4] = "PR2";
                //    }
                //    else
                //    {
                //        xlWorkSheet.Cells[i, 4] = rows[j][3].ToString();
                //    }
                //    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                //    xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();
                //    xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();
                //    xlWorkSheet.Cells[i, 8] = rows[j][6].ToString();
                //    try
                //    {
                //        if (Convert.ToDateTime(rows[j][6].ToString()).Date < DateTime.Today.Date)
                //        {
                //            Xl.Range chartRange1 = xlWorkSheet.get_Range("A" + i.ToString(), "L" + i.ToString());
                //            chartRange1.Interior.Color = Xl.XlRgbColor.rgbBisque;
                //        }
                //    }
                //    catch (Exception e) { }
                //    xlWorkSheet.Cells[i, 9] = rows[j][9].ToString();
                //    xlWorkSheet.Cells[i, 10] = "";
                //    try
                //    {
                //        xlWorkSheet.Cells[i, 11] = Cs.ReturnDays(Convert.ToDateTime(rows[j][5].ToString()).Date, db, DateTime.Today);
                //    }
                //    catch (Exception e) { }
                //    xlWorkSheet.Cells[i, 12] = rows[j][10].ToString();
                //    i++;
                //    k++;
                //    rcnt++;
                //}
                //chartRange = xlWorkSheet.get_Range("A1", "L" + (rcnt + 1));
                //CellAlignment(chartRange);
                //chartRange = xlWorkSheet.get_Range("A1", "L1");
                //chartRange.Font.Bold = true;
                //chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                ////***    
                //***
                JRlist = new System.Collections.ArrayList();
                JRStagelist = new System.Collections.ArrayList();
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.Add();
                xlWorkSheet.Name = "MC-Query Report";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "Sr. No.";
                xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                xlWorkSheet.Cells[1, 3] = "Article ID";
                xlWorkSheet.Cells[1, 4] = "Curr. Activity";
                xlWorkSheet.Cells[1, 5] = "Pages";
                xlWorkSheet.Cells[1, 6] = "Submission";
                xlWorkSheet.Cells[1, 7] = "Recd Date";
                xlWorkSheet.Cells[1, 8] = "Due Date";
                xlWorkSheet.Cells[1, 9] = "Article Type";
                xlWorkSheet.Cells[1, 10] = "CopyRight";
                xlWorkSheet.Cells[1, 11] = "Days from MS Received";
                xlWorkSheet.Cells[1, 12] = "PM";
                i = 2; k = 1; rcnt = 0;
                for (int j = 0; j < rows.Count; j++)
                {
                    if ((rows[j][0].ToString() == "") || (rows[j][0].ToString() == "SAMPLE") || (rows[j][4].ToString() == "") || rows[j][3].ToString().ToUpper() != "MC-QUERY")
                    {
                        continue;
                    }
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                    if (!JRlist.Contains(rows[j][0].ToString()))
                    {
                        JRlist.Add(rows[j][0].ToString());
                    }
                    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();
                    if (rows[j][3].ToString().ToUpper() == "CE-QC" || rows[j][3].ToString().ToUpper() == "CE")
                    {
                        xlWorkSheet.Cells[i, 4] = "CE";
                    }
                    else if (rows[j][3].ToString().ToUpper() == "QC")
                    {
                        xlWorkSheet.Cells[i, 4] = "QC";
                    }
                    else if (rows[j][3].ToString().ToUpper() == "INCOMPLETE")
                    {
                        xlWorkSheet.Cells[i, 4] = "PR2";
                    }
                    else
                    {
                        xlWorkSheet.Cells[i, 4] = rows[j][3].ToString();
                    }
                    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();
                    xlWorkSheet.Cells[i, 8] = rows[j][6].ToString();
                    try
                    {
                        if (Convert.ToDateTime(rows[j][6].ToString()).Date < DateTime.Today.Date)
                        {
                            Xl.Range chartRange1 = xlWorkSheet.get_Range("A" + i.ToString(), "L" + i.ToString());
                            chartRange1.Interior.Color = Xl.XlRgbColor.rgbBisque;
                        }
                    }
                    catch (Exception e) { }
                    xlWorkSheet.Cells[i, 9] = rows[j][9].ToString();
                    xlWorkSheet.Cells[i, 10] = "";
                    try
                    {
                        xlWorkSheet.Cells[i, 11] = Cs.ReturnDays(Convert.ToDateTime(rows[j][5].ToString()).Date, db, DateTime.Today);
                    }
                    catch (Exception e) { }
                    xlWorkSheet.Cells[i, 12] = rows[j][10].ToString();
                    i++;
                    k++;
                    rcnt++;
                }
                chartRange = xlWorkSheet.get_Range("A1", "L" + (rcnt + 1));
                CellAlignment(chartRange);
                chartRange = xlWorkSheet.get_Range("A1", "L1");
                chartRange.Font.Bold = true;
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                //***    
                //***
                JRlist = new System.Collections.ArrayList();
                JRStagelist = new System.Collections.ArrayList();
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.Add();
                xlWorkSheet.Name = "PMChk Report";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "Sr. No.";
                xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                xlWorkSheet.Cells[1, 3] = "Article ID";
                xlWorkSheet.Cells[1, 4] = "Curr. Activity";
                xlWorkSheet.Cells[1, 5] = "Pages";
                xlWorkSheet.Cells[1, 6] = "Submission";
                xlWorkSheet.Cells[1, 7] = "Recd Date";
                xlWorkSheet.Cells[1, 8] = "Due Date";
                xlWorkSheet.Cells[1, 9] = "Article Type";
                xlWorkSheet.Cells[1, 10] = "CopyRight";
                xlWorkSheet.Cells[1, 11] = "Days from MS Received";
                xlWorkSheet.Cells[1, 12] = "PM";
                i = 2; k = 1; rcnt = 0;
                for (int j = 0; j < rows.Count; j++)
                {
                    if ((rows[j][0].ToString() == "") || (rows[j][0].ToString() == "SAMPLE") || (rows[j][4].ToString() == "") || rows[j][3].ToString().ToUpper() != "PMCHK")
                    {
                        continue;
                    }
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                    if (!JRlist.Contains(rows[j][0].ToString()))
                    {
                        JRlist.Add(rows[j][0].ToString());
                    }
                    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();
                    if (rows[j][3].ToString().ToUpper() == "CE-QC" || rows[j][3].ToString().ToUpper() == "CE")
                    {
                        xlWorkSheet.Cells[i, 4] = "CE";
                    }
                    else if (rows[j][3].ToString().ToUpper() == "QC")
                    {
                        xlWorkSheet.Cells[i, 4] = "QC";
                    }
                    else if (rows[j][3].ToString().ToUpper() == "INCOMPLETE")
                    {
                        xlWorkSheet.Cells[i, 4] = "PR2";
                    }
                    else
                    {
                        xlWorkSheet.Cells[i, 4] = rows[j][3].ToString();
                    }
                    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();
                    xlWorkSheet.Cells[i, 8] = rows[j][6].ToString();
                    try
                    {
                        if (Convert.ToDateTime(rows[j][6].ToString()).Date < DateTime.Today.Date)
                        {
                            Xl.Range chartRange1 = xlWorkSheet.get_Range("A" + i.ToString(), "L" + i.ToString());
                            chartRange1.Interior.Color = Xl.XlRgbColor.rgbBisque;
                        }
                    }
                    catch (Exception e) { }
                    xlWorkSheet.Cells[i, 9] = rows[j][9].ToString();
                    xlWorkSheet.Cells[i, 10] = "";
                    try
                    {
                        xlWorkSheet.Cells[i, 11] = Cs.ReturnDays(Convert.ToDateTime(rows[j][5].ToString()).Date, db, DateTime.Today);
                    }
                    catch (Exception e) { }
                    xlWorkSheet.Cells[i, 12] = rows[j][10].ToString();
                    i++;
                    k++;
                    rcnt++;
                }
                chartRange = xlWorkSheet.get_Range("A1", "L" + (rcnt + 1));
                CellAlignment(chartRange);
                chartRange = xlWorkSheet.get_Range("A1", "L1");
                chartRange.Font.Bold = true;
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                //***    
                Q1 = "WITH T1 AS (SELECT DISTINCT Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID,ArtType_Name, CASE WHEN isnull(Proof_Pages,0)<>0 THEN Proof_Pages WHEN Artcl_TextFolios IS NULL OR Artcl_TextFolios='' THEN 0 ELSE Artcl_TextFolios END AS [Pages], Artcl_UploadedDt AS Artcl_UploadedDt, Artcl_Status AS Status, Artcl_ReceivedDt, Artcl_ScheduledDt,isnull(Artcl_PII,'') as Artcl_PII FROM Article,  Journal,ArticleTypes WHERE Artcl_JrnlId=Jrnl_Id and Artcl_ArtType=ArtType_ID  AND Jrnl_PublID=10 and CHARINDEX('_',Artcl_ArticleId)=0)  , T2 as (SELECT MAX(JRST_ID) AS maxid,JRA_ArticleID AS ArticleID FROM JR_Articles, JR_Main, JR_Stage_Tran, Journal where JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_ID AND JRM_JournalID=Jrnl_Id AND Jrnl_PublID=4 AND JRA_ArticleID IN(SELECT ISNULL(Artcl_ArticleId,'') AS ArticleID FROM Article,  Journal,ArticleTypes WHERE   Artcl_ArtType=ArtType_ID and Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=4and CHARINDEX('_',Artcl_ArticleId)=0) GROUP BY JRA_ArticleID) SELECT DISTINCT t1.JrnlID, t1.ArticleID, t1.[Pages],  CASE WHEN t2.maxid IS NULL THEN T1.Status ELSE PrcsMst_Name END AS 'Last Stage Status',CASE WHEN t2.maxid IS NULL  THEN 'First Proof'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0) or (CHARINDEX('PM',JRS_StageName)>0)) THEN 'Author/PM Correction'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0) or (CHARINDEX('PM',JRS_StageName)>0)) THEN 'Author/PM Correction'  WHEN  CHARINDEX('PAP',JRS_StageName)>0  THEN 'PAP' ELSE '' END as 'Last Stage',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ReceivedDt ELSE JR_Stage_Tran.JRST_ReceivedDt END AS 'ReceivedDate',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ScheduledDt  ELSE (CASE WHEN JR_Stage_Tran.JRST_DueDtCats IS NULL then JR_Stage_Tran.JRST_ScheduledDt ELSE JR_Stage_Tran.JRST_DueDtCats END)  END AS 'DueDate',     Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end as UploadDt,isnull(t1.Artcl_PII,'') as Workflow,t1.ArtType_Name  from T1 Left outer join T2 on t1.ArticleID=t2.ArticleID LEFT OUTER JOIN JR_Stage_Tran on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages ON JR_Stage_Tran.JRST_JRS_ID=JR_Stages.JRS_ID LEFT OUTER JOIN ProcessMst ON JRST_Status=PrcsMst_Id WHERE Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end=''  order by ArticleID";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnectionBlr()));
                db.OpenConnectionBlr();
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnectionBlr();
                ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                rows = ds.Tables[0].Rows;
                if (rows.Count == 0)
                {
                    Cs.SendMail("", "Dear Team,<Br/><Br/>No records found. SRN Bangalore.", "SAGE", false, "SAGE_Report");
                    goto Skip;
                }
                //JRlist = new System.Collections.ArrayList();
                //JRStagelist = new System.Collections.ArrayList();
                //xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.Add();
                ////xlWorkSheet.Name = "SRN Comp. Report - WIP";
                //xlWorkSheet.Cells.NumberFormat = "@";
                //xlWorkSheet.Cells[1, 1] = "Sr. No.";
                //xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                //xlWorkSheet.Cells[1, 3] = "Article ID";
                //xlWorkSheet.Cells[1, 4] = "Curr. Activity";
                //xlWorkSheet.Cells[1, 5] = "Pages";
                //xlWorkSheet.Cells[1, 6] = "Submission";
                //xlWorkSheet.Cells[1, 7] = "Recd Date";
                //xlWorkSheet.Cells[1, 8] = "Due Date";
                //xlWorkSheet.Cells[1, 9] = "Article Type";
                //xlWorkSheet.Cells[1, 10] = "CopyRight";
                //i = 2; k = 1; rcnt = 0;
                //for (int j = 0; j < rows.Count; j++)
                //{
                //    if ((rows[j][0].ToString() == "") || (rows[j][0].ToString() == "SAMPLE") || (rows[j][4].ToString() == ""))
                //    {
                //        continue;
                //    }
                //    xlWorkSheet.Cells[i, 1] = k;
                //    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                //    if (!JRlist.Contains(rows[j][0].ToString()))
                //    {
                //        JRlist.Add(rows[j][0].ToString());
                //    }
                //    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();
                //    //if (rows[j][3].ToString().ToUpper() == "CE-QC" || rows[j][3].ToString().ToUpper() == "CE")
                //    //{
                //    //    xlWorkSheet.Cells[i, 4] = "CE";
                //    //}
                //    //else if (rows[j][3].ToString().ToUpper() == "QC")
                //    //{
                //    //    xlWorkSheet.Cells[i, 4] = "QC";
                //    //}
                //    //else if (rows[j][3].ToString().ToUpper() == "INCOMPLETE")
                //    //{
                //    //    xlWorkSheet.Cells[i, 4] = "PR2";
                //    //}
                //    //else
                //    //{
                //    xlWorkSheet.Cells[i, 4] = rows[j][3].ToString();
                //    //}
                //    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                //    xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();
                //    xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();
                //    xlWorkSheet.Cells[i, 8] = rows[j][6].ToString();
                //    try
                //    {
                //        if (Convert.ToDateTime(rows[j][6].ToString()).Date < DateTime.Today.Date)
                //        {
                //            Xl.Range chartRange1 = xlWorkSheet.get_Range("A" + i.ToString(), "J" + i.ToString());
                //            chartRange1.Interior.Color = Xl.XlRgbColor.rgbBisque;
                //        }
                //    }
                //    catch (Exception e) { }
                //    xlWorkSheet.Cells[i, 9] = rows[j][9].ToString();
                //    xlWorkSheet.Cells[i, 10] = "";
                //    i++;
                //    k++;
                //    rcnt++;
                //}
                //chartRange = xlWorkSheet.get_Range("A1", "J" + (rcnt + 1));
                //CellAlignment(chartRange);
                //chartRange = xlWorkSheet.get_Range("A1", "J1");
                //chartRange.Font.Bold = true;
                //chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
            //***       
                JRlist = new System.Collections.ArrayList();
                JRStagelist = new System.Collections.ArrayList();
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.Add();
                xlWorkSheet.Name = "PE CE Hold Report";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "Sr. No.";
                xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                xlWorkSheet.Cells[1, 3] = "Article ID";
                xlWorkSheet.Cells[1, 4] = "Curr. Activity";
                xlWorkSheet.Cells[1, 5] = "Pages";
                xlWorkSheet.Cells[1, 6] = "Submission";
                xlWorkSheet.Cells[1, 7] = "Recd Date";
                xlWorkSheet.Cells[1, 8] = "Due Date";
                xlWorkSheet.Cells[1, 9] = "Article Type";
                xlWorkSheet.Cells[1, 10] = "CopyRight";
                i = 2; k = 1; rcnt = 0;
                for (int j = 0; j < rows.Count; j++)
                {
                    if ((rows[j][0].ToString() == "") || (rows[j][0].ToString() == "SAMPLE") || (rows[j][4].ToString() == "") || rows[j][3].ToString().ToUpper() != "HOLD")
                    {
                        continue;
                    }
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                    if (!JRlist.Contains(rows[j][0].ToString()))
                    {
                        JRlist.Add(rows[j][0].ToString());
                    }
                    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();
                    //if (rows[j][3].ToString().ToUpper() == "CE-QC" || rows[j][3].ToString().ToUpper() == "CE")
                    //{
                    //    xlWorkSheet.Cells[i, 4] = "CE";
                    //}
                    //else if (rows[j][3].ToString().ToUpper() == "QC")
                    //{
                    //    xlWorkSheet.Cells[i, 4] = "QC";
                    //}
                    //else if (rows[j][3].ToString().ToUpper() == "INCOMPLETE")
                    //{
                    //    xlWorkSheet.Cells[i, 4] = "PR2";
                    //}
                    //else
                    //{
                    xlWorkSheet.Cells[i, 4] = rows[j][3].ToString();
                    //}
                    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();
                    xlWorkSheet.Cells[i, 8] = rows[j][6].ToString();
                    try
                    {
                        if (Convert.ToDateTime(rows[j][6].ToString()).Date < DateTime.Today.Date)
                        {
                            Xl.Range chartRange1 = xlWorkSheet.get_Range("A" + i.ToString(), "J" + i.ToString());
                            chartRange1.Interior.Color = Xl.XlRgbColor.rgbBisque;
                        }
                    }
                    catch (Exception e) { }
                    xlWorkSheet.Cells[i, 9] = rows[j][9].ToString();
                    xlWorkSheet.Cells[i, 10] = "";
                    i++;
                    k++;
                    rcnt++;
                }
                chartRange = xlWorkSheet.get_Range("A1", "J" + (rcnt + 1));
                CellAlignment(chartRange);
                chartRange = xlWorkSheet.get_Range("A1", "J1");
                chartRange.Font.Bold = true;
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
            //***       
            Skip:
                //Q1 = "select Jrnl_Acronym,Artcl_ArticleId,Proof_Pages,Artcl_ReceivedDt,Artcl_ScheduledDt,Artcl_UploadedDt,Jrnl_Contact from article,journal where Artcl_JrnlId=jrnl_id and Jrnl_PublID=4 and isnull(Artcl_UploadedDt,'')<>'' and isnull(Artcl_AUCorr_RecDT,'')='' and artcl_id>=1531456 and isnull(Artcl_PDFToAuthor,'')<>''";
                //Q1 = "  select Jrnl_Acronym,Artcl_ArticleId,Proof_Pages,Artcl_ReceivedDt,Artcl_ScheduledDt,Artcl_UploadedDt,Jrnl_Contact from article,journal where Artcl_JrnlId=jrnl_id and Jrnl_PublID=4 and isnull(Artcl_UploadedDt,'')<>'' and artcl_id>=1531456  and  (select count(*) from jr_main,JR_Stage_Tran where JRST_JRM_ID=JRM_ID and (JRST_JRS_ID='35' or JRST_JRS_ID='58') and Artcl_ArticleId=JRM_ArticleID) = 0 and CHARINDEX('_',Artcl_ArticleId)=0 and isnull(Inv_OtherTypesetter,'')<>'Y' and Artcl_Status='UL'";
                Q1 = "select Jrnl_Acronym,Artcl_ArticleId,Proof_Pages,Artcl_ReceivedDt,Artcl_ScheduledDt,Artcl_UploadedDt,Jrnl_Contact from article,journal where Artcl_JrnlId=jrnl_id and Jrnl_PublID=4 and isnull(Artcl_UploadedDt,'')<>'' and artcl_id>=1531456  and  (select count(*) from JR_Articles where (JRA_StageID='35' or JRA_StageID='58' or JRA_StageID='38'  or JRA_StageID='42'  or JRA_StageID='43') and Artcl_ArticleId=JRA_ArticleID) = 0 and CHARINDEX('_',Artcl_ArticleId)=0 and isnull(Inv_OtherTypesetter,'')<>'Y' and Artcl_Status='UL'";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                rows = ds.Tables[0].Rows;
                JRlist = new System.Collections.ArrayList();
                JRStagelist = new System.Collections.ArrayList();
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.Add();
                xlWorkSheet.Name = "Waiting for Correction - Report";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "Sr. No.";
                xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                xlWorkSheet.Cells[1, 3] = "Article ID";
                xlWorkSheet.Cells[1, 4] = "Curr. Activity";
                xlWorkSheet.Cells[1, 5] = "Pages";
                xlWorkSheet.Cells[1, 6] = "Submission";
                xlWorkSheet.Cells[1, 7] = "Recd Date";
                xlWorkSheet.Cells[1, 8] = "Due Date";
                xlWorkSheet.Cells[1, 9] = "Uploaded date";
                xlWorkSheet.Cells[1, 10] = "PM";
                i = 2; k = 1; rcnt = 0;
                for (int j = 0; j < rows.Count; j++)
                {
                    if (rows[j][0].ToString() == "" || rows[j][0].ToString() == "SAMPLE" || rows[j][4].ToString() == "" || rows[j][1].ToString() == "PIE1076988" || rows[j][1].ToString() == "PIE1083098")
                    {
                        continue;
                    }
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();
                    xlWorkSheet.Cells[i, 4] = "UL";
                    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 6] = "First Proof";
                    xlWorkSheet.Cells[i, 7] = rows[j][3].ToString();
                    xlWorkSheet.Cells[i, 8] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 9] = rows[j][5].ToString();
                    xlWorkSheet.Cells[i, 10] = rows[j][6].ToString();
                    try
                    {
                        if (Cs.AddDays(Convert.ToDateTime(rows[j][5].ToString()).Date, db, 4) < DateTime.Today.Date)
                        {
                            Xl.Range chartRange1 = xlWorkSheet.get_Range("A" + i.ToString(), "J" + i.ToString());
                            chartRange1.Interior.Color = Xl.XlRgbColor.rgbBisque;
                        }
                    }
                    catch (Exception e) { }
                    i++;
                    k++;
                    rcnt++;
                }
                chartRange = xlWorkSheet.get_Range("A1", "J" + (rcnt + 1));
                CellAlignment(chartRange);
                chartRange = xlWorkSheet.get_Range("A1", "J1");
                chartRange.Font.Bold = true;
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                //***   
                Q1 = "select Jrnl_Acronym,JRM_Volume,JRM_Issue,JRS_StageName,PrcsMst_Name,JRST_ReceivedDt,JRST_ScheduledDt,Jrnl_Contact FROM  JR_Main, JR_Stage_Tran, Journal,JR_Stages,ProcessMst where JRM_ID = JRST_JRM_ID  and JRM_JournalID=Jrnl_ID AND JRM_JournalID=Jrnl_Id AND Jrnl_PublID=4 and jrs_id=JRST_JRS_ID and JRST_Status=PrcsMst_Id and JRST_JRS_ID in(42,43,50,57,71,125,38,39) and isnull(JRST_UploadedDT,'')='' order by Jrnl_Acronym";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                rows = ds.Tables[0].Rows;
                JRlist = new System.Collections.ArrayList();
                JRStagelist = new System.Collections.ArrayList();
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.Add();
                xlWorkSheet.Name = "Issue - Report";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "Sr. No.";
                xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                xlWorkSheet.Cells[1, 3] = "Vol.";
                xlWorkSheet.Cells[1, 4] = "Iss.";
                xlWorkSheet.Cells[1, 5] = "Curr. Activity";
                xlWorkSheet.Cells[1, 6] = "Submission";
                xlWorkSheet.Cells[1, 7] = "Recd Date";
                xlWorkSheet.Cells[1, 8] = "Due Date";
                xlWorkSheet.Cells[1, 9] = "PM";
                i = 2; k = 1; rcnt = 0;
                for (int j = 0; j < rows.Count; j++)
                {
                    if ((rows[j][3].ToString() == ""))
                    {
                        continue;
                    }
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();
                    xlWorkSheet.Cells[i, 4] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 5] = rows[j][3].ToString();
                    xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();
                    xlWorkSheet.Cells[i, 8] = rows[j][6].ToString();
                    xlWorkSheet.Cells[i, 9] = rows[j][7].ToString();
                    try
                    {
                        if (Convert.ToDateTime(rows[j][6].ToString()).Date < DateTime.Today.Date)
                        {
                            Xl.Range chartRange1 = xlWorkSheet.get_Range("A" + i.ToString(), "I" + i.ToString());
                            chartRange1.Interior.Color = Xl.XlRgbColor.rgbBisque;
                        }
                    }
                    catch (Exception e) { }
                    i++;
                    k++;
                    rcnt++;
                }
                chartRange = xlWorkSheet.get_Range("A1", "I" + (rcnt + 1));
                CellAlignment(chartRange);
                chartRange = xlWorkSheet.get_Range("A1", "I1");
                chartRange.Font.Bold = true;
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                //***       
                if (!(Directory.Exists(System.Environment.CurrentDirectory + @"\SAGE_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\SAGE_Report\");
                string fname = System.Environment.CurrentDirectory + @"\SAGE_Report\SAGE_PM_Excel_Report_" + DateTime.Now.ToString("ddMMyyyy_hhmmss") + @".xlsx";
                xlWorkSheet.SaveAs(fname);
                xlApp.Quit();
                System.Threading.Thread.Sleep(5000);
                Cs.SendMail("", "Dear Team,<Br/><Br/>Kindly find the attached today's report", "SAGE", false, "SAGE_PM_Report", fname);
                System.Threading.Thread.Sleep(5000);
                return true;
            }
            catch (Exception e)
            {
                //MessageBox.Show("Error: " + e.Message + "\n" + e.StackTrace);
                System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("Rajasekar@novatechset.com", "tiworkflow@novatechset.com", "SAGE_PM_Report: " + DateTime.Today.ToString("dd/MM/yyyy"), "Error while generating report: " + e.Message + "<Br/>" + e.StackTrace + "<Br/><Br/>Regards,<Br/>TechSupport.");
                System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                MM.IsBodyHtml = true;
                client.Send(MM);
                return false;
            }
        }

        public bool SAGE_TempCreateReport()
        {
            try
            {
                foreach (Process P in Process.GetProcessesByName("EXCEL"))
                {
                    try
                    {
                        P.Kill();
                    }
                    catch (Exception e) { }
                }
                DBClass db = new DBClass();
                //string Q1 = "WITH T1 AS (SELECT DISTINCT Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID,ArtType_Name, CASE WHEN isnull(Proof_Pages,0)<>0 THEN Proof_Pages WHEN Artcl_TextFolios IS NULL OR Artcl_TextFolios='' THEN 0 ELSE Artcl_TextFolios END AS [Pages], Artcl_UploadedDt AS Artcl_UploadedDt, Artcl_Status AS Status, Artcl_ReceivedDt, Artcl_DueDtCats, Artcl_ScheduledDt,isnull(Artcl_PII,'') as Artcl_PII,jrnl_contact FROM Article,  Journal,ArticleTypes WHERE Artcl_JrnlId=Jrnl_Id and Artcl_ArtType=ArtType_ID  AND Jrnl_PublID=4 and CHARINDEX('_',Artcl_ArticleId)=0 and  Artcl_ArticleId in ('ACT1031163','BDS1047735','CATH1040109','CATH1047230','CNO1046440','CNO1046447','CRA1047041','CSS1047885','CVD1047122','DHJ1045590','DHJ1047802','EEA1038551','EEA1041779','HME1046484','HME1047024','IPE1046975','IPE1047259','IRP1045690','IRP1047841','JBM1042899','JPX1038794','MAV1043305','MDE1035235','MDE1041794','MDE1041799','MNS1047123','MSO1047978','NAD1044861','NPX1030815','NPX1030818','PAC1046646','SBH1047694','SCI1037460','SEA1038172','SON1044601','TCT1039131','TCT1039670','TCT1039676','TCT1039681','TCT1039948','TCT1041212','TCT1041425','TCT1042140','TCT1043048','TCT1045198','TCT1045213','TCT1045506','TIA1041422','TIA1045313','TIA1046135','TCT1045204','SBH1038313','SBH1047830','NPX1046069','TCT1043030','TCT1043963','TCT1045831','JBM1039236','JPX1043392','SON1037494','ASN1042220','BDS1046374','BDS1047319','CSS1046881','EVP1040751','EVP1044150','EVP1045271','JIAPAC1045551','SCI1044228','SCI1044562','TCT1039135','TCT1045496','TCT1045497','TCT1045499','TCT1045820','TCT1045823','TCT1045826','TCT1046432','TCT1046433','BDS1046181','CCA1046967','CRA1047432','EEA1044831','JIAPAC1044920','JIAPAC1046762','NPX1043731','SAA1044481','SCI1041495','CCA1047871','NPX1046072','OTR1025812','OTR1035548','TCT1039127','TCT1045510','MDE1035239','NPX1047705','TCT1039679','TCT1041464','TCT1043040','TCT1043784','TCT1043975','TCT1044626','TCT1045206','NPX1046068','CATH1044723','EEA1040876','NPX1043964','OTR1025808','NPX1045479','BDS1047725','BDS1047734','CATH1044212','CNO1041471','JPX1046089','MDE1044590','MDE1044607','NPX1046105','OTR1035555','BDS1045171','BDS1046182','EEA1036824','MDE1041178','SCI1041488','SCI1042479','TCT1041203','MDE1037444','CATH1047229','CCN1044879','DHJ1045579','EEA1042701','EVP1046162','NPX1042540','NPX1045464','SON1044615','SON1044618','SON1045258','TCT1042139','TIA1045306','ASN1039028','CATH1040873','CATH1041169','CATH1042940','CATH1045902','CCA1038339','CCA1042029','CCA1044518','CNO1031059','JBM1043128','NPX1033673','TIA1041475','CVD1047742','CCN1046459','SCI1044848','CNO1034360','AFR1042384','MDE1044604','NPX1031766','CATH1047231','CRA1047065','NPX1045467','JBM1046368','TCT1043976','SCI1044032','EEA1043211','IRP1043791','CATH1045908','EEA1042703','SON1044600','SON1044592','ASN1035036','ASN1044359','CCA1041630','EEA1033342','NPX1040354','NPX1040357','SCI1043365','NPX1041270','BDS1044808','IRP1041295','CATH1039288')) , T2 as (SELECT MAX(JRST_ID) AS maxid,JRA_ArticleID AS ArticleID FROM JR_Articles, JR_Main, JR_Stage_Tran, Journal where JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_ID AND JRM_JournalID=Jrnl_Id AND Jrnl_PublID=4 AND JRA_ArticleID IN(SELECT ISNULL(Artcl_ArticleId,'') AS ArticleID FROM Article,  Journal,ArticleTypes WHERE   Artcl_ArtType=ArtType_ID and Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=4and CHARINDEX('_',Artcl_ArticleId)=0 and  Artcl_ArticleId in ('ACT1031163','BDS1047735','CATH1040109','CATH1047230','CNO1046440','CNO1046447','CRA1047041','CSS1047885','CVD1047122','DHJ1045590','DHJ1047802','EEA1038551','EEA1041779','HME1046484','HME1047024','IPE1046975','IPE1047259','IRP1045690','IRP1047841','JBM1042899','JPX1038794','MAV1043305','MDE1035235','MDE1041794','MDE1041799','MNS1047123','MSO1047978','NAD1044861','NPX1030815','NPX1030818','PAC1046646','SBH1047694','SCI1037460','SEA1038172','SON1044601','TCT1039131','TCT1039670','TCT1039676','TCT1039681','TCT1039948','TCT1041212','TCT1041425','TCT1042140','TCT1043048','TCT1045198','TCT1045213','TCT1045506','TIA1041422','TIA1045313','TIA1046135','TCT1045204','SBH1038313','SBH1047830','NPX1046069','TCT1043030','TCT1043963','TCT1045831','JBM1039236','JPX1043392','SON1037494','ASN1042220','BDS1046374','BDS1047319','CSS1046881','EVP1040751','EVP1044150','EVP1045271','JIAPAC1045551','SCI1044228','SCI1044562','TCT1039135','TCT1045496','TCT1045497','TCT1045499','TCT1045820','TCT1045823','TCT1045826','TCT1046432','TCT1046433','BDS1046181','CCA1046967','CRA1047432','EEA1044831','JIAPAC1044920','JIAPAC1046762','NPX1043731','SAA1044481','SCI1041495','CCA1047871','NPX1046072','OTR1025812','OTR1035548','TCT1039127','TCT1045510','MDE1035239','NPX1047705','TCT1039679','TCT1041464','TCT1043040','TCT1043784','TCT1043975','TCT1044626','TCT1045206','NPX1046068','CATH1044723','EEA1040876','NPX1043964','OTR1025808','NPX1045479','BDS1047725','BDS1047734','CATH1044212','CNO1041471','JPX1046089','MDE1044590','MDE1044607','NPX1046105','OTR1035555','BDS1045171','BDS1046182','EEA1036824','MDE1041178','SCI1041488','SCI1042479','TCT1041203','MDE1037444','CATH1047229','CCN1044879','DHJ1045579','EEA1042701','EVP1046162','NPX1042540','NPX1045464','SON1044615','SON1044618','SON1045258','TCT1042139','TIA1045306','ASN1039028','CATH1040873','CATH1041169','CATH1042940','CATH1045902','CCA1038339','CCA1042029','CCA1044518','CNO1031059','JBM1043128','NPX1033673','TIA1041475','CVD1047742','CCN1046459','SCI1044848','CNO1034360','AFR1042384','MDE1044604','NPX1031766','CATH1047231','CRA1047065','NPX1045467','JBM1046368','TCT1043976','SCI1044032','EEA1043211','IRP1043791','CATH1045908','EEA1042703','SON1044600','SON1044592','ASN1035036','ASN1044359','CCA1041630','EEA1033342','NPX1040354','NPX1040357','SCI1043365','NPX1041270','BDS1044808','IRP1041295','CATH1039288')) GROUP BY JRA_ArticleID)SELECT DISTINCT t1.JrnlID, t1.ArticleID, t1.[Pages],  CASE WHEN t2.maxid IS NULL THEN T1.Status ELSE PrcsMst_Name END AS 'Last Stage Status',CASE WHEN t2.maxid IS NULL  THEN 'First Proof'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0) or (CHARINDEX('PM',JRS_StageName)>0)) THEN 'Author/PM Correction'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0) or (CHARINDEX('PM',JRS_StageName)>0)) THEN 'Author/PM Correction'  WHEN  CHARINDEX('PAP',JRS_StageName)>0  THEN 'PAP' ELSE '' END as 'Last Stage',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ReceivedDt ELSE JR_Stage_Tran.JRST_ReceivedDt END AS 'ReceivedDate',CASE WHEN t2.maxid IS NULL THEN (CASE WHEN T1.Artcl_DueDtCats<T1.Artcl_ScheduledDt then T1.Artcl_ScheduledDt else T1.Artcl_DueDtCats END) ELSE (CASE WHEN JR_Stage_Tran.JRST_DueDtCats IS NULL then JR_Stage_Tran.JRST_ScheduledDt ELSE JR_Stage_Tran.JRST_DueDtCats END)  END AS 'DueDate',     Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end as UploadDt,isnull(t1.Artcl_PII,'') as Workflow,t1.ArtType_Name,T1.jrnl_contact as PM  from T1 Left outer join T2 on t1.ArticleID=t2.ArticleID LEFT OUTER JOIN JR_Stage_Tran on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages ON JR_Stage_Tran.JRST_JRS_ID=JR_Stages.JRS_ID LEFT OUTER JOIN ProcessMst ON JRST_Status=PrcsMst_Id WHERE Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end=''  order by ArticleID";
                //string Q1 = "WITH T1 AS (SELECT DISTINCT Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID,ArtType_Name, CASE WHEN isnull(Proof_Pages,0)<>0 THEN Proof_Pages WHEN Artcl_TextFolios IS NULL OR Artcl_TextFolios='' THEN 0 ELSE Artcl_TextFolios END AS [Pages], Artcl_UploadedDt AS Artcl_UploadedDt, Artcl_Status AS Status, Artcl_ReceivedDt, Artcl_DueDtCats, Artcl_ScheduledDt,isnull(Artcl_PII,'') as Artcl_PII,jrnl_contact FROM Article,  Journal,ArticleTypes WHERE Artcl_JrnlId=Jrnl_Id and Artcl_ArtType=ArtType_ID  AND Jrnl_PublID=4 and CHARINDEX('_',Artcl_ArticleId)=0 and  Artcl_ArticleId in ('AAR1056239','AAR1058052','ACT1024899','ACT1031163','ACT1054342','ACT1055679','ACT1060469','AFR1050077','AFR1052567','AFR1060057','ASN1035036','ASN1049056','ASN1052862','ASN1053505','ASN1055064','ASN1057635','AVC1061063','BDS1049670','BDS1050499','BDS1053712','BDS1054277','BDS1055898','BDS1059480','BDS1061122','CATH1040873','CATH1048896','CATH1049402','CATH1049786','CATH1050356','CATH1050642','CATH1050923','CATH1051704','CATH1051708','CATH1051764','CATH1051766','CATH1052292','CATH1052293','CATH1052968','CATH1053313','CATH1053315','CATH1054094','CATH1054514','CATH1055165','CATH1055716','CATH1056637','CATH1056648','CATH1057901','CATH1057903','CATH1059495','CATH1059498','CATH1059500','CATH1059813','CATH1060446','CATH1060455','CATH1061147','CATH1061148','CATH1061149','CCA1041630','CCA1047871','CCA1052052','CCA1057134','CCA1058186','CCA1061750','CCN1044879','CCN1046459','CCN1055346','CCN1058894','CNO1048068','CNO1055330','CNO1055335','CNO1056709','CRA1053476','CSS1046881','CSS1051327','CSS1053850','CSS1055176','CSS1061347','CTC1052382','CTC1052392','CTC1056192','CUL1053085','CUL1056376','CUL1056405','CUL1056988','CVD1047122','CVD1049978','CVD1059374','DHJ1048654','DHJ1050167','DHJ1054922','DHJ1055552','DHJ1056156','DHJ1057662','DHJ1057667','DHJ1058935','DHJ1059350','DHJ1059358','DHJ1059366','DHJ1059649','DHJ1059975','DHJ1060659','DLI1053264','DLI1057658','DLI1057681','EEA1033342','EEA1038551','EEA1044831','EEA1052063','EEA1054224','EEA1055806','EEA1055807','EEA1056989','EEA1057195','EEA1058304','EVP1056159','EVP1056160','EVP1057158','HME1046484','HME1048640','HME1051832','HME1053965','HME1058023','INI1051069','INI1051364','INI1053634','INI1057038','IPE1048513','IPE1053352','IPE1053361','IPE1053877','IPE1054533','IPE1054534','IPE1055212','IPE1055766','IPE1055767','IPE1056362','IPE1058222','IPE1058476','IPE1058480','IPE1058799','IPE1059203','IRP1043791','IRP1047841','IRP1048511','IRP1049482','IRP1050864','IRP1051290','IRP1051791','IRP1053659','IRP1055994','IRP1057042','IRP1057883','IRP1057884','IRP1058086','JBM1043128','JBM1052571','JBM1056959','JBM1057576','JEBIM1053641','JEBIM1058417','JEBIM1058421','JIAPAC1047797','JIAPAC1052399','JIAPAC1053518','JIAPAC1053520','JIAPAC1053964','JIAPAC1054935','JIAPAC1055933','JIAPAC1056760','JIAPAC1059289','JIAPAC1059588','JIAPAC1059921','JPX1049644','JPX1049672','JPX1049677','JPX1049680','JPX1049880','JPX1054934','JPX1055289','JPX1056428','JPX1056432','JPX1056436','JPX1056467','JPX1056503','JPX1056506','JPX1056513','JPX1056521','JPX1056523','JPX1056533','JPX1056534','JPX1058611','JPX1059049','JPX1059051','JPX1059053','JPX1060615','JPX1060636','JPX1060769','JPX1060773','JPX1060783','JPX1060791','JPX1060792','JPX1060802','JPX1060811','JPX1060812','MAV1055653','MAV1055656','MAV1060500','MAV1060504','MDE1037444','MDE1041799','MDE1044604','MDE1051803','MDE1054965','MDE1055391','MDE1059652','MDE1059667','MDE1061012','MDE1061019','MNS1047123','MNS1048827','MNS1050018','MNS1054829','MNS1055168','MNS1055484','MNS1057217','MNS1059752','MNS1061106','MNS1061745','MSO1047978','MSO1048756','MSO1048761','MSO1049168','MSO1051855','MSO1052159','MSO1052656','MSO1053939','MSO1054454','MSO1057110','MSO1057514','MSO1058862','MSO1059048','MSO1060337','MSO1061543','MSO1061547','MSO1061550','NAD1050747','NAD1050765','NAD1050768','NAD1053130','NAD1057373','NAD1057638','NAD1058635','NAD1059054','NPX1039922','NPX1040354','NPX1040357','NPX1041270','NPX1048628','NPX1048651','NPX1049688','NPX1052868','NPX1053202','NPX1053951','NPX1054955','NPX1055014','NPX1055604','NPX1056140','NPX1056144','NPX1056418','NPX1056422','NPX1056753','NPX1057694','NPX1057940','NPX1059010','NPX1059292','NPX1059299','NPX1059312','NPX1059578','NPX1059635','NPX1059645','NPX1059646','NPX1060579','NPX1060922','NPX1060924','OTR1056940','OTR1056942','OTR1056943','OTR1056944','OTR1056946','OTR1056947','OTR1056949','OTR1056951','OTR1059543','PAC1046646','PAC1051800','PAC1052657','PAC1052658','PAC1056855','PAC1057001','PAC1057657','PLA1057135','PLA1058739','PLA1058742','PLA1059184','SAA1057569','SAA1058470','SAA1058741','SBH1038313','SBH1047694','SBH1047830','SBH1049040','SBH1049043','SBH1052394','SBH1056542','SBH1058430','SCI1037460','SCI1050276','SCI1050277','SCI1050278','SCI1050279','SCI1050284','SCI1050288','SCI1050289','SCI1050292','SCI1050293','SCI1052354','SCI1052359','SCI1053417','SCI1053510','SCI1053512','SCI1053551','SCI1053728','SCI1054256','SCI1054258','SCI1054985','SCI1054986','SCI1054992','SCI1055277','SCI1055638','SCI1055640','SCI1056290','SCI1056818','SCI1057678','SCI1057680','SCI1058036','SCI1058554','SCI1058555','SCI1058557','SCI1058562','SCI1059038','SCI1059045','SCI1059047','SCI1059050','SCI1059716','SCI1059973','SCI1059976','SHR1055558','SON1051467','SON1051824','SON1052118','SON1052356','SON1053493','SON1054814','SON1054817','SON1055614','SON1057938','SON1057939','SON1058492','SON1059265','TCT1039127','TCT1039670','TCT1039676','TCT1039948','TCT1041212','TCT1041425','TCT1043048','TCT1043784','TCT1043976','TCT1045198','TCT1045506','TCT1048592','TCT1048634','TCT1049894','TCT1049902','TCT1049903','TCT1050767','TCT1051547','TCT1051808','TCT1052142','TCT1052150','TCT1052152','TCT1052154','TCT1053752','TCT1055340','TCT1055948','TCT1055953','TCT1056478','TCT1056809','TCT1057371','TCT1057982','TCT1057983','TCT1058352','TCT1059937','TCT1060170','TCT1060180','TCT1060202','TIA1046135','TIA1049938','TIA1052786','TIA1053707','TIA1054924','TIA1057367','TIA1059628','TIA1059982','TIA1060983','TIA1061116')) , T2 as (SELECT MAX(JRST_ID) AS maxid,JRA_ArticleID AS ArticleID FROM JR_Articles, JR_Main, JR_Stage_Tran, Journal where JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_ID AND JRM_JournalID=Jrnl_Id AND Jrnl_PublID=4 AND JRA_ArticleID IN(SELECT ISNULL(Artcl_ArticleId,'') AS ArticleID FROM Article,  Journal,ArticleTypes WHERE   Artcl_ArtType=ArtType_ID and Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=4and CHARINDEX('_',Artcl_ArticleId)=0 and  Artcl_ArticleId in ('AAR1056239','AAR1058052','ACT1024899','ACT1031163','ACT1054342','ACT1055679','ACT1060469','AFR1050077','AFR1052567','AFR1060057','ASN1035036','ASN1049056','ASN1052862','ASN1053505','ASN1055064','ASN1057635','AVC1061063','BDS1049670','BDS1050499','BDS1053712','BDS1054277','BDS1055898','BDS1059480','BDS1061122','CATH1040873','CATH1048896','CATH1049402','CATH1049786','CATH1050356','CATH1050642','CATH1050923','CATH1051704','CATH1051708','CATH1051764','CATH1051766','CATH1052292','CATH1052293','CATH1052968','CATH1053313','CATH1053315','CATH1054094','CATH1054514','CATH1055165','CATH1055716','CATH1056637','CATH1056648','CATH1057901','CATH1057903','CATH1059495','CATH1059498','CATH1059500','CATH1059813','CATH1060446','CATH1060455','CATH1061147','CATH1061148','CATH1061149','CCA1041630','CCA1047871','CCA1052052','CCA1057134','CCA1058186','CCA1061750','CCN1044879','CCN1046459','CCN1055346','CCN1058894','CNO1048068','CNO1055330','CNO1055335','CNO1056709','CRA1053476','CSS1046881','CSS1051327','CSS1053850','CSS1055176','CSS1061347','CTC1052382','CTC1052392','CTC1056192','CUL1053085','CUL1056376','CUL1056405','CUL1056988','CVD1047122','CVD1049978','CVD1059374','DHJ1048654','DHJ1050167','DHJ1054922','DHJ1055552','DHJ1056156','DHJ1057662','DHJ1057667','DHJ1058935','DHJ1059350','DHJ1059358','DHJ1059366','DHJ1059649','DHJ1059975','DHJ1060659','DLI1053264','DLI1057658','DLI1057681','EEA1033342','EEA1038551','EEA1044831','EEA1052063','EEA1054224','EEA1055806','EEA1055807','EEA1056989','EEA1057195','EEA1058304','EVP1056159','EVP1056160','EVP1057158','HME1046484','HME1048640','HME1051832','HME1053965','HME1058023','INI1051069','INI1051364','INI1053634','INI1057038','IPE1048513','IPE1053352','IPE1053361','IPE1053877','IPE1054533','IPE1054534','IPE1055212','IPE1055766','IPE1055767','IPE1056362','IPE1058222','IPE1058476','IPE1058480','IPE1058799','IPE1059203','IRP1043791','IRP1047841','IRP1048511','IRP1049482','IRP1050864','IRP1051290','IRP1051791','IRP1053659','IRP1055994','IRP1057042','IRP1057883','IRP1057884','IRP1058086','JBM1043128','JBM1052571','JBM1056959','JBM1057576','JEBIM1053641','JEBIM1058417','JEBIM1058421','JIAPAC1047797','JIAPAC1052399','JIAPAC1053518','JIAPAC1053520','JIAPAC1053964','JIAPAC1054935','JIAPAC1055933','JIAPAC1056760','JIAPAC1059289','JIAPAC1059588','JIAPAC1059921','JPX1049644','JPX1049672','JPX1049677','JPX1049680','JPX1049880','JPX1054934','JPX1055289','JPX1056428','JPX1056432','JPX1056436','JPX1056467','JPX1056503','JPX1056506','JPX1056513','JPX1056521','JPX1056523','JPX1056533','JPX1056534','JPX1058611','JPX1059049','JPX1059051','JPX1059053','JPX1060615','JPX1060636','JPX1060769','JPX1060773','JPX1060783','JPX1060791','JPX1060792','JPX1060802','JPX1060811','JPX1060812','MAV1055653','MAV1055656','MAV1060500','MAV1060504','MDE1037444','MDE1041799','MDE1044604','MDE1051803','MDE1054965','MDE1055391','MDE1059652','MDE1059667','MDE1061012','MDE1061019','MNS1047123','MNS1048827','MNS1050018','MNS1054829','MNS1055168','MNS1055484','MNS1057217','MNS1059752','MNS1061106','MNS1061745','MSO1047978','MSO1048756','MSO1048761','MSO1049168','MSO1051855','MSO1052159','MSO1052656','MSO1053939','MSO1054454','MSO1057110','MSO1057514','MSO1058862','MSO1059048','MSO1060337','MSO1061543','MSO1061547','MSO1061550','NAD1050747','NAD1050765','NAD1050768','NAD1053130','NAD1057373','NAD1057638','NAD1058635','NAD1059054','NPX1039922','NPX1040354','NPX1040357','NPX1041270','NPX1048628','NPX1048651','NPX1049688','NPX1052868','NPX1053202','NPX1053951','NPX1054955','NPX1055014','NPX1055604','NPX1056140','NPX1056144','NPX1056418','NPX1056422','NPX1056753','NPX1057694','NPX1057940','NPX1059010','NPX1059292','NPX1059299','NPX1059312','NPX1059578','NPX1059635','NPX1059645','NPX1059646','NPX1060579','NPX1060922','NPX1060924','OTR1056940','OTR1056942','OTR1056943','OTR1056944','OTR1056946','OTR1056947','OTR1056949','OTR1056951','OTR1059543','PAC1046646','PAC1051800','PAC1052657','PAC1052658','PAC1056855','PAC1057001','PAC1057657','PLA1057135','PLA1058739','PLA1058742','PLA1059184','SAA1057569','SAA1058470','SAA1058741','SBH1038313','SBH1047694','SBH1047830','SBH1049040','SBH1049043','SBH1052394','SBH1056542','SBH1058430','SCI1037460','SCI1050276','SCI1050277','SCI1050278','SCI1050279','SCI1050284','SCI1050288','SCI1050289','SCI1050292','SCI1050293','SCI1052354','SCI1052359','SCI1053417','SCI1053510','SCI1053512','SCI1053551','SCI1053728','SCI1054256','SCI1054258','SCI1054985','SCI1054986','SCI1054992','SCI1055277','SCI1055638','SCI1055640','SCI1056290','SCI1056818','SCI1057678','SCI1057680','SCI1058036','SCI1058554','SCI1058555','SCI1058557','SCI1058562','SCI1059038','SCI1059045','SCI1059047','SCI1059050','SCI1059716','SCI1059973','SCI1059976','SHR1055558','SON1051467','SON1051824','SON1052118','SON1052356','SON1053493','SON1054814','SON1054817','SON1055614','SON1057938','SON1057939','SON1058492','SON1059265','TCT1039127','TCT1039670','TCT1039676','TCT1039948','TCT1041212','TCT1041425','TCT1043048','TCT1043784','TCT1043976','TCT1045198','TCT1045506','TCT1048592','TCT1048634','TCT1049894','TCT1049902','TCT1049903','TCT1050767','TCT1051547','TCT1051808','TCT1052142','TCT1052150','TCT1052152','TCT1052154','TCT1053752','TCT1055340','TCT1055948','TCT1055953','TCT1056478','TCT1056809','TCT1057371','TCT1057982','TCT1057983','TCT1058352','TCT1059937','TCT1060170','TCT1060180','TCT1060202','TIA1046135','TIA1049938','TIA1052786','TIA1053707','TIA1054924','TIA1057367','TIA1059628','TIA1059982','TIA1060983','TIA1061116')) GROUP BY JRA_ArticleID)SELECT DISTINCT t1.JrnlID, t1.ArticleID, t1.[Pages],  CASE WHEN t2.maxid IS NULL THEN T1.Status ELSE PrcsMst_Name END AS 'Last Stage Status',CASE WHEN t2.maxid IS NULL  THEN 'First Proof'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0) or (CHARINDEX('PM',JRS_StageName)>0)) THEN 'Author/PM Correction'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0) or (CHARINDEX('PM',JRS_StageName)>0)) THEN 'Author/PM Correction'  WHEN  CHARINDEX('PAP',JRS_StageName)>0  THEN 'PAP' ELSE '' END as 'Last Stage',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ReceivedDt ELSE JR_Stage_Tran.JRST_ReceivedDt END AS 'ReceivedDate',CASE WHEN t2.maxid IS NULL THEN (CASE WHEN T1.Artcl_DueDtCats<T1.Artcl_ScheduledDt then T1.Artcl_ScheduledDt else T1.Artcl_DueDtCats END) ELSE (CASE WHEN JR_Stage_Tran.JRST_DueDtCats IS NULL then JR_Stage_Tran.JRST_ScheduledDt ELSE JR_Stage_Tran.JRST_DueDtCats END)  END AS 'DueDate',     Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end as UploadDt,isnull(t1.Artcl_PII,'') as Workflow,t1.ArtType_Name,T1.jrnl_contact as PM  from T1 Left outer join T2 on t1.ArticleID=t2.ArticleID LEFT OUTER JOIN JR_Stage_Tran on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages ON JR_Stage_Tran.JRST_JRS_ID=JR_Stages.JRS_ID LEFT OUTER JOIN ProcessMst ON JRST_Status=PrcsMst_Id WHERE Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end=''  order by ArticleID";
                string Q1 = "WITH T1 AS (SELECT DISTINCT Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID,ArtType_Name, CASE WHEN isnull(Proof_Pages,0)<>0 THEN Proof_Pages WHEN Artcl_TextFolios IS NULL OR Artcl_TextFolios='' THEN 0 ELSE Artcl_TextFolios END AS [Pages], Artcl_UploadedDt AS Artcl_UploadedDt, Artcl_Status AS Status, Artcl_ReceivedDt, Artcl_DueDtCats, Artcl_ScheduledDt,isnull(Artcl_PII,'') as Artcl_PII,jrnl_contact FROM Article,  Journal,ArticleTypes WHERE Artcl_JrnlId=Jrnl_Id and Artcl_ArtType=ArtType_ID  AND Jrnl_PublID=4 and CHARINDEX('_',Artcl_ArticleId)=0 and  Jrnl_Acronym in ('OTR','LFN','ACT','SHR','TIA','ROE','BDS','EEA','NPX','AAR','CSS','DHJ','DLI','SEA','SON','CNO','CTC','ASN','EVP','JPX','IRP','JBM','CRA','BDX','MDE','SBH','MAV','NAD','CATH','SCI','TCT','PLA','SAA','AFR','CCA','CUL','IPE','JEBIM','JIAPAC','AVC','CCN','CVD','HME','INI','MSO','MNS','NAB','PAC','MEA')) , T2 as (SELECT MAX(JRST_ID) AS maxid,JRA_ArticleID AS ArticleID FROM JR_Articles, JR_Main, JR_Stage_Tran, Journal where JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_ID AND JRM_JournalID=Jrnl_Id AND Jrnl_PublID=4 AND JRA_ArticleID IN(SELECT ISNULL(Artcl_ArticleId,'') AS ArticleID FROM Article,  Journal,ArticleTypes WHERE   Artcl_ArtType=ArtType_ID and Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=4and CHARINDEX('_',Artcl_ArticleId)=0 and  Jrnl_Acronym in ('OTR','LFN','ACT','SHR','TIA','ROE','BDS','EEA','NPX','AAR','CSS','DHJ','DLI','SEA','SON','CNO','CTC','ASN','EVP','JPX','IRP','JBM','CRA','BDX','MDE','SBH','MAV','NAD','CATH','SCI','TCT','PLA','SAA','AFR','CCA','CUL','IPE','JEBIM','JIAPAC','AVC','CCN','CVD','HME','INI','MSO','MNS','NAB','PAC','MEA')) GROUP BY JRA_ArticleID)SELECT DISTINCT t1.JrnlID, t1.ArticleID, t1.[Pages],  CASE WHEN t2.maxid IS NULL THEN T1.Status ELSE PrcsMst_Name END AS 'Last Stage Status',CASE WHEN t2.maxid IS NULL  THEN 'First Proof'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0) or (CHARINDEX('PM',JRS_StageName)>0)) THEN 'Author/PM Correction'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0) or (CHARINDEX('PM',JRS_StageName)>0)) THEN 'Author/PM Correction'  WHEN  CHARINDEX('PAP',JRS_StageName)>0  THEN 'PAP' ELSE '' END as 'Last Stage',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ReceivedDt ELSE JR_Stage_Tran.JRST_ReceivedDt END AS 'ReceivedDate',CASE WHEN t2.maxid IS NULL THEN (CASE WHEN T1.Artcl_DueDtCats<T1.Artcl_ScheduledDt then T1.Artcl_ScheduledDt else T1.Artcl_DueDtCats END) ELSE (CASE WHEN JR_Stage_Tran.JRST_DueDtCats IS NULL then JR_Stage_Tran.JRST_ScheduledDt ELSE JR_Stage_Tran.JRST_DueDtCats END)  END AS 'DueDate',     Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end as UploadDt,isnull(t1.Artcl_PII,'') as Workflow,t1.ArtType_Name,T1.jrnl_contact as PM  from T1 Left outer join T2 on t1.ArticleID=t2.ArticleID LEFT OUTER JOIN JR_Stage_Tran on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages ON JR_Stage_Tran.JRST_JRS_ID=JR_Stages.JRS_ID LEFT OUTER JOIN ProcessMst ON JRST_Status=PrcsMst_Id WHERE Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end=''  order by ArticleID";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rows = ds.Tables[0].Rows;
                Xl.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                Xl.Workbook xlWorkBook;
                Xl.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                System.Collections.ArrayList JRlist = new System.Collections.ArrayList();
                System.Collections.ArrayList JRStagelist = new System.Collections.ArrayList();
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Name = "Comp. Report - WIP";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "Sr. No.";
                xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                xlWorkSheet.Cells[1, 3] = "Article ID";
                xlWorkSheet.Cells[1, 4] = "Curr. Activity";
                xlWorkSheet.Cells[1, 5] = "Pages";
                xlWorkSheet.Cells[1, 6] = "Submission";
                xlWorkSheet.Cells[1, 7] = "Recd Date";
                xlWorkSheet.Cells[1, 8] = "Due Date";
                xlWorkSheet.Cells[1, 9] = "Article Type";
                xlWorkSheet.Cells[1, 10] = "CopyRight";
                xlWorkSheet.Cells[1, 11] = "PM";
                int i = 2, k = 1, rcnt = 0;
                CommonClass Cs = new CommonClass();
                if (rows.Count == 0)
                {
                    //Cs.SendMail("", "Dear Team,<Br/><Br/>No records found", "SAGE", false, "SAGE_Report");
                    return true;
                }
                for (int j = 0; j < rows.Count; j++)
                {
                    if ((rows[j][0].ToString() == "") || (rows[j][0].ToString() == "SAMPLE") || (rows[j][4].ToString() == ""))
                    {
                        continue;
                    }
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                    if (!JRlist.Contains(rows[j][0].ToString()))
                    {
                        JRlist.Add(rows[j][0].ToString());
                    }
                    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();
                    xlWorkSheet.Cells[i, 4] = rows[j][3].ToString();
                    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();
                    xlWorkSheet.Cells[i, 8] = rows[j][6].ToString();                   
                    xlWorkSheet.Cells[i, 9] = rows[j][9].ToString();
                    xlWorkSheet.Cells[i, 10] = "";
                    xlWorkSheet.Cells[i, 11] = rows[j][10].ToString();
                    i++;
                    k++;
                    rcnt++;
                }
                Xl.Range chartRange = xlWorkSheet.get_Range("A1", "K" + (rcnt + 1));
                CellAlignment(chartRange);
                chartRange = xlWorkSheet.get_Range("A1", "K1");
                chartRange.Font.Bold = true;
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;               
                //***       
                if (!(Directory.Exists(System.Environment.CurrentDirectory + @"\SAGE_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\SAGE_Report\");
                string fname = System.Environment.CurrentDirectory + @"\SAGE_Report\SAGE_Excel_Report_" + DateTime.Now.ToString("ddMMyyyy_HHmmss") + @".xlsx";
                xlWorkSheet.SaveAs(fname);
                xlApp.Quit();
                System.Threading.Thread.Sleep(5000);
                Cs.SendMail("", "Dear Team,<Br/><Br/>Kindly find the attached today's report", "SAGE", false, "SAGE_TempReport", fname);
                System.Threading.Thread.Sleep(5000);
                return true;
            }
            catch (Exception e)
            {
                //MessageBox.Show("Error: " + e.Message + "\n" + e.StackTrace);
                //Cs.SendMail("", "Dear Team,<Br/><Br/>Error on sage report generation", "SAGE", true, "SAGE_Report", fname);
                return false;
            }
        }

        public bool SAGE_CreateReport()
        {
            try
            {
                foreach (Process P in Process.GetProcessesByName("EXCEL"))
                {
                    try
                    {
                        P.Kill();
                    }
                    catch (Exception e) { }
                }
                DBClass db = new DBClass();
                //string Q1 = "WITH T1 AS (SELECT DISTINCT Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID,ArtType_Name, CASE WHEN isnull(Proof_Pages,0)<>0 THEN Proof_Pages WHEN Artcl_TextFolios IS NULL OR Artcl_TextFolios='' THEN 0 ELSE Artcl_TextFolios END AS [Pages], Artcl_UploadedDt AS Artcl_UploadedDt, Artcl_Status AS Status, Artcl_ReceivedDt, Artcl_DueDtCats, Artcl_ScheduledDt,isnull(Artcl_PII,'') as Artcl_PII FROM Article,  Journal,ArticleTypes WHERE Artcl_JrnlId=Jrnl_Id and Artcl_ArtType=ArtType_ID  AND Jrnl_PublID=4 and CHARINDEX('_',Artcl_ArticleId)=0)  , T2 as (SELECT MAX(JRST_ID) AS maxid,JRA_ArticleID AS ArticleID FROM JR_Articles, JR_Main, JR_Stage_Tran, Journal where JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_ID AND JRM_JournalID=Jrnl_Id AND Jrnl_PublID=4 AND JRA_ArticleID IN(SELECT ISNULL(Artcl_ArticleId,'') AS ArticleID FROM Article,  Journal,ArticleTypes WHERE   Artcl_ArtType=ArtType_ID and Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=4and CHARINDEX('_',Artcl_ArticleId)=0) GROUP BY JRA_ArticleID) SELECT DISTINCT t1.JrnlID, t1.ArticleID, t1.[Pages],  CASE WHEN t2.maxid IS NULL THEN T1.Status ELSE PrcsMst_Name END AS 'Last Stage Status',CASE WHEN t2.maxid IS NULL  THEN 'First Proof'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0) or (CHARINDEX('PM',JRS_StageName)>0)) THEN 'Author/PM Correction'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0) or (CHARINDEX('PM',JRS_StageName)>0)) THEN 'Author/PM Correction'  WHEN  CHARINDEX('PAP',JRS_StageName)>0  THEN 'PAP' ELSE '' END as 'Last Stage',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ReceivedDt ELSE JR_Stage_Tran.JRST_ReceivedDt END AS 'ReceivedDate',CASE WHEN t2.maxid IS NULL THEN (CASE WHEN T1.Artcl_DueDtCats<T1.Artcl_ScheduledDt then T1.Artcl_ScheduledDt else T1.Artcl_DueDtCats END) ELSE (CASE WHEN JR_Stage_Tran.JRST_DueDtCats IS NULL then JR_Stage_Tran.JRST_ScheduledDt ELSE JR_Stage_Tran.JRST_DueDtCats END)  END AS 'DueDate',     Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end as UploadDt,isnull(t1.Artcl_PII,'') as Workflow,t1.ArtType_Name  from T1 Left outer join T2 on t1.ArticleID=t2.ArticleID LEFT OUTER JOIN JR_Stage_Tran on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages ON JR_Stage_Tran.JRST_JRS_ID=JR_Stages.JRS_ID LEFT OUTER JOIN ProcessMst ON JRST_Status=PrcsMst_Id WHERE Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end=''  order by ArticleID";
                string Q1 = "SSP_AutoReport 7";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rows = ds.Tables[0].Rows;
                Xl.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                Xl.Workbook xlWorkBook;
                Xl.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                System.Collections.ArrayList JRlist = new System.Collections.ArrayList();
                System.Collections.ArrayList JRStagelist = new System.Collections.ArrayList();
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                xlWorkSheet.Name = "Comp. Report - WIP";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "Sr. No.";
                xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                xlWorkSheet.Cells[1, 3] = "Article ID";
                xlWorkSheet.Cells[1, 4] = "Curr. Activity";
                xlWorkSheet.Cells[1, 5] = "Pages";
                xlWorkSheet.Cells[1, 6] = "Submission";
                xlWorkSheet.Cells[1, 7] = "Recd Date";
                xlWorkSheet.Cells[1, 8] = "Due Date";
                xlWorkSheet.Cells[1, 9] = "Article Type";
                xlWorkSheet.Cells[1, 10] = "CopyRight";
                int i = 2, k = 1, rcnt = 0;
                CommonClass Cs = new CommonClass();
                if (rows.Count == 0)
                {
                    Cs.SendMail("", "Dear Team,<Br/><Br/>No records found", "SAGE", false, "SAGE_Report");
                    return true;
                }
                for (int j = 0; j < rows.Count; j++)
                {
                    if ((rows[j][0].ToString() == "") || (rows[j][0].ToString() == "SAMPLE") || (rows[j][4].ToString() == ""))
                    {
                        continue;
                    }
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                    if (!JRlist.Contains(rows[j][0].ToString()))
                    {
                        JRlist.Add(rows[j][0].ToString());
                    }
                    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();
                    if (rows[j][3].ToString().ToUpper() == "CE-QC" || rows[j][3].ToString().ToUpper() == "CE")
                    {
                        xlWorkSheet.Cells[i, 4] = "CE";
                    }
                    else if (rows[j][3].ToString().ToUpper() == "QC")
                    {
                        xlWorkSheet.Cells[i, 4] = "QC";
                    }
                    else if (rows[j][3].ToString().ToUpper() == "INCOMPLETE")
                    {
                        xlWorkSheet.Cells[i, 4] = "PR2";
                    }
                    else
                    {
                        xlWorkSheet.Cells[i, 4] = rows[j][3].ToString();
                    }
                    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();
                    xlWorkSheet.Cells[i, 8] = rows[j][6].ToString();
                    try
                    {
                        if (Convert.ToDateTime(rows[j][6].ToString()).Date < DateTime.Today.Date)
                        {
                            Xl.Range chartRange1 = xlWorkSheet.get_Range("A" + i.ToString(), "J" + i.ToString());
                            chartRange1.Interior.Color = Xl.XlRgbColor.rgbYellowGreen;
                        }
                    }
                    catch (Exception e) { }
                    xlWorkSheet.Cells[i, 9] = rows[j][9].ToString();
                    xlWorkSheet.Cells[i, 10] = "";
                    i++;
                    k++;
                    rcnt++;
                }
                Xl.Range chartRange = xlWorkSheet.get_Range("A1", "J" + (rcnt + 1));
                CellAlignment(chartRange);
                chartRange = xlWorkSheet.get_Range("A1", "J1");
                chartRange.Font.Bold = true;
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                //***
                Q1 = "WITH T1 AS (SELECT DISTINCT Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID,ArtType_Name, CASE WHEN isnull(Proof_Pages,0)<>0 THEN Proof_Pages WHEN Artcl_TextFolios IS NULL OR Artcl_TextFolios='' THEN 0 ELSE Artcl_TextFolios END AS [Pages], Artcl_UploadedDt AS Artcl_UploadedDt, Artcl_Status AS Status, Artcl_ReceivedDt, Artcl_ScheduledDt,isnull(Artcl_PII,'') as Artcl_PII FROM Article,  Journal,ArticleTypes WHERE Artcl_JrnlId=Jrnl_Id and Artcl_ArtType=ArtType_ID  AND Jrnl_PublID=10 and CHARINDEX('_',Artcl_ArticleId)=0)  , T2 as (SELECT MAX(JRST_ID) AS maxid,JRA_ArticleID AS ArticleID FROM JR_Articles, JR_Main, JR_Stage_Tran, Journal where JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_ID AND JRM_JournalID=Jrnl_Id AND Jrnl_PublID=4 AND JRA_ArticleID IN(SELECT ISNULL(Artcl_ArticleId,'') AS ArticleID FROM Article,  Journal,ArticleTypes WHERE   Artcl_ArtType=ArtType_ID and Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=4and CHARINDEX('_',Artcl_ArticleId)=0) GROUP BY JRA_ArticleID) SELECT DISTINCT t1.JrnlID, t1.ArticleID, t1.[Pages],  CASE WHEN t2.maxid IS NULL THEN T1.Status ELSE PrcsMst_Name END AS 'Last Stage Status',CASE WHEN t2.maxid IS NULL  THEN 'First Proof'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0) or (CHARINDEX('PM',JRS_StageName)>0)) THEN 'Author/PM Correction'  WHEN  ((CHARINDEX('AU',JRS_StageName)>0) or (CHARINDEX('PM',JRS_StageName)>0)) THEN 'Author/PM Correction'  WHEN  CHARINDEX('PAP',JRS_StageName)>0  THEN 'PAP' ELSE '' END as 'Last Stage',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ReceivedDt ELSE JR_Stage_Tran.JRST_ReceivedDt END AS 'ReceivedDate',CASE WHEN t2.maxid IS NULL THEN T1.Artcl_ScheduledDt  ELSE (CASE WHEN JR_Stage_Tran.JRST_DueDtCats IS NULL then JR_Stage_Tran.JRST_ScheduledDt ELSE JR_Stage_Tran.JRST_DueDtCats END)  END AS 'DueDate',     Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end as UploadDt,isnull(t1.Artcl_PII,'') as Workflow,t1.ArtType_Name  from T1 Left outer join T2 on t1.ArticleID=t2.ArticleID LEFT OUTER JOIN JR_Stage_Tran on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages ON JR_Stage_Tran.JRST_JRS_ID=JR_Stages.JRS_ID LEFT OUTER JOIN ProcessMst ON JRST_Status=PrcsMst_Id WHERE Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')='' then '' when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end=''  order by ArticleID";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnectionBlr()));
                db.OpenConnectionBlr();
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnectionBlr();
                ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                rows = ds.Tables[0].Rows;
                if (rows.Count == 0)
                {
                    Cs.SendMail("", "Dear Team,<Br/><Br/>No records found. SRN Bangalore.", "SAGE", false, "SAGE_Report");
                    goto Skip;
                }
                JRlist = new System.Collections.ArrayList();
                JRStagelist = new System.Collections.ArrayList();
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.Add();
                xlWorkSheet.Name = "SRN Comp. Report - WIP";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "Sr. No.";
                xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                xlWorkSheet.Cells[1, 3] = "Article ID";
                xlWorkSheet.Cells[1, 4] = "Curr. Activity";
                xlWorkSheet.Cells[1, 5] = "Pages";
                xlWorkSheet.Cells[1, 6] = "Submission";
                xlWorkSheet.Cells[1, 7] = "Recd Date";
                xlWorkSheet.Cells[1, 8] = "Due Date";
                xlWorkSheet.Cells[1, 9] = "Article Type";
                xlWorkSheet.Cells[1, 10] = "CopyRight";
                i = 2; k = 1; rcnt = 0;
                for (int j = 0; j < rows.Count; j++)
                {
                    if ((rows[j][0].ToString() == "") || (rows[j][0].ToString() == "SAMPLE") || (rows[j][4].ToString() == ""))
                    {
                        continue;
                    }
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                    if (!JRlist.Contains(rows[j][0].ToString()))
                    {
                        JRlist.Add(rows[j][0].ToString());
                    }
                    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();
                    //if (rows[j][3].ToString().ToUpper() == "CE-QC" || rows[j][3].ToString().ToUpper() == "CE")
                    //{
                    //    xlWorkSheet.Cells[i, 4] = "CE";
                    //}
                    //else if (rows[j][3].ToString().ToUpper() == "QC")
                    //{
                    //    xlWorkSheet.Cells[i, 4] = "QC";
                    //}
                    //else if (rows[j][3].ToString().ToUpper() == "INCOMPLETE")
                    //{
                    //    xlWorkSheet.Cells[i, 4] = "PR2";
                    //}
                    //else
                    //{
                    xlWorkSheet.Cells[i, 4] = rows[j][3].ToString();
                    //}
                    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 6] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 7] = rows[j][5].ToString();
                    xlWorkSheet.Cells[i, 8] = rows[j][6].ToString();
                    try
                    {
                        if (Convert.ToDateTime(rows[j][6].ToString()).Date < DateTime.Today.Date)
                        {
                            Xl.Range chartRange1 = xlWorkSheet.get_Range("A" + i.ToString(), "J" + i.ToString());
                            chartRange1.Interior.Color = Xl.XlRgbColor.rgbYellowGreen;
                        }
                    }
                    catch (Exception e) { }
                    xlWorkSheet.Cells[i, 9] = rows[j][9].ToString();
                    xlWorkSheet.Cells[i, 10] = "";
                    i++;
                    k++;
                    rcnt++;
                }
                chartRange = xlWorkSheet.get_Range("A1", "J" + (rcnt + 1));
                CellAlignment(chartRange);
                chartRange = xlWorkSheet.get_Range("A1", "J1");
                chartRange.Font.Bold = true;
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
            //***       
            Skip:
                Q1 = "select Jrnl_Acronym,Artcl_ArticleId,Proof_Pages,Artcl_ReceivedDt,Artcl_ScheduledDt,Artcl_UploadedDt from article,journal where Artcl_JrnlId=jrnl_id and Jrnl_PublID=4 and isnull(Artcl_UploadedDt,'')<>'' and isnull(Artcl_AUCorr_RecDT,'')='' and artcl_id>=1531456 and isnull(Artcl_PDFToAuthor,'')<>''";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                rows = ds.Tables[0].Rows;
                JRlist = new System.Collections.ArrayList();
                JRStagelist = new System.Collections.ArrayList();
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.Add();
                xlWorkSheet.Name = "Waiting for Correction - Report";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "Sr. No.";
                xlWorkSheet.Cells[1, 2] = "Jrnl ID";
                xlWorkSheet.Cells[1, 3] = "Article ID";
                xlWorkSheet.Cells[1, 4] = "Curr. Activity";
                xlWorkSheet.Cells[1, 5] = "Pages";
                xlWorkSheet.Cells[1, 6] = "Submission";
                xlWorkSheet.Cells[1, 7] = "Recd Date";
                xlWorkSheet.Cells[1, 8] = "Due Date";
                xlWorkSheet.Cells[1, 9] = "Uploaded date";
                i = 2; k = 1; rcnt = 0;
                for (int j = 0; j < rows.Count; j++)
                {
                    if ((rows[j][0].ToString() == "") || (rows[j][0].ToString() == "SAMPLE") || (rows[j][4].ToString() == ""))
                    {
                        continue;
                    }
                    xlWorkSheet.Cells[i, 1] = k;
                    xlWorkSheet.Cells[i, 2] = rows[j][0].ToString();
                    xlWorkSheet.Cells[i, 3] = rows[j][1].ToString();
                    xlWorkSheet.Cells[i, 4] = "UL";
                    xlWorkSheet.Cells[i, 5] = rows[j][2].ToString();
                    xlWorkSheet.Cells[i, 6] = "First Proof";
                    xlWorkSheet.Cells[i, 7] = rows[j][3].ToString();
                    xlWorkSheet.Cells[i, 8] = rows[j][4].ToString();
                    xlWorkSheet.Cells[i, 9] = rows[j][5].ToString();
                    i++;
                    k++;
                    rcnt++;
                }
                chartRange = xlWorkSheet.get_Range("A1", "I" + (rcnt + 1));
                CellAlignment(chartRange);
                chartRange = xlWorkSheet.get_Range("A1", "I1");
                chartRange.Font.Bold = true;
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                //***       
                if (!(Directory.Exists(System.Environment.CurrentDirectory + @"\SAGE_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\SAGE_Report\");
                string fname = System.Environment.CurrentDirectory + @"\SAGE_Report\SAGE_Excel_Report_" + DateTime.Now.ToString("ddMMyyyy_hhmmss") + @".xlsx";
                xlWorkSheet.SaveAs(fname);
                xlApp.Quit();
                System.Threading.Thread.Sleep(5000);
                Cs.SendMail("", "Dear Team,<Br/><Br/>Kindly find the attached today's report", "SAGE", false, "SAGE_Report", fname);
                System.Threading.Thread.Sleep(5000);
                return true;
            }
            catch (Exception e)
            {
                //MessageBox.Show("Error: " + e.Message + "\n" + e.StackTrace);
                //Cs.SendMail("", "Dear Team,<Br/><Br/>Error on sage report generation", "SAGE", true, "SAGE_Report", fname);
                return false;
            }
        }
        

        public void IWAP_DailyReport()
        {
            CommonClass Cs = new CommonClass();
            DBClass db = new DBClass();
            try
            {
                foreach (Process P in Process.GetProcessesByName("EXCEL"))
                {
                    try
                    {
                        P.Kill();
                    }
                    catch (Exception e2) { }
                }              
                Xl.Workbook xlWorkBook;
                Xl.Worksheet xlWorkSheet;
                Xl.Application xlapp;
                xlapp = new Xl.Application();
                xlapp.Visible = false;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlapp.Workbooks.Add(misValue);
                //string Q1 = "WITH T1 AS (SELECT DISTINCT Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID,Artcl_UploadedDt AS Artcl_UploadedDt  FROM Article,  Journal WHERE Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=67 AND  isnull(Artcl_UploadedDt,'')<>'')  , T2 as (SELECT MAX(JRST_ID) AS maxid,JRA_ArticleID AS ArticleID FROM JR_Articles, JR_Main, JR_Stage_Tran, Journal where JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_ID AND JRM_JournalID=Jrnl_Id AND Jrnl_PublID=67 AND JRA_ArticleID IN(SELECT ISNULL(Artcl_ArticleId,'') AS ArticleID FROM Article,  Journal WHERE Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=67 AND ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' ) GROUP BY JRA_ArticleID) SELECT DISTINCT  'IWAP' as 'Publisher', t1.JrnlID , t1.ArticleID , Case when ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>'' then  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')  when  ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'')<>'' and t2.ArticleID IS not NULL  then ISNULL(CONVERT(Varchar,t1.Artcl_UploadedDt),'') else  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'') end as UploadDt from T1 Left outer join T2 on t1.ArticleID=t2.ArticleID LEFT OUTER JOIN JR_Stage_Tran on JR_Stage_Tran.JRST_ID=t2.maxid  WHERE  ISNULL(CONVERT(Varchar,JR_Stage_Tran.JRST_UploadedDT),'')<>''  and t2.ArticleID IS not NULL   order by ArticleID";

                //string Q1 = "SELECT  'IWAP' as 'Publisher', Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID,CONVERT(VARCHAR(16),ISNULL(Artcl_UploadedDt,''),106) AS Artcl_UploadedDt  FROM Article,  Journal WHERE Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=67 AND  isnull(Artcl_UploadedDt,'')<>'' AND  CONVERT(date,ISNULL(Artcl_UploadedDt,'')) >'2015-12-31'  ORDER BY CONVERT(date,ISNULL(Artcl_UploadedDt,''))  ";
                //string Q1 = "SELECT  'IWAP' as 'Publisher', Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID,ISNULL(Artcl_DOI,'') AS DOI,CONVERT(VARCHAR(16), ISNULL(Artcl_UploadedDt,''),106) AS Artcl_UploadedDt  FROM Article,  Journal WHERE Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=67  AND  isnull(Artcl_ReceivedDt,'')<>''   AND  isnull(Artcl_UploadedDt,'')<>'' AND  CONVERT(date,ISNULL(Artcl_UploadedDt,'')) >'2015-12-31'  ORDER BY CONVERT(date,ISNULL(Artcl_UploadedDt,''))";
                //string Q1 = "SELECT  'IWAP' as 'Publisher', Jrnl_Acronym AS 'JrnlID', ISNULL(Artcl_ArticleId,'') AS ArticleID,ISNULL(Artcl_DOI,'') AS DOI,CONVERT(VARCHAR(16), ISNULL(Artcl_UploadedDt,''),106) AS Artcl_UploadedDt  FROM Article,  Journal WHERE Artcl_JrnlId=Jrnl_Id  AND Jrnl_PublID=67   AND  Artcl_ArticleId NOT LIKE '%_cover' AND  Artcl_ArticleId NOT LIKE '%_content' AND  Artcl_ArticleId NOT LIKE '%_advert' AND  Artcl_ArticleId NOT LIKE '%_ifa' AND  isnull(Artcl_ReceivedDt,'')<>'' AND  isnull(Artcl_UploadedDt,'')<>'' AND  CONVERT(date,ISNULL(Artcl_UploadedDt,'')) >'2013-12-31'  ORDER BY CONVERT(date,ISNULL(Artcl_UploadedDt,''))";
                string Q1 = "SSP_AutoReport 9";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rows = ds.Tables[0].Rows;
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Sheets.Add();
                xlWorkSheet.Name = "Uncorrected Proof upload on HWX";
                xlWorkSheet.Cells[1, 1] = "Publisher";
                xlWorkSheet.Cells[1, 2] = "Journal";
                xlWorkSheet.Cells[1, 3] = "Article ID";
                xlWorkSheet.Cells[1, 4] = "DOI";
                xlWorkSheet.Cells[1, 5] = "Uploaded Date";
                int j = 2;
                for (int i = 0; i < rows.Count; i++)
                {
                    xlWorkSheet.Cells[j, 1] = rows[i][0];
                    xlWorkSheet.Cells[j, 2] = rows[i][1];
                    xlWorkSheet.Cells[j, 3] = rows[i][2];
                    xlWorkSheet.Cells[j, 4] = rows[i][3];
                    xlWorkSheet.Cells[j, 5] = rows[i][4];
                    j++;

                }
                Xl.Range chartRange = xlWorkSheet.get_Range("A1", "E" + (j - 1));
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeLeft).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeRight).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideHorizontal).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideVertical).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeBottom).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeTop).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Cells.HorizontalAlignment = Xl.XlHAlign.xlHAlignCenter;
                chartRange.Cells.VerticalAlignment = Xl.XlHAlign.xlHAlignCenter;
                chartRange = xlWorkSheet.get_Range("A1", "E1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;               
                chartRange.Font.Bold = true;
                chartRange.Font.Size = 16;
                CellAlignment(chartRange);
                chartRange.EntireColumn.AutoFit();
                if (!(Directory.Exists(System.Environment.CurrentDirectory + @"\IWAP_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\IWAP_Report\");
                xlapp.DisplayAlerts = false;
                //string fname = System.Environment.CurrentDirectory + @"\IWAP_Report\Online Publication Dates.xlsx";
                string fname = System.Environment.CurrentDirectory + @"\IWAP_Report\online_publication_dates.xlsx";
                xlWorkSheet.SaveAs(fname);
                xlapp.Quit();
                try
                {
                    System.Threading.Thread.Sleep(5000);
                    //FTP.clsFTP Ftp = new FTP.clsFTP("52.71.53.70", @"/IWA/Journals/Online Publication Dates/", "TIFTPAdmin", "Admin052013", 21);
                    //Ftp.Login();
                    //Ftp.UploadFile(fname, true);
                    //System.Threading.Thread.Sleep(5000);
                    //Ftp.CloseConnection();
                    using (WebClient client = new WebClient())
                    {
                        client.Credentials = new NetworkCredential("TIFTPAdmin", "Admin052013");
                        client.UploadFile("ftp://52.71.53.70/IWA/Journals/Online Publication Dates/" + Path.GetFileName(fname), WebRequestMethods.Ftp.UploadFile, fname);
                    }
                    using (SftpClient client = new SftpClient("ftp.datasalon.co.uk", 44422, "iwa_techset", "aQOC7Crl3Ybz"))
                    {
                        client.Connect();
                        client.ChangeDirectory("/transfers");
                        using (FileStream fs = new FileStream(fname, FileMode.Open))
                        {
                            client.BufferSize = 4 * 1024;
                            client.UploadFile(fs, Path.GetFileName(fname));
                        }
                    }
                    //using (Ftp ftp = new Ftp())
                    //{
                    //    ftp.Connect("52.71.53.70");
                    //    ftp.Login("TIFTPAdmin", "Admin052013");
                    //    //ftp.ChangeFolder(@"/IWA/Journals/Online Publication Dates/");
                    //    ftp.DeleteFile(@"/IWA/Journals/Online Publication Dates/Online Publication Dates.xlsx");
                    //    ftp.Upload(@"/IWA/Journals/Online Publication Dates/Online Publication Dates.xlsx",fname);
                    //    try
                    //    {
                    //        ftp.Rename(@"/IWA/Journals/Online Publication Dates/FtpTrial-Online Publication Dates.xlsx", @"/IWA/Journals/Online Publication Dates/Online Publication Dates.xlsx");
                    //    }
                    //    catch (Exception E){}
                    //    ftp.Close();
                    //}
                    Cs.SendMail("IWAP", "IWAP Today's Report:  Success...", "IWAP", false, "IWAP_report", fname);
                    File.WriteAllText(System.Environment.CurrentDirectory + @"\IWAP_Report\IWAP_Report_" + DateTime.Now.ToString("ddMMyyyy") + @".txt", "");
                }

                catch (Exception ex)
                {
                    Cs.SendMail("IWAP", "IWAP Error:  Process aborted... " + ex.Message + "\n" + ex.StackTrace, "IWAP", true, "IWAP_report");
                    return;
                }
                //MessageBox.Show("Process completed");
            }
            catch (Exception e1)
            {
                Cs.SendMail("IWAP", "IWAP Error:  Process aborted... " + e1.Message + "\n" + e1.StackTrace, "IWAP", true, "IWAP_report");
                return;
            }
        }


        public void CUP_PM_Weekly_Report_New()
        {
            CommonClass Cs = new CommonClass();
            DBClass db = new DBClass();
            try
            {
                foreach (Process P in Process.GetProcessesByName("EXCEL"))
                {
                    try
                    {
                        P.Kill();
                    }
                    catch (Exception e2) { }
                }
                Xl.Workbook xlWorkBook;
                Xl.Worksheet xlWorkSheet;
                Xl.Application xlapp;
                xlapp = new Xl.Application();
                xlapp.Visible = false;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlapp.Workbooks.Add(misValue);
                //string Q1 = @"with T1 as (SELECT DISTINCT convert(bit,'False') as 'Check',Jrnl_Title As JrnlTitle,Artcl_Status as Artstatus, Jrnl_Acronym AS Acronym, Artcl_ArticleId as ArticleID,Artcl_ManuScriptID as ManuscriptID,Artcl_AuthorName as AuthorName,CONVERT(DATE,Artcl_ReceivedDt) as ReceivedDate, ISNULL(Artcl_Title,'') AS Title,UsrMst_EmpNm as PM, jrnl_contact as CM, ArtType_Name as ArticleType,ISNULL(Artcl_OUPCopyright,'') as Copyright, ISNULL(Proof_Pages,0) AS PageExtent, '' AS CESendDate, '' AS CEFileRecDate, CONVERT(DATE,Artcl_UploadedDt) as ProofSentDate, '' AS AUCorrRecDate, Artcl_ScheduledDt as scheduledt,'' AS EditorCorrRecDate, ISNULL(Artcl_ColourOnline,'') AS ColourOnline, ISNULL(Artcl_ColourPrint,'') AS ColourPrint, '' ReviseAppDate,ISNULL(OUP_SPMComments,'') AS SPMComment,'0' as JRS_ID, '0' as overdue, Artcl_Volume as Volume,Artcl_Issue as Issue, Artcl_AuthorEmail as Email,CONVERT(DATE,Artcl_AUCorr_RecDT) AS Artcl_AUCorr_RecDT, CONVERT(DATE,Artcl_EDCorr_RecDT) AS Artcl_EDCorr_RecDT , Artcl_CUP_Remarks as smartremark  FROM Article with(nolock) , Journal with(nolock),ArticleTypes with(nolock),UsrMst with(nolock) where UsrMst_EmpId=Jrnl_User and Artcl_JrnlId=Jrnl_Id AND Jrnl_PublID=8 AND Artcl_ArtType=ArtType_ID and ISNULL(Jrnl_User, '')<>'' AND  Artcl_ArticleId NOT IN(SELECT DISTINCT JRA_ArticleID  FROM JR_Articles with(nolock) , JR_Stage_Tran with(nolock),  JR_Main with(nolock) ,TrnsJournalRev with(NOLOCK) WHERE JRM_ID=JRST_JRM_ID  AND JRST_ID=JRA_JRST_ID and JrnlTrns_ArticleId=JRA_ID AND JrnlTrns_Id=Jra_TransID AND ((JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=35) or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=36)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=37)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=109)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=110)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=111)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=112) or JRST_JRS_ID IN (33,34,38,39,40,41,42,43,44,49,50,57,58,64,65,66,71,73,74,75,82))) AND CHARINDEX('_',Artcl_ArticleID)=0 and CONVERT(date, Artcl_ReceivedDt) >= '2018-01-01'), T2 as (select MAX(JRST_ID) as maxid,JRA_ArticleID as ArticleID ,PrcsMst_name as Artstatus , CONVERT(DATE,JRST_ReceivedDt) AS AUCorrRecDate,jrst_scheduleddt as scheduledt,JRST_UploadedDT as uldt from JR_Articles with(nolock), JR_Main with(nolock), ProcessMst with(nolock), JR_Stage_Tran with(nolock), Journal with(nolock) where PrcsMst_Id=jrst_status and JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_Id and Jrnl_PublID=8 and JRA_ArticleID in (SELECT DISTINCT Artcl_ArticleId as ArticleID FROM Article with(nolock) , Journal with(nolock) WHERE Artcl_JrnlId=Jrnl_Id AND Jrnl_PublID=8  and ISNULL(Jrnl_User, '')<>'' AND Artcl_ArticleId NOT IN(SELECT DISTINCT JRA_ArticleID  FROM JR_Articles with(nolock) , JR_Stage_Tran with(nolock),  JR_Main with(nolock)  WHERE JRM_ID=JRST_JRM_ID AND JRST_ID=JRA_JRST_ID  AND JRST_JRS_ID IN(33,34,38,39,40,41,42,43,44,49,50,57,58,64,65,66,71,73,74,75,82)) )  and JRST_JRS_ID  in('35') group by JRA_ArticleID ,JRST_ReceivedDt,PrcsMst_name,jrst_scheduleddt,JRST_UploadedDT) SELECT  t1.ArticleID, t1.ManuscriptID,t1.ReceivedDate AS 'Mss Received',t1.ProofSentDate,t2.AUCorrRecDate AS 'Author corrections Received date', t1.EditorCorrRecDate AS 'Editor corrections Received date',CASE WHEN t2.maxid IS NULL and t1.ProofSentDate is null then  'First Proof'   WHEN t2.maxid IS NULL and t1.ProofSentDate is not null   THEN 'Proof Sent'    WHEN t2.maxid IS NULL and  T1.Artstatus='PMChk' THEN 'PM Approval'  WHEN t2.maxid IS not NULL and  T2.Artstatus='PMChk' THEN 'PM Approval' WHEN t2.AUCorrRecDate is not null or t1.EditorCorrRecDate is not null THEN 'Corrections received' else JRS_StageName  end as StageName,CASE WHEN t2.maxid IS NULL and t1.ProofSentDate is null and T1.scheduledt<getdate() then dbo.fnTATWithoutHolidaysNew(convert(date,T1.scheduledt), convert(date, getdate()),0,0) WHEN t2.maxid IS not NULL and T2.uldt is null and T2.scheduledt<getdate() then dbo.fnTATWithoutHolidaysNew(convert(date,T2.scheduledt), convert(date, getdate()),0,0)else t1.overdue end as Overdue,T1.PM as 'PM Name', T1.CM as 'CM Name','' as 'Remarks' from T1  with(nolock) Left outer join T2  with(nolock) on t1.ArticleID=t2.ArticleID left outer join JR_Stage_Tran with(nolock)  on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages  with(nolock) ON JRST_JRS_ID=JR_Stages.JRS_ID WHERE CONVERT(DATE,t1.ReceivedDate)>='2015-09-01' order by Acronym,ArticleID";     
                //string Q1 = @"with T1 as (SELECT DISTINCT convert(bit,'False') as 'Check',Jrnl_Title As JrnlTitle,Artcl_Status as Artstatus, Jrnl_Acronym AS Acronym, Artcl_ArticleId as ArticleID,Artcl_ManuScriptID as ManuscriptID,Artcl_AuthorName as AuthorName,CONVERT(DATE,Artcl_ReceivedDt) as ReceivedDate, ISNULL(Artcl_Title,'') AS Title,UsrMst_EmpNm as PM, jrnl_contact as CM, ArtType_Name as ArticleType,ISNULL(Artcl_OUPCopyright,'') as Copyright, ISNULL(Proof_Pages,0) AS PageExtent, '' AS CESendDate, '' AS CEFileRecDate, CONVERT(DATE,Artcl_UploadedDt) as ProofSentDate, '' AS AUCorrRecDate, Artcl_ScheduledDt as scheduledt,'' AS EditorCorrRecDate, ISNULL(Artcl_ColourOnline,'') AS ColourOnline, ISNULL(Artcl_ColourPrint,'') AS ColourPrint, '' ReviseAppDate,ISNULL(OUP_SPMComments,'') AS SPMComment,'0' as JRS_ID, '0' as overdue, Artcl_Volume as Volume,Artcl_Issue as Issue, Artcl_AuthorEmail as Email,CONVERT(DATE,Artcl_AUCorr_RecDT) AS Artcl_AUCorr_RecDT, CONVERT(DATE,Artcl_EDCorr_RecDT) AS Artcl_EDCorr_RecDT , Artcl_CUP_Remarks as smartremark  FROM Article with(nolock) , Journal with(nolock),ArticleTypes with(nolock),UsrMst with(nolock) where UsrMst_EmpId=Jrnl_User and Artcl_JrnlId=Jrnl_Id AND Jrnl_PublID=8 AND Artcl_ArtType=ArtType_ID and ISNULL(Jrnl_User, '')<>'' AND  Artcl_ArticleId NOT IN(SELECT DISTINCT JRA_ArticleID  FROM JR_Articles with(nolock) , JR_Stage_Tran with(nolock),  JR_Main with(nolock) ,TrnsJournalRev with(NOLOCK) WHERE JRM_ID=JRST_JRM_ID  AND JRST_ID=JRA_JRST_ID and JrnlTrns_ArticleId=JRA_ID AND JrnlTrns_Id=Jra_TransID AND ((JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=35) or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=36)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=37)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=109)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=110)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=111)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=112) or JRST_JRS_ID IN (33,34,38,39,40,41,42,43,44,49,50,57,58,64,65,66,71,73,74,75,82))) AND CHARINDEX('_',Artcl_ArticleID)=0 and CONVERT(date, Artcl_ReceivedDt) >= '2018-01-01'), T2 as (select MAX(JRST_ID) as maxid,JRA_ArticleID as ArticleID ,PrcsMst_name as Artstatus,JR_Articles.LastModifiedDate as pmuldt , CONVERT(DATE,JRST_ReceivedDt) AS AUCorrRecDate,jrst_scheduleddt as scheduledt,JRST_UploadedDT as uldt from JR_Articles with(nolock), JR_Main with(nolock), ProcessMst with(nolock), JR_Stage_Tran with(nolock), Journal with(nolock) where PrcsMst_Id=jrst_status and JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_Id and Jrnl_PublID=8 and JRA_ArticleID in (SELECT DISTINCT Artcl_ArticleId as ArticleID FROM Article with(nolock) , Journal with(nolock) WHERE Artcl_JrnlId=Jrnl_Id AND Jrnl_PublID=8  and ISNULL(Jrnl_User, '')<>'' AND Artcl_ArticleId NOT IN(SELECT DISTINCT JRA_ArticleID  FROM JR_Articles with(nolock) , JR_Stage_Tran with(nolock),  JR_Main with(nolock)  WHERE JRM_ID=JRST_JRM_ID AND JRST_ID=JRA_JRST_ID  AND JRST_JRS_ID IN(33,34,38,39,40,41,42,43,44,49,50,57,58,64,65,66,71,73,74,75,82)) )  and JRST_JRS_ID  in('35') group by JRA_ArticleID ,JRST_ReceivedDt,PrcsMst_name,jrst_scheduleddt,JRST_UploadedDT,JR_Articles.LastModifiedDate) SELECT  t1.ArticleID, t1.ManuscriptID,t1.ReceivedDate AS 'Mss Received',t1.ProofSentDate,t2.AUCorrRecDate AS 'Author corrections Received date', t1.EditorCorrRecDate AS 'Editor corrections Received date',CASE WHEN t2.maxid IS NULL and t1.ProofSentDate is null then  'First Proof'   WHEN t2.maxid IS NULL and t1.ProofSentDate is not null   THEN 'Proof Sent'    WHEN t2.maxid IS NULL and  T1.Artstatus='PMChk' THEN 'PM Approval'  WHEN t2.maxid IS not NULL and  T2.Artstatus='PMChk' THEN 'PM Approval' WHEN t2.AUCorrRecDate is not null or t1.EditorCorrRecDate is not null THEN 'Corrections received' else JRS_StageName  end as StageName,CASE WHEN t2.maxid IS NULL and t1.ProofSentDate is null and T1.scheduledt<getdate() then dbo.fnTATWithoutHolidaysNew(convert(date,T1.scheduledt), convert(date, getdate()),0,0) WHEN t2.maxid IS not NULL and T2.uldt is null and  T2.Artstatus='PMChk' and T2.pmuldt < getdate() and dbo.fnTATWithoutHolidaysNew(convert(date,T2.pmuldt), convert(date, getdate()),0,0)>2 then dbo.fnTATWithoutHolidaysNew(convert(date,T2.pmuldt), convert(date, getdate()),0,0)WHEN t2.maxid IS not NULL and T2.uldt is null and T2.scheduledt<getdate() and  T2.Artstatus<>'PMChk'  then dbo.fnTATWithoutHolidaysNew(convert(date,T2.scheduledt), convert(date, getdate()),0,0)else t1.overdue end as Overdue,T1.PM as 'PM Name', T1.CM as 'CM Name','' as 'Remarks' from T1  with(nolock) Left outer join T2  with(nolock) on t1.ArticleID=t2.ArticleID left outer join JR_Stage_Tran with(nolock)  on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages  with(nolock) ON JRST_JRS_ID=JR_Stages.JRS_ID WHERE CONVERT(DATE,t1.ReceivedDate)>='2015-09-01' order by Acronym,ArticleID";
                //string Q1 = "with T1 as (SELECT DISTINCT convert(bit,'False') as 'Check',Jrnl_Title As JrnlTitle,Artcl_Status as Artstatus, Jrnl_Acronym AS Acronym, Artcl_ArticleId as ArticleID,Artcl_ManuScriptID as ManuscriptID,Artcl_AuthorName as AuthorName,CONVERT(DATE,Artcl_ReceivedDt) as ReceivedDate, ISNULL(Artcl_Title,'') AS Title,UsrMst_EmpNm as PM, jrnl_contact as CM, ArtType_Name as ArticleType,ISNULL(Artcl_OUPCopyright,'') as Copyright, ISNULL(Proof_Pages,0) AS PageExtent, '' AS CESendDate, '' AS CEFileRecDate, CONVERT(DATE,Artcl_UploadedDt) as ProofSentDate, '' AS AUCorrRecDate, Artcl_ScheduledDt as scheduledt,'' AS EditorCorrRecDate, ISNULL(Artcl_ColourOnline,'') AS ColourOnline, ISNULL(Artcl_ColourPrint,'') AS ColourPrint, '' ReviseAppDate,ISNULL(OUP_SPMComments,'') AS SPMComment,'0' as JRS_ID, '0' as overdue, Artcl_Volume as Volume,Artcl_Issue as Issue, Artcl_AuthorEmail as Email,CONVERT(DATE,Artcl_AUCorr_RecDT) AS Artcl_AUCorr_RecDT, CONVERT(DATE,Artcl_EDCorr_RecDT) AS Artcl_EDCorr_RecDT , Artcl_CUP_Remarks as smartremark,Artcl_ScheduledWeb FROM Article with(nolock) , Journal with(nolock),ArticleTypes with(nolock),UsrMst with(nolock) where UsrMst_EmpId=Jrnl_User and Artcl_JrnlId=Jrnl_Id AND Jrnl_PublID=8 AND Artcl_ArtType=ArtType_ID and ISNULL(Jrnl_User, '')<>'' AND  Artcl_ArticleId NOT IN(SELECT DISTINCT JRA_ArticleID  FROM JR_Articles with(nolock), Article with(nolock) , JR_Stage_Tran with(nolock),  JR_Main with(nolock) ,TrnsJournalRev with(NOLOCK) WHERE JRM_ID=JRST_JRM_ID AND JRA_ArticleID=Artcl_ArticleId  AND JRST_ID=JRA_JRST_ID and JrnlTrns_ArticleId=JRA_ID AND JrnlTrns_Id=Jra_TransID AND ((JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=35 and isnull(Artcl_WebDelivery,'')<>'') or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=36  and isnull(Artcl_WebDelivery,'')<>'')  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=37 and isnull(Artcl_WebDelivery,'')<>'')  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=109 and isnull(Artcl_WebDelivery,'')<>'')  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=110 and isnull(Artcl_WebDelivery,'')<>'')  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=111 and isnull(Artcl_WebDelivery,'')<>'')  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=112 and isnull(Artcl_WebDelivery,'')<>'') or JRST_JRS_ID IN (33,34,38,39,40,41,42,43,44,49,50,57,58,64,65,66,71,73,74,75,82))) AND CHARINDEX('_',Artcl_ArticleID)=0 and CONVERT(date, Artcl_ReceivedDt) >= '2018-01-01'), T2 as (select MAX(JRST_ID) as maxid,JRA_ArticleID as ArticleID ,PrcsMst_name as Artstatus,JR_Articles.LastModifiedDate as pmuldt , CONVERT(DATE,JRST_ReceivedDt) AS AUCorrRecDate,jrst_scheduleddt as scheduledt,JRST_UploadedDT as uldt from JR_Articles with(nolock), JR_Main with(nolock), ProcessMst with(nolock), JR_Stage_Tran with(nolock), Journal with(nolock) where PrcsMst_Id=jrst_status and JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_Id and Jrnl_PublID=8 and JRA_ArticleID in (SELECT DISTINCT Artcl_ArticleId as ArticleID FROM Article with(nolock) , Journal with(nolock) WHERE Artcl_JrnlId=Jrnl_Id AND Jrnl_PublID=8  and ISNULL(Jrnl_User, '')<>'' and isnull(Artcl_WebDelivery,'')='' AND Artcl_ArticleId NOT IN(SELECT DISTINCT JRA_ArticleID  FROM JR_Articles with(nolock) , JR_Stage_Tran with(nolock),  JR_Main with(nolock)  WHERE JRM_ID=JRST_JRM_ID AND JRST_ID=JRA_JRST_ID  AND JRST_JRS_ID IN(33,34,38,39,40,41,42,43,44,49,50,57,58,64,65,66,71,73,74,75,82)) )  and JRST_JRS_ID  in('35') group by JRA_ArticleID ,JRST_ReceivedDt,PrcsMst_name,jrst_scheduleddt,JRST_UploadedDT,JR_Articles.LastModifiedDate) SELECT  t1.ArticleID, t1.ManuscriptID,t1.ReceivedDate AS 'Mss Received', case when CONVERT(DATE,t1.scheduledt)>= CONVERT(DATE,getdate()) and CONVERT(DATE,t1.scheduledt)<= CONVERT(DATE,getdate()+6) and isnull(t1.ProofSentDate,'')='' then  CONVERT(DATE,t1.scheduledt) else null end as 'Proof due date',t1.ProofSentDate,t2.AUCorrRecDate AS 'Author corrections Received date', t1.EditorCorrRecDate AS 'Editor corrections Received date',CASE WHEN t2.maxid IS NULL and t1.ProofSentDate is null then  'First Proof'   WHEN t2.maxid IS NULL and t1.ProofSentDate is not null   THEN 'Proof Sent'    WHEN t2.maxid IS NULL and  T1.Artstatus='PMChk' THEN 'PM Approval'  WHEN  t2.maxid IS not NULL and  T2.Artstatus='UL' and  t1.Artcl_ScheduledWeb is not null THEN 'CAMS_Delivery_Due'  WHEN  t2.maxid IS not NULL and  T2.Artstatus='UL' and t1.Artcl_ScheduledWeb is null THEN 'CAMS_Request_Due'  WHEN t2.maxid IS not NULL and  T2.Artstatus='PMChk' THEN 'PM Approval' WHEN t2.AUCorrRecDate is not null or t1.EditorCorrRecDate is not null THEN 'Corrections received' else JRS_StageName  end as StageName,CASE WHEN t2.maxid IS NULL and t1.ProofSentDate is null and T1.scheduledt<getdate() then dbo.fnTATWithoutHolidaysNew(convert(date,T1.scheduledt), convert(date, getdate()),0,0) WHEN t2.maxid IS not NULL and T2.uldt is null and  T2.Artstatus='PMChk' and T2.pmuldt < getdate() and dbo.fnTATWithoutHolidaysNew(convert(date,T2.pmuldt), convert(date, getdate()),0,0)>2 then dbo.fnTATWithoutHolidaysNew(convert(date,T2.pmuldt), convert(date, getdate()),0,0)WHEN t2.maxid IS not NULL and T2.uldt is null and T2.scheduledt<getdate() and  T2.Artstatus<>'PMChk'  then dbo.fnTATWithoutHolidaysNew(convert(date,T2.scheduledt), convert(date, getdate()),0,0)else t1.overdue end as Overdue,T1.PM as 'PM Name', T1.CM as 'CM Name','' as 'Remarks' from T1  with(nolock) Left outer join T2  with(nolock) on t1.ArticleID=t2.ArticleID left outer join JR_Stage_Tran with(nolock)  on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages  with(nolock) ON JRST_JRS_ID=JR_Stages.JRS_ID WHERE CONVERT(DATE,t1.ReceivedDate)>='2015-09-01' order by Acronym,ArticleID";
                //string Q1 = File.ReadAllText(@"C:\Users\2083\Desktop\CUP_PM\CUP_PM.sql");
                string str = "AGS2000097|ASO1800120|ASO1800121|ASO1900001|BER1800004|BPP2000055|DEM1800003|EDE1000020|HEP2100002|HLG1900009|INT1900003|INT2000056|INT2000057|INT2000058|INT2000060|JMO1800074|JMO1800075|JMO1900060|JOI1800032|JOI1800037|JOI1800038|JSC SAMPLE|JSC1800012|LVC standard small sample|PAO1900002|PAR1800108|PAR1800109|PAR1800158|PAR1800159|PAR1800162|PAR1800171|PAR1800172|PAR2000161|PAR2000162|pem1800044|pem1800045|PRM1900019|PSM1800358|PSM2000152|RAF2100006|RAM1900020|SSR1800033|SSR2100002|THC1800016|TRE1800010|TRE1800021|TRE1800022|TRE1800023|TRE1800024|TRE1800025|TRE1800026|TRE1800027|TRE1800028|TRE1800029|TRE1800030|TRE1800031|TRE1800032|TRE1800033|TRE1800034|TRE1800035|TRE1800036|TRE1800037|TRE1800038|TRE1800039|TRE1800040|TRE1800041|TRE1800044|TRE1800045|TRE1800046|TRE1800047|TRE1800048|TRE1800049|TRE1800050|TRE1800051|TRE1800052|TRE1800053|TRE1800054|TRE1800055|TRE1800056|TRE1800057|TRE1800058|TRE1800059|TRE1800060|TRE1800061|TRE1800062|TRE1800063|TRE1800064|TRE1800065|TRE1800066|TRE1800067|TRE1800068|TRE1800069|TRE1800070|TRE1800072|TRE1800073|TRE1800074|TRE1800075|TRE1800076|TRE1800077|TRE1800079|TRE1800080|TRE1800081|TRE1800082|TRE1800083|TRE1800084|TRE1800085|TRE1800086|TRE1800087|TRE1800088|TRE1800089|TRE1800090|TRE1800091|TRE1800092|TRE1800093|TRE1800096|TRE1800099|TRE1900001|TRE1900004|TRE1900005|TRE1900006|TRE1900012|TRE1900015|TRE1900017|TRE1900018|TRE1900020|TRE1900021|XYZ|BPP2000062|BPP2100002|BPP2100003|LSY1800055|LSY1800056|LSY1800132|LSY1800133|LSY2000082|LVC2100006|LVC2100007|MRS2000149|MRS2000203|MRS2000231|MRS2000253|MRS2000279|MRS2000280|NAV2000010|PAX1800042|PAX1800043|PAX1900027|PAX1900028|PAX2000068|PES1800028|PES1800029|PES1900005|PES1900006|PES2100001|PES2100002|SAP2000015|SAP2000016|SAP2100006|ERM2100006|MRF1800115|MRF2100032|NAV1800041|NAV2100016|PRM2000093|PRM2000094|JHL2000020|sample";
                string Q1 = "with T1 as (SELECT DISTINCT convert(bit,'False') as 'Check',Jrnl_Title As JrnlTitle,Artcl_Status as Artstatus, Jrnl_Acronym AS Acronym, Artcl_ArticleId as ArticleID,Artcl_ManuScriptID as ManuscriptID,Artcl_AuthorName as AuthorName,CONVERT(DATE,Artcl_ReceivedDt) as ReceivedDate, ISNULL(Artcl_Title,'') AS Title,UsrMst_EmpNm as PM, jrnl_contact as CM, ArtType_Name as ArticleType,ISNULL(Artcl_OUPCopyright,'') as Copyright, ISNULL(Proof_Pages,0) AS PageExtent, '' AS CESendDate, '' AS CEFileRecDate, CONVERT(DATE,Artcl_UploadedDt) as ProofSentDate, '' AS AUCorrRecDate, Artcl_ScheduledDt as scheduledt,'' AS EditorCorrRecDate, ISNULL(Artcl_ColourOnline,'') AS ColourOnline, ISNULL(Artcl_ColourPrint,'') AS ColourPrint, '' ReviseAppDate,ISNULL(OUP_SPMComments,'') AS SPMComment,'0' as JRS_ID, '0' as overdue, Artcl_Volume as Volume,Artcl_Issue as Issue, Artcl_AuthorEmail as Email,CONVERT(DATE,Artcl_AUCorr_RecDT) AS Artcl_AUCorr_RecDT, CONVERT(DATE,Artcl_EDCorr_RecDT) AS Artcl_EDCorr_RecDT , Artcl_CUP_Remarks as smartremark,Artcl_ScheduledWeb FROM Article with(nolock) , Journal with(nolock),ArticleTypes with(nolock),UsrMst with(nolock) where isnull(Manually_Closed,0)=0 and UsrMst_EmpId=Jrnl_User and Artcl_JrnlId=Jrnl_Id AND Jrnl_PublID=8 AND Artcl_ArtType=ArtType_ID and ISNULL(Jrnl_User, '')<>'' AND  Artcl_ArticleId NOT IN(SELECT DISTINCT JRA_ArticleID  FROM JR_Articles with(nolock), Article with(nolock) , JR_Stage_Tran with(nolock),  JR_Main with(nolock) ,TrnsJournalRev with(NOLOCK) WHERE JRM_ID=JRST_JRM_ID AND JRA_ArticleID=Artcl_ArticleId  AND JRST_ID=JRA_JRST_ID and JrnlTrns_ArticleId=JRA_ID AND JrnlTrns_Id=Jra_TransID AND (((JrnlTrns_NextProcessID in('33') or JRST_Status in('38')) AND JRST_JRS_ID=35 and isnull(Artcl_WebDelivery,'')<>'') or ((JrnlTrns_NextProcessID in('33') or JRST_Status in('38')) AND JRST_JRS_ID=36  and isnull(Artcl_WebDelivery,'')<>'')  or ((JrnlTrns_NextProcessID in('33') or JRST_Status in('38')) AND JRST_JRS_ID=37 and isnull(Artcl_WebDelivery,'')<>'')  or ((JrnlTrns_NextProcessID in('33') or JRST_Status in('38')) AND JRST_JRS_ID=109 and isnull(Artcl_WebDelivery,'')<>'')  or ((JrnlTrns_NextProcessID in('33') or JRST_Status in('38')) AND JRST_JRS_ID=110 and isnull(Artcl_WebDelivery,'')<>'')  or ((JrnlTrns_NextProcessID in('33') or JRST_Status in('38')) AND JRST_JRS_ID=111 and isnull(Artcl_WebDelivery,'')<>'')  or ((JrnlTrns_NextProcessID in('33') or JRST_Status in('38')) AND JRST_JRS_ID=112 and isnull(Artcl_WebDelivery,'')<>'') or JRST_JRS_ID IN (33,34,38,39,40,41,42,43,44,49,50,57,58,64,65,66,71,73,74,75,82))) AND CHARINDEX('_',Artcl_ArticleID)=0 and CONVERT(date, Artcl_ReceivedDt) >= '2021-01-01'), T2 as (select MAX(JRST_ID) as maxid,JRA_ArticleID as ArticleID ,PrcsMst_name as Artstatus,JR_Articles.LastModifiedDate as pmuldt , CONVERT(DATE,JRST_ReceivedDt) AS AUCorrRecDate,jrst_scheduleddt as scheduledt,JRST_UploadedDT as uldt,JRST_RevisedDtTnF 'RevisedProofDate' from JR_Articles with(nolock), JR_Main with(nolock), ProcessMst with(nolock), JR_Stage_Tran with(nolock), Journal with(nolock) where PrcsMst_Id=jrst_status and JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_Id and Jrnl_PublID=8 and JRA_ArticleID in (SELECT DISTINCT Artcl_ArticleId as ArticleID FROM Article with(nolock) , Journal with(nolock) WHERE Artcl_JrnlId=Jrnl_Id AND Jrnl_PublID=8  and ISNULL(Jrnl_User, '')<>'' and isnull(Artcl_WebDelivery,'')='' AND Artcl_ArticleId NOT IN(SELECT DISTINCT JRA_ArticleID  FROM JR_Articles with(nolock) , JR_Stage_Tran with(nolock),  JR_Main with(nolock)  WHERE JRM_ID=JRST_JRM_ID AND JRST_ID=JRA_JRST_ID  AND JRST_JRS_ID IN(33,34,38,39,40,41,42,43,44,49,50,57,58,64,65,66,71,73,74,75,82)) )  and JRST_JRS_ID  in('35') group by JRA_ArticleID ,JRST_ReceivedDt,PrcsMst_name,jrst_scheduleddt,JRST_UploadedDT,JR_Articles.LastModifiedDate,JRST_RevisedDtTnF) SELECT  t1.ArticleID, t1.ManuscriptID,t1.ReceivedDate AS 'Mss Received', CONVERT(DATE,t1.scheduledt) as 'Proof due date',t1.ProofSentDate,t2.AUCorrRecDate AS 'Author corrections Received date', t1.EditorCorrRecDate AS 'Editor corrections Received date',CASE WHEN t2.maxid IS NULL and t1.ProofSentDate is null then  'First Proof'   WHEN t2.maxid IS NULL and t1.ProofSentDate is not null   THEN 'Proof Sent'    WHEN t2.maxid IS NULL and  T1.Artstatus='PMChk' THEN 'PM Approval'  WHEN  t2.maxid IS not NULL and  T2.Artstatus='UL' and  t1.Artcl_ScheduledWeb is null and RevisedProofDate is not null THEN 'Revised Proof Sent To Editor Date' WHEN  t2.maxid IS not NULL and  T2.Artstatus='UL' and  t1.Artcl_ScheduledWeb is not null THEN 'CAMS_Delivery_Due'  WHEN  t2.maxid IS not NULL and  T2.Artstatus='UL' and t1.Artcl_ScheduledWeb is null THEN 'CAMS_Request_Due'  WHEN t2.maxid IS not NULL and  T2.Artstatus='PMChk' THEN 'PM Approval' WHEN t2.AUCorrRecDate is not null or t1.EditorCorrRecDate is not null THEN 'Corrections received' else JRS_StageName  end as StageName,CASE WHEN t2.maxid IS NULL and t1.ProofSentDate is null and T1.scheduledt<getdate() then dbo.fnTATWithoutHolidaysNew(convert(date,T1.scheduledt), convert(date, getdate()),0,0) WHEN t2.maxid IS not NULL and T2.uldt is null and  T2.Artstatus='PMChk' and T2.pmuldt < getdate() and dbo.fnTATWithoutHolidaysNew(convert(date,T2.pmuldt), convert(date, getdate()),0,0)>2 then dbo.fnTATWithoutHolidaysNew(convert(date,T2.pmuldt), convert(date, getdate()),0,0)WHEN t2.maxid IS not NULL and T2.uldt is null and T2.scheduledt<getdate() and  T2.Artstatus<>'PMChk'  then dbo.fnTATWithoutHolidaysNew(convert(date,T2.scheduledt), convert(date, getdate()),0,0)else t1.overdue end as Overdue,T1.PM as 'PM Name', T1.CM as 'CM Name','' as 'Remarks',dbo.fn_GetPMCheckDt(t1.ArticleID) 'PM Check',dbo.fn_GetFPMCheckDt(t1.ArticleID) 'Further PM Check',RevisedProofDate 'Revised Proof Sent Date' from T1  with(nolock) Left outer join T2  with(nolock) on t1.ArticleID=t2.ArticleID left outer join JR_Stage_Tran with(nolock)  on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages  with(nolock) ON JRST_JRS_ID=JR_Stages.JRS_ID WHERE CONVERT(DATE,t1.ReceivedDate)>='2022-01-01' order by Acronym,ArticleID";
                //string Q1 = "SSP_AutoReport 4";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1.Replace("'35'", "'110'"), db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rowsPM1 = ds.Tables[0].Rows;
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1.Replace("'35'", "'36'"), db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rowsAU1 = ds.Tables[0].Rows;
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1.Replace("'35'","'109'"), db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rowsPM = ds.Tables[0].Rows;
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rows = ds.Tables[0].Rows;
                string PSarticles = "";
                IDictionary<string, int> d = new Dictionary<string, int>();
                for (int i = 0; i < rows.Count; i++)
                {
                    if (Regex.IsMatch(rows[i][0].ToString(), str, RegexOptions.IgnoreCase)) continue;
                    if (rows[i][7].ToString() == "Proof Sent") PSarticles += "'" + rows[i][0].ToString() + "',";
                }
                PSarticles = Regex.Replace(PSarticles, ",$", "");
                string Q2 = " select  articleid,max(id) as dt,max(ACTUALDATE) as ACTUALDATE, case when  dbo.fnTATWithoutHolidaysNew(convert(date,max(ACTUALDATE)+2), convert(date, getdate()),0,0)<0 then '0' else dbo.fnTATWithoutHolidaysNew(convert(date,max(ACTUALDATE)+2), convert(date, getdate()),0,0) end as overdue    from TBL_REMINDER_TRANSACTIONS where articleid in (" + PSarticles + ") and isnull(ACTUALDATE,'')<>''  group by articleid";//and ULTYPE='EG'
                SqlDataAdapter sqa = new SqlDataAdapter(new SqlCommand(Q2, db.getconnectionEG()));
                DataTable dt1 = new DataTable();
                sqa.Fill(dt1);
                db.CloseConnectionEG();
                DataSet ds1 = new DataSet("New_DataSet");
                ds1.Tables.Add(dt1);
                var rows1 = ds1.Tables[0].Rows;
                for (int i = 0; i < rows1.Count; i++)
                {
                    d.Add(rows1[i][0].ToString(), Convert.ToInt32(rows1[i][3].ToString()));
                }
                Q2 = "select CUPR_ArticleID, case when  dbo.fnTATWithoutHolidaysNew(convert(date,CUPR_PEReminder_SentDT+2), convert(date, getdate()),0,0)<0 then '0' else dbo.fnTATWithoutHolidaysNew(convert(date,CUPR_PEReminder_SentDT+2), convert(date, getdate()),0,0) end as overdue  from CUPReminder where CUPR_ArticleID in (" + PSarticles + ") and isnull(CUPR_PEReminderDT,'')<>'' and isnull(CUPR_PEReminder_SentDT,'')<>''";
                sqa = new SqlDataAdapter(new SqlCommand(Q2, db.GetConnection()));
                dt1 = new DataTable();
                sqa.Fill(dt1);
                db.CloseConnection();
                ds1 = new DataSet("New_DataSet");
                ds1.Tables.Add(dt1);
                rows1 = ds1.Tables[0].Rows;
                for (int i = 0; i < rows1.Count; i++)
                {
                    d.Add(rows1[i][0].ToString(), Convert.ToInt32(rows1[i][3].ToString()));
                }
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Sheets[1];
                int j = 2;
                for (int i = 0; i < ds.Tables[0].Columns.Count; i++)
                {
                    xlWorkSheet.Cells[1, i + 1] = ds.Tables[0].Columns[i].ColumnName;
                }
                //PM1
                for (int i = 0; i < rowsPM1.Count; i++)
                {
                    if (Regex.IsMatch(rowsPM1[i][0].ToString(), str, RegexOptions.IgnoreCase)) continue;
                    if (rowsPM1[i][5].ToString() == "") continue;
                    str += "|" + rowsPM1[i][0].ToString();
                    for (int i1 = 0; i1 < ds.Tables[0].Columns.Count; i1++)
                    {
                        if (i1 == 9)
                        {
                            System.Globalization.CultureInfo cultureInfo = System.Threading.Thread.CurrentThread.CurrentCulture;
                            System.Globalization.TextInfo textInfo = cultureInfo.TextInfo;
                            xlWorkSheet.Cells[j, i1 + 1] = textInfo.ToTitleCase(rowsPM1[i][i1].ToString().ToLower());
                        }
                        else if (i1 == 8)
                        {
                            int a = Convert.ToInt32(rowsPM1[i][i1].ToString());
                            if (a > 0 && rowsPM1[i][7].ToString() != "PM Approval") a = a - 1;
                            xlWorkSheet.Cells[j, i1 + 1] = a.ToString();
                            if (d.ContainsKey(rowsPM1[i][0].ToString()))
                            {
                                a = d[rowsPM1[i][0].ToString()];
                                if (a > 0 && rowsPM1[i][7].ToString() != "PM Approval") a = a - 1;
                                xlWorkSheet.Cells[j, i1 + 1] = a.ToString();
                            }
                        }
                        else { xlWorkSheet.Cells[j, i1 + 1] = rowsPM1[i][i1]; }
                    }
                    j++;
                }
                //AU1
                for (int i = 0; i < rowsAU1.Count; i++)
                {
                    if (Regex.IsMatch(rowsAU1[i][0].ToString(), str, RegexOptions.IgnoreCase)) continue;
                    if (rowsAU1[i][5].ToString() == "") continue;
                    str += "|" + rowsAU1[i][0].ToString();
                    for (int i1 = 0; i1 < ds.Tables[0].Columns.Count; i1++)
                    {
                        if (i1 == 9)
                        {
                            System.Globalization.CultureInfo cultureInfo = System.Threading.Thread.CurrentThread.CurrentCulture;
                            System.Globalization.TextInfo textInfo = cultureInfo.TextInfo;
                            xlWorkSheet.Cells[j, i1 + 1] = textInfo.ToTitleCase(rowsAU1[i][i1].ToString().ToLower());
                        }
                        else if (i1 == 8)
                        {
                            int a = Convert.ToInt32(rowsAU1[i][i1].ToString());
                            if (a > 0 && rowsAU1[i][7].ToString() != "PM Approval") a = a - 1;
                            xlWorkSheet.Cells[j, i1 + 1] = a.ToString();
                            if (d.ContainsKey(rowsAU1[i][0].ToString()))
                            {
                                a = d[rowsAU1[i][0].ToString()];
                                if (a > 0 && rowsAU1[i][7].ToString() != "PM Approval") a = a - 1;
                                xlWorkSheet.Cells[j, i1 + 1] = a.ToString();
                            }
                        }
                        else { xlWorkSheet.Cells[j, i1 + 1] = rowsAU1[i][i1]; }
                    }
                    j++;
                }
                //PM
                for (int i = 0; i < rowsPM.Count; i++)
                {
                    if (Regex.IsMatch(rowsPM[i][0].ToString(), str, RegexOptions.IgnoreCase)) continue;
                    if (rowsPM[i][5].ToString() == "") continue;
                    str += "|" + rowsPM[i][0].ToString();
                    for (int i1 = 0; i1 < ds.Tables[0].Columns.Count; i1++)
                    {
                        if (i1 == 9)
                        {
                            System.Globalization.CultureInfo cultureInfo = System.Threading.Thread.CurrentThread.CurrentCulture;
                            System.Globalization.TextInfo textInfo = cultureInfo.TextInfo;
                            xlWorkSheet.Cells[j, i1 + 1] = textInfo.ToTitleCase(rowsPM[i][i1].ToString().ToLower());
                        }
                        else if (i1 == 8)
                        {
                            int a = Convert.ToInt32(rowsPM[i][i1].ToString());
                            if (a > 0 && rowsPM[i][7].ToString() != "PM Approval") a = a - 1;
                            xlWorkSheet.Cells[j, i1 + 1] = a.ToString();
                            if (d.ContainsKey(rowsPM[i][0].ToString()))
                            {
                                a = d[rowsPM[i][0].ToString()];
                                if (a > 0 && rowsPM[i][7].ToString() != "PM Approval") a = a - 1;
                                xlWorkSheet.Cells[j, i1 + 1] = a.ToString();
                            }
                        }
                        else { xlWorkSheet.Cells[j, i1 + 1] = rowsPM[i][i1]; }
                    }
                    j++;
                }
                //AU
                for (int i = 0; i < rows.Count; i++)
                {
                    if (Regex.IsMatch(rows[i][0].ToString(), str, RegexOptions.IgnoreCase)) continue;
                    for (int i1 = 0; i1 < ds.Tables[0].Columns.Count; i1++)
                    {
                        if (i1 == 9)
                        {
                            System.Globalization.CultureInfo cultureInfo = System.Threading.Thread.CurrentThread.CurrentCulture;
                            System.Globalization.TextInfo textInfo = cultureInfo.TextInfo;
                            xlWorkSheet.Cells[j, i1 + 1] = textInfo.ToTitleCase(rows[i][i1].ToString().ToLower());
                        }
                        else if (i1 == 8)
                        {
                            int a = Convert.ToInt32(rows[i][i1].ToString());
                            if (a > 0 && rows[i][7].ToString() != "PM Approval") a = a - 1;
                            xlWorkSheet.Cells[j, i1 + 1] = a.ToString();
                            if (d.ContainsKey(rows[i][0].ToString()))
                            {
                                a = d[rows[i][0].ToString()];
                                if (a > 0 && rows[i][7].ToString() != "PM Approval") a = a - 1;
                                xlWorkSheet.Cells[j, i1 + 1] = a.ToString();
                            }
                        }
                        else { xlWorkSheet.Cells[j, i1 + 1] = rows[i][i1]; }
                    }
                    j++;
                }
                Xl.Range chartRange = xlWorkSheet.get_Range("A1", "O" + (j - 1));
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeLeft).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeRight).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideHorizontal).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideVertical).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeBottom).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeTop).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Cells.HorizontalAlignment = Xl.XlHAlign.xlHAlignCenter;
                chartRange.Cells.VerticalAlignment = Xl.XlHAlign.xlHAlignCenter;
                chartRange = xlWorkSheet.get_Range("A1", "O1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                chartRange.Font.Bold = true;
                chartRange.Font.Size = 16;
                CellAlignment(chartRange);
                chartRange.EntireColumn.AutoFit();
                if (!(Directory.Exists(System.Environment.CurrentDirectory + @"\CUP_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\CUP_Report\");
                xlapp.DisplayAlerts = false;
                string fname = System.Environment.CurrentDirectory + @"\CUP_Report\CUPPM_Report_" + DateTime.Now.ToString("ddMMyyyy_HHmm") + ".xlsx";
                if (File.Exists(fname)) File.Delete(fname);
                xlWorkSheet.SaveAs(fname);
                xlapp.Quit();
                System.Threading.Thread.Sleep(5000);
                Cs.SendMail("CUP", "Dear Team,<Br/><Br/>Kindly find the attached Report.", "CUP PM", false, "CUP_report", fname, "CUP PM Daily Report");
                File.WriteAllText(System.Environment.CurrentDirectory + @"\CUP_Report\CUPPM_Report_" + DateTime.Now.ToString("ddMMyyyy") + @".txt", "");
            }
            catch (Exception e1)
            {
                //Cs.SendMail("IWAP", "IWAP Error:  Process aborted... " + e1.Message + "\n" + e1.StackTrace, "IWAP", true, "IWAP_report");
                Cs.SendMail("CUP", "CUP Daily PM Report:  Process aborted... " + e1.Message + "\n" + e1.StackTrace, "CUP PM", true, "CUP_report", "", "CUP PM Daily Report");
                return;
            }
        }

        public void CUP_RCP_Weekly_Report()
        {
            CommonClass Cs = new CommonClass();
            DBClass db = new DBClass();
            try
            {
                foreach (Process P in Process.GetProcessesByName("EXCEL"))
                {
                    try
                    {
                        P.Kill();
                    }
                    catch (Exception e2) { }
                }
                Xl.Workbook xlWorkBook;
                Xl.Worksheet xlWorkSheet;
                Xl.Application xlapp;
                xlapp = new Xl.Application();
                xlapp.Visible = false;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlapp.Workbooks.Add(misValue);
                //string Q1 = "select distinct * from (SELECT Jrnl_Acronym,Artcl_ArticleId,Artcl_ReceivedDt,maxid=(select max(JrnlTrns_OutTime) from TrnsJournal where JrnlTrns_ArticleId = Artcl_Id AND JrnlTrns_NextProcessID=121 AND convert(varchar,JrnlTrns_OutTime,112)<=convert(varchar,GETDATE(),112) AND convert(varchar,JrnlTrns_OutTime,112)>=convert(varchar,GETDATE()-7,112) )FROM Article left join journal on Artcl_JrnlId=jrnl_id left outer join TrnsJournal a WITH (NOLOCK) on Artcl_Id=a.JrnlTrns_ArticleId WHERE Artcl_JrnlId IN (1748,1747,1749,1750,1746) and convert(varchar,JrnlTrns_OutTime,112)<=convert(varchar,GETDATE(),112) AND convert(varchar,JrnlTrns_OutTime,112)>=convert(varchar,GETDATE()-7,112))A where maxid is not NULL order by Artcl_ReceivedDt";
                string Q1 = "SSP_AutoReport 1";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rows = ds.Tables[0].Rows;
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Sheets[1];
                xlWorkSheet.Name = "RCP PE Report";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "S.No.";
                xlWorkSheet.Cells[1, 2] = "Jrnl Name";
                xlWorkSheet.Cells[1, 3] = "Article ID";
                xlWorkSheet.Cells[1, 4] = "Pre-edit Received date";
                xlWorkSheet.Cells[1, 5] = "Pre-edit uploaded date";
                xlWorkSheet.Cells[1, 6] = "Remarks";             
                int j = 2;
                for (int i = 0; i < rows.Count; i++)
                {                 
                    xlWorkSheet.Cells[j, 1] = i+1;
                    xlWorkSheet.Cells[j, 2] = rows[i][0];
                    xlWorkSheet.Cells[j, 3] = rows[i][1];
                    xlWorkSheet.Cells[j, 4] = rows[i][2];
                    xlWorkSheet.Cells[j, 5] = rows[i][3];
                    j++;
                }
                Xl.Range chartRange = xlWorkSheet.get_Range("A1", "F" + (j - 1));
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeLeft).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeRight).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideHorizontal).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideVertical).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeBottom).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeTop).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Cells.HorizontalAlignment = Xl.XlHAlign.xlHAlignCenter;
                chartRange.Cells.VerticalAlignment = Xl.XlHAlign.xlHAlignCenter;
                chartRange = xlWorkSheet.get_Range("A1", "F1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                chartRange.Font.Bold = true;
                chartRange.Font.Size = 16;
                CellAlignment(chartRange);
                chartRange.EntireColumn.AutoFit();
                if (!(Directory.Exists(System.Environment.CurrentDirectory + @"\CUP_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\CUP_Report\");
                xlapp.DisplayAlerts = false;
                string fname = System.Environment.CurrentDirectory + @"\CUP_Report\RCP pre-edit details (" + DateTime.Now.AddDays(-7).ToString("dd MMM yyyy") + " to " + DateTime.Now.ToString("dd MMM yyyy") + ").xlsx";
                if (File.Exists(fname)) File.Delete(fname);
                xlWorkSheet.SaveAs(fname);
                xlapp.Quit();
                System.Threading.Thread.Sleep(5000);
                Cs.SendMail("CUP", "Dear Team,<Br/><Br/>Kindly find the attached Report.", "CUP RCP", false, "CUP_report", fname, "CUP RCP Weekly Report");
                File.WriteAllText(System.Environment.CurrentDirectory + @"\CUP_Report\CUPRCP_Report_" + DateTime.Now.ToString("ddMMyyyy") + @".txt", "");
            }
            catch (Exception e1)
            {
                //Cs.SendMail("IWAP", "IWAP Error:  Process aborted... " + e1.Message + "\n" + e1.StackTrace, "IWAP", true, "IWAP_report");
                Cs.SendMail("CUP", "CUP Weekly RCP Report:  Process aborted... " + e1.Message + "\n" + e1.StackTrace, "CUP RCP", true, "CUP_report", "", "CUP RCP Weekly Report");
                return;
            }
        }
        public void Frontiers_Daily_Report()
        {
            CommonClass Cs = new CommonClass();
            DBClass db = new DBClass();
            try
            {
                foreach (Process P in Process.GetProcessesByName("EXCEL"))
                {
                    try
                    {
                        P.Kill();
                    }
                    catch (Exception e2) { }
                }
                Xl.Workbook xlWorkBook;
                Xl.Worksheet xlWorkSheet;
                Xl.Application xlapp;
                xlapp = new Xl.Application();
                xlapp.Visible = false;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlapp.Workbooks.Add(misValue);
                string Q1 = "SSP_AutoReport 2";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rows = ds.Tables[0].Rows;
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Sheets[1];
                xlWorkSheet.Name = "CrossRef Details";
                xlWorkSheet.Cells.NumberFormat = "@";
                xlWorkSheet.Cells[1, 1] = "S.No.";
                xlWorkSheet.Cells[1, 2] = "Received Date";
                xlWorkSheet.Cells[1, 3] = "Dispatch Date";
                xlWorkSheet.Cells[1, 4] = "Articles";
                xlWorkSheet.Cells[1, 5] = "Proof Pages";
                xlWorkSheet.Cells[1, 6] = "Article Type";
                xlWorkSheet.Cells[1, 7] = "Specialty Section Heading";
                xlWorkSheet.Cells[1, 8] = "Publishing Day/Date";
                xlWorkSheet.Cells[2, 1] = "HEALTH ARTICLES";
                Xl.Range chartRange1 = xlWorkSheet.get_Range("A2", "H2");
                chartRange1.Merge();
                chartRange1.Font.Bold = true;
                
                int j = 3;
                for (int i = 0; i < rows.Count; i++)
                {
                    xlWorkSheet.Cells[j, 1] = i + 1;
                    xlWorkSheet.Cells[j, 2] = rows[i][5];
                    xlWorkSheet.Cells[j, 3] = rows[i][0];
                    xlWorkSheet.Cells[j, 4] = rows[i][1];
                    xlWorkSheet.Cells[j, 5] = rows[i][6];
                    xlWorkSheet.Cells[j, 6] = rows[i][2];
                    xlWorkSheet.Cells[j, 7] = rows[i][3];
                    xlWorkSheet.Cells[j, 8] = rows[i][4];
                    //xlWorkSheet.Cells[j, 8] = rows[i][6];

                    j++;
                }
                Xl.Range chartRange = xlWorkSheet.get_Range("A1", "H" + (j - 1));
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeLeft).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeRight).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideHorizontal).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideVertical).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeBottom).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeTop).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Cells.HorizontalAlignment = Xl.XlHAlign.xlHAlignCenter;
                chartRange.Cells.VerticalAlignment = Xl.XlHAlign.xlHAlignCenter;
                chartRange = xlWorkSheet.get_Range("A1", "H1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                chartRange.Font.Bold = true;
                chartRange.Font.Size = 16;
                CellAlignment(chartRange);
                chartRange.EntireColumn.AutoFit();
                if (!(Directory.Exists(System.Environment.CurrentDirectory + @"\Frontiers_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\Frontiers_Report\");
                xlapp.DisplayAlerts = false;
                string fname = System.Environment.CurrentDirectory + @"\Frontiers_Report\CrossRef_DOI_Details_on_(" + DateTime.Now.ToString("ddMMyyyy") + ").xlsx";
                if (File.Exists(fname)) File.Delete(fname);
                xlWorkSheet.SaveAs(fname);
                xlapp.Quit();
                System.Threading.Thread.Sleep(5000);
                Cs.SendMail("Frontiers", "Dear Team,<Br/><Br/>Kindly find the attached Report.", "Frontiers", false, "Frontiers_report", fname, "CrossRef DOI Details");
                File.WriteAllText(System.Environment.CurrentDirectory + @"\Frontiers_Report\CrossRef_DOI_Details_" + DateTime.Now.ToString("ddMMyyyy") + @".txt", "");
            }
            catch (Exception e1)
            {
                Cs.SendMail("Frontiers", "CrossRef DOI Details Report:  Process aborted... " + e1.Message + "\n" + e1.StackTrace, "Frontiers Due", true, "Frontiers_report", "", "CrossRef DOI Details");
                return;
            }
        }
        public void Convert_CUP_TXTtoExcel(string f)
        {
            CommonClass Cs = new CommonClass();
            DBClass db = new DBClass();
            string aid = "", doi = "", stid = "", title = "", pages = "", fpdt = "", audts = "", audt = "", au1dt = "", au2dt = "", au3dt = "", au4dt = "", au5dt = "", aurdt = "", au1rdt = "", au2rdt = "", au3rdt = "", au4rdt = "", au5rdt = "", arttype = "", acro = "", RecivedOrUpload = "R", stagename = "FirstProof";
            Boolean xlsuploadflag = false;
            if (Path.GetFileNameWithoutExtension(f).Split('_').Length == 1) { doi = Path.GetFileNameWithoutExtension(f); }
            else if (Path.GetFileNameWithoutExtension(f).Split('_').Length == 2) { aid = Path.GetFileNameWithoutExtension(f).Split('_')[0]; stid = Path.GetFileNameWithoutExtension(f).Split('_')[1]; }
            else { aid = Path.GetFileNameWithoutExtension(f).Split('_')[0]; stid = Path.GetFileNameWithoutExtension(f).Split('_')[1]; RecivedOrUpload = Path.GetFileNameWithoutExtension(f).Split('_')[2]; }
            if (aid == "") aid = Cs.ReturnDetail("Artcl_ArticleId", "Article,Journal", db, "charindex('_',Artcl_ArticleId)=0 and (Artcl_pii='" + doi + "' or Artcl_doi='" + doi + "') and Artcl_JrnlId=jrnl_id and Jrnl_Acronym not in('XYZ','ABC','AAA','DEF','YYY')");
            if (aid != "")
            {
                if (doi == "") doi = Cs.ReturnDetail("Artcl_pii", "Article", db, "Artcl_ArticleId='" + aid + "'");
                if (doi == "") doi = Cs.ReturnDetail("Artcl_doi", "Article", db, "Artcl_ArticleId='" + aid + "'");
                title = Cs.ReturnDetail("Artcl_Title", "Article", db, "Artcl_ArticleId='" + aid + "'");
                pages = Cs.ReturnDetail("Proof_Pages", "Article", db, "Artcl_ArticleId='" + aid + "'");
                fpdt = Cs.ReturnDetail("convert(date,Artcl_UploadedDt) as id", "Article", db, "Artcl_ArticleId='" + aid + "'");
                acro = Cs.ReturnDetail("Jrnl_Acronym", "article,Journal", db, "Artcl_ArticleId='" + aid + "'  and Artcl_JrnlId=jrnl_id");
                arttype = Cs.ReturnDetail("Artcl_ArtType", "Article", db, "Artcl_ArticleId='" + aid + "'");
                audts = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='" + stid + "'");

                if (stid != "") stagename = Cs.ReturnDetail("JRS_StageName", "JR_Stages", db, "JRS_ID='" + stid + "'");
                if (acro == "JPS" && stid == "35")
                {
                    aurdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='" + stid + "' and JRST_Status='17'");
                }
                else
                {
                    aurdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='" + stid + "'");
                }
                if ((fpdt != "" && stid == "") || (stid != "" && audts != "" && RecivedOrUpload == "U") || (stid != "" && aurdt != "" && RecivedOrUpload == "R")) { xlsuploadflag = true; }
                aurdt = "";
                if (stid != "")
                {

                    if (stid == "35")
                    {
                        audt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='35'");
                        aurdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 3','Level 2','Level 1','Partial PM') and  JRM_ArticleID='" + aid + "') and JRST_JRS_ID='35'");
                        //if (audt == "") return;
                        if (!String.IsNullOrEmpty(audt))
                        {
                            audt = Convert.ToDateTime(audt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(aurdt))
                        {
                            aurdt = Convert.ToDateTime(aurdt).ToString("dd-MM-yyyy");
                        }

                    }
                    else if (stid == "36")
                    {
                        audt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='35'");
                        aurdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 3','Level 2','Level 1','Partial PM') and  JRM_ArticleID='" + aid + "') and JRST_JRS_ID='35'");
                        au1dt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='36'");
                        au1rdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 2','Level 3') and JRM_ArticleID='" + aid + "') and JRST_JRS_ID='36'");
                        //if (au1dt == "") return;
                        if (!String.IsNullOrEmpty(audt))
                        {
                            audt = Convert.ToDateTime(audt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(aurdt))
                        {
                            aurdt = Convert.ToDateTime(aurdt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au1dt))
                        {
                            au1dt = Convert.ToDateTime(au1dt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au1rdt))
                        {
                            au1rdt = Convert.ToDateTime(au1rdt).ToString("dd-MM-yyyy");
                        }


                    }
                    else if (stid == "37")
                    {
                        audt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='35'");
                        aurdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 3','Level 2','Level 1','Partial PM') and JRM_ArticleID='" + aid + "') and JRST_JRS_ID='35'");
                        au1dt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main  where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='36'");
                        au1rdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 2','Level 3') and JRM_ArticleID='" + aid + "') and JRST_JRS_ID='36'");
                        au2dt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='37'");
                        au2rdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 2','Level 3') and JRM_ArticleID='" + aid + "') and JRST_JRS_ID='37'");
                        //if (au2dt == "") return;
                        if (!String.IsNullOrEmpty(audt))
                        {
                            audt = Convert.ToDateTime(audt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(aurdt))
                        {
                            aurdt = Convert.ToDateTime(aurdt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au1dt))
                        {
                            au1dt = Convert.ToDateTime(au1dt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au1rdt))
                        {
                            au1rdt = Convert.ToDateTime(au1rdt).ToString("dd-MM-yyyy");
                        }

                        if (!String.IsNullOrEmpty(au2dt))
                        {
                            au2dt = Convert.ToDateTime(au2dt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au2rdt))
                        {
                            au2rdt = Convert.ToDateTime(au2rdt).ToString("dd-MM-yyyy");
                        }
                    }
                    else if (stid == "78")
                    {
                        audt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='35'");
                        aurdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 3','Level 2','Level 1','Partial PM') and  JRM_ArticleID='" + aid + "') and JRST_JRS_ID='35'");
                        au1dt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='36'");
                        au1rdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 2','Level 3') and JRM_ArticleID='" + aid + "') and JRST_JRS_ID='36'");
                        au2dt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='37'");
                        au2rdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 2','Level 3') and  JRM_ArticleID='" + aid + "') and JRST_JRS_ID='37'");
                        au3dt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='78'");
                        au3rdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 2','Level 3') and  JRM_ArticleID='" + aid + "') and JRST_JRS_ID='78'");
                        //if (au3dt == "") return;
                        if (!String.IsNullOrEmpty(audt))
                        {
                            audt = Convert.ToDateTime(audt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(aurdt))
                        {
                            aurdt = Convert.ToDateTime(aurdt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au1dt))
                        {
                            au1dt = Convert.ToDateTime(au1dt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au1rdt))
                        {
                            au1rdt = Convert.ToDateTime(au1rdt).ToString("dd-MM-yyyy");
                        }

                        if (!String.IsNullOrEmpty(au2dt))
                        {
                            au2dt = Convert.ToDateTime(au2dt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au2rdt))
                        {
                            au2rdt = Convert.ToDateTime(au2rdt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au3dt))
                        {
                            au3dt = Convert.ToDateTime(au3dt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au3rdt))
                        {
                            au3rdt = Convert.ToDateTime(au3rdt).ToString("dd-MM-yyyy");
                        }

                    }
                    else if (stid == "97")
                    {
                        audt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='35'");
                        aurdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 3','Level 2','Level 1','Partial PM') and  JRM_ArticleID='" + aid + "') and JRST_JRS_ID='35'");
                        au1dt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='36'");
                        au1rdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 2','Level 3') and  JRM_ArticleID='" + aid + "') and JRST_JRS_ID='36'");
                        au2dt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='37'");
                        au2rdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 2','Level 3') and JRM_ArticleID='" + aid + "') and JRST_JRS_ID='37'");
                        au3dt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='78'");
                        au3rdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 2','Level 3') and JRM_ArticleID='" + aid + "') and JRST_JRS_ID='78'");
                        au4dt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='97'");
                        au4rdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 2','Level 3') and JRM_ArticleID='" + aid + "') and JRST_JRS_ID='97'");
                        //if (au4dt == "") return;
                        if (!String.IsNullOrEmpty(audt))
                        {
                            audt = Convert.ToDateTime(audt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(aurdt))
                        {
                            aurdt = Convert.ToDateTime(aurdt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au1dt))
                        {
                            au1dt = Convert.ToDateTime(au1dt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au1rdt))
                        {
                            au1rdt = Convert.ToDateTime(au1rdt).ToString("dd-MM-yyyy");
                        }

                        if (!String.IsNullOrEmpty(au2dt))
                        {
                            au2dt = Convert.ToDateTime(au2dt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au2rdt))
                        {
                            au2rdt = Convert.ToDateTime(au2rdt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au3dt))
                        {
                            au3dt = Convert.ToDateTime(au3dt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au3rdt))
                        {
                            au3rdt = Convert.ToDateTime(au3rdt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au4dt))
                        {
                            au4dt = Convert.ToDateTime(au4dt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au4rdt))
                        {
                            au4rdt = Convert.ToDateTime(au4rdt).ToString("dd-MM-yyyy");
                        }

                    }
                    else if (stid == "98")
                    {
                        audt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='35'");
                        aurdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 3','Level 2','Level 1','Partial PM') and JRM_ArticleID='" + aid + "') and JRST_JRS_ID='35'");
                        au1dt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='36'");
                        au1rdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 2','Level 3') and JRM_ArticleID='" + aid + "') and JRST_JRS_ID='36'");
                        au2dt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='37'");
                        au2rdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 2','Level 3') and JRM_ArticleID='" + aid + "') and JRST_JRS_ID='37'");
                        au3dt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='78'");
                        au3rdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 2','Level 3') and JRM_ArticleID='" + aid + "') and JRST_JRS_ID='78'");
                        au4dt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where JRM_ArticleID='" + aid + "') and JRST_JRS_ID='97'");
                        au4rdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 2','Level 3') and JRM_ArticleID='" + aid + "') and JRST_JRS_ID='97'");
                        au5dt = Cs.ReturnDetail("convert(date,JRST_UploadedDT) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main where  JRM_ArticleID='" + aid + "') and JRST_JRS_ID='98'");
                        au5rdt = Cs.ReturnDetail("convert(date,JRST_ReceivedDt) as id", "JR_Stage_Tran", db, "JRST_JRM_ID in(select jrm_id from JR_Main,journal where JRM_JournalID=Jrnl_Id and Jrnl_SmartPMLevel in('Level 2','Level 3') and JRM_ArticleID='" + aid + "') and JRST_JRS_ID='98'");
                        //if (au5dt == "") return;
                        if (!String.IsNullOrEmpty(audt))
                        {
                            audt = Convert.ToDateTime(audt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(aurdt))
                        {
                            aurdt = Convert.ToDateTime(aurdt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au1dt))
                        {
                            au1dt = Convert.ToDateTime(au1dt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au1rdt))
                        {
                            au1rdt = Convert.ToDateTime(au1rdt).ToString("dd-MM-yyyy");
                        }

                        if (!String.IsNullOrEmpty(au2dt))
                        {
                            au2dt = Convert.ToDateTime(au2dt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au2rdt))
                        {
                            au2rdt = Convert.ToDateTime(au2rdt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au3dt))
                        {
                            au3dt = Convert.ToDateTime(au3dt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au3rdt))
                        {
                            au3rdt = Convert.ToDateTime(au3rdt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au4dt))
                        {
                            au4dt = Convert.ToDateTime(au4dt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au4rdt))
                        {
                            au4rdt = Convert.ToDateTime(au4rdt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au5dt))
                        {
                            au5dt = Convert.ToDateTime(au5dt).ToString("dd-MM-yyyy");
                        }
                        if (!String.IsNullOrEmpty(au5rdt))
                        {
                            au5rdt = Convert.ToDateTime(au5rdt).ToString("dd-MM-yyyy");
                        }

                    }
                }
                else
                {
                    if (arttype == "157" || arttype == "643" || arttype == "1184" || arttype == "2051")
                    {
                        title = "";

                    }
                }
            }
            if (fpdt == "") return;
            fpdt = Convert.ToDateTime(fpdt).ToString("dd-MM-yyyy");
            if (xlsuploadflag == true)
            {
                try
                {
                    foreach (Process P in Process.GetProcessesByName("EXCEL"))
                    {
                        try
                        {
                            P.Kill();
                        }
                        catch (Exception e2) { }
                    }
                    Xl.Workbook xlWorkBook;
                    Xl.Worksheet xlWorkSheet;
                    Xl.Application xlapp;
                    xlapp = new Xl.Application();
                    xlapp.Visible = false;
                    object misValue = System.Reflection.Missing.Value;
                    xlWorkBook = xlapp.Workbooks.Add(misValue);
                    xlWorkSheet = (Xl.Worksheet)xlWorkBook.Sheets[1];
                    xlWorkSheet.Cells.NumberFormat = "@";
                    xlWorkSheet.Cells[1, 1] = "mnemonic";
                    xlWorkSheet.Cells[1, 2] = "doi";
                    xlWorkSheet.Cells[1, 3] = "number of pages";
                    xlWorkSheet.Cells[1, 4] = "title";
                    xlWorkSheet.Cells[1, 5] = "copy to copyed";
                    xlWorkSheet.Cells[1, 6] = "copy to typesetter";
                    xlWorkSheet.Cells[1, 7] = "first proof rec'd";
                    xlWorkSheet.Cells[1, 8] = "for correction";
                    xlWorkSheet.Cells[1, 9] = "revised proof";
                    xlWorkSheet.Cells[1, 10] = "for correction v1";
                    xlWorkSheet.Cells[1, 11] = "revised proof 1";
                    xlWorkSheet.Cells[1, 12] = "for correction v2";
                    xlWorkSheet.Cells[1, 13] = "revised proof 2";
                    xlWorkSheet.Cells[1, 14] = "for correction v3";
                    xlWorkSheet.Cells[1, 15] = "revised proof 3";
                    xlWorkSheet.Cells[1, 16] = "for correction v4";
                    xlWorkSheet.Cells[1, 17] = "revised proof 4";
                    xlWorkSheet.Cells[1, 18] = "for correction v5";
                    xlWorkSheet.Cells[1, 19] = "revised proof 5";
                    int j = 2;
                    if (pages == "") pages = "0";
                    xlWorkSheet.Cells[j, 1] = acro.ToUpper().Replace("CUP", "");
                    xlWorkSheet.Cells[j, 2] = doi;
                    xlWorkSheet.Cells[j, 3] = pages;
                    xlWorkSheet.Cells[j, 4] = title;
                    xlWorkSheet.Cells[j, 7] = fpdt;
                    xlWorkSheet.Cells[j, 8] = aurdt;
                    xlWorkSheet.Cells[j, 9] = audt;
                    xlWorkSheet.Cells[j, 10] = au1rdt;
                    xlWorkSheet.Cells[j, 11] = au1dt;
                    xlWorkSheet.Cells[j, 12] = au2rdt;
                    xlWorkSheet.Cells[j, 13] = au2dt;
                    xlWorkSheet.Cells[j, 14] = au3rdt;
                    xlWorkSheet.Cells[j, 15] = au3dt;
                    xlWorkSheet.Cells[j, 16] = au4rdt;
                    xlWorkSheet.Cells[j, 17] = au4dt;
                    xlWorkSheet.Cells[j, 18] = au5rdt;
                    xlWorkSheet.Cells[j, 19] = au5dt;                
                    Xl.Range chartRange = xlWorkSheet.get_Range("A1", "S2");
                    //chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeLeft).LineStyle = Xl.XlLineStyle.xlContinuous;
                    //chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeRight).LineStyle = Xl.XlLineStyle.xlContinuous;
                    //chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideHorizontal).LineStyle = Xl.XlLineStyle.xlContinuous;
                    //chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideVertical).LineStyle = Xl.XlLineStyle.xlContinuous;
                    //chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeBottom).LineStyle = Xl.XlLineStyle.xlContinuous;
                    //chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeTop).LineStyle = Xl.XlLineStyle.xlContinuous;
                    chartRange.Cells.HorizontalAlignment = Xl.XlHAlign.xlHAlignCenter;
                    chartRange.Cells.VerticalAlignment = Xl.XlHAlign.xlHAlignCenter;
                    chartRange.Font.Size = 10;               
                    chartRange.EntireColumn.AutoFit();
                    chartRange = xlWorkSheet.get_Range("A1", "S1");
                    //chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                    chartRange.Font.Bold = true;
                    //chartRange.Font.Size = 10;
                    //CellAlignment(chartRange);
                    //chartRange.EntireColumn.AutoFit();
                    xlapp.DisplayAlerts = false;
                    string fname =  Path.GetDirectoryName(Path.GetDirectoryName(f)) + @"\" + acro + "_Upload" + DateTime.Now.ToString("ddMMyyyy_HH-mm-ss") + ".xlsx";
                    if (File.Exists(fname)) File.Delete(fname);
                    xlWorkSheet.SaveAs(fname);
                    xlapp.Quit();
                    System.Threading.Thread.Sleep(5000);
                    if (!Directory.Exists(Path.GetDirectoryName(f) + @"\bk\")) Directory.CreateDirectory(Path.GetDirectoryName(f) + @"\bk\");
                    File.Copy(f, Path.GetDirectoryName(f) + @"\bk\" + Path.GetFileName(f), true);
                    File.Delete(f);
                    try {
                       // string Query = @"SSP_TypImp 2,'CUP','" + acro + "','" + aid + "','','','" + stagename + "','Success','" + RecivedOrUpload + "','" + Path.GetFileName(fname) + "','Yes','','','','','','DT0308','','DT0308','" + doi + "','" + pages + "','" + title + "','" + Convert.ToDateTime(fpdt).ToString("MM-DD-YYYY") + "','" + Convert.ToDateTime(aurdt).ToString("MM-DD-YYYY") + "','" + Convert.ToDateTime(audt).ToString("MM-DD-YYYY") + "','" + Convert.ToDateTime(au1rdt).ToString("MM-DD-YYYY") + "','" + Convert.ToDateTime(au1dt).ToString("MM-DD-YYYY") + "','" + Convert.ToDateTime(au2rdt).ToString("MM-DD-YYYY") + "','" + Convert.ToDateTime(au2dt).ToString("MM-DD-YYYY") + "','" + Convert.ToDateTime(au3rdt).ToString("MM-DD-YYYY") + "','" + Convert.ToDateTime(au3dt).ToString("MM-DD-YYYY") + "','" + Convert.ToDateTime(au4rdt).ToString("MM-DD-YYYY") + "','" + Convert.ToDateTime(au4dt).ToString("MM-DD-YYYY") + "','" + Convert.ToDateTime(au5rdt).ToString("MM-DD-YYYY") + "','" + Convert.ToDateTime(au5dt).ToString("MM-DD-YYYY") + "'";
                        string Query = @"SSP_TypImp 2,'CUP','" + acro + "','" + aid + "','','','" + stagename + "','Success','" + RecivedOrUpload + "','" + Path.GetFileName(fname) + "','Yes','','','','','','DT0308','','DT0308','" + doi + "','" + pages + "','" + title + "','" + fpdt + "','" + aurdt + "','" + audt + "','" + au1rdt + "','" + au1dt + "','" + au2rdt + "','" + au2dt + "','" + au3rdt + "','" + au3dt + "','" + au4rdt + "','" + au4dt + "','" + au5rdt + "','" + au5dt + "'";
                        db.SqlCmd = new System.Data.SqlClient.SqlCommand(Query, db.GetConnection());
                        Cs.SaveToReport("Status: " + Query + " " + aid);
                        db.OpenConnection();
                        db.SqlReader = db.SqlCmd.ExecuteReader();
                        db.SqlReader.Close();
                    }
                    catch (Exception e1) {
                        string Query = @"SSP_TypImp 2,'CUP','" + acro + "','" + aid + "','','','" + stagename + "','Failure','" + RecivedOrUpload + "','" + Path.GetFileName(fname) + "','No','','','','" + e1.StackTrace + "','','DT0308','','DT0308'";
                        db.SqlCmd = new System.Data.SqlClient.SqlCommand(Query, db.GetConnection());
                        Cs.SaveToReport("Status: Failure" + Query + " " + aid);
                        db.OpenConnection();
                        db.SqlReader = db.SqlCmd.ExecuteReader();
                        db.SqlReader.Close();
                    }
                    
                }
                catch (Exception e1)
                {
                    Cs.SendMail("CUP", "TymImp excel generation:  Process aborted... " + e1.Message + "\n" + e1.StackTrace, "CUP Tymimp", true, "CUP_report", "", "CUP Tymimp");
                    return;
                }
            }
        }

        public void CUP_PM_Weekly_Report()
        {
            CommonClass Cs = new CommonClass();
            DBClass db = new DBClass();
            try
            {
                foreach (Process P in Process.GetProcessesByName("EXCEL"))
                {
                    try
                    {
                        P.Kill();
                    }
                    catch (Exception e2) { }
                }
                Xl.Workbook xlWorkBook;
                Xl.Worksheet xlWorkSheet;
                Xl.Application xlapp;
                xlapp = new Xl.Application();
                xlapp.Visible = false;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlapp.Workbooks.Add(misValue);
                //string Q1 = @"with T1 as (SELECT DISTINCT convert(bit,'False') as 'Check',Jrnl_Title As JrnlTitle,Artcl_Status as Artstatus, Jrnl_Acronym AS Acronym, Artcl_ArticleId as ArticleID,Artcl_ManuScriptID as ManuscriptID,Artcl_AuthorName as AuthorName,CONVERT(DATE,Artcl_ReceivedDt) as ReceivedDate, ISNULL(Artcl_Title,'') AS Title,UsrMst_EmpNm as PM, jrnl_contact as CM, ArtType_Name as ArticleType,ISNULL(Artcl_OUPCopyright,'') as Copyright, ISNULL(Proof_Pages,0) AS PageExtent, '' AS CESendDate, '' AS CEFileRecDate, CONVERT(DATE,Artcl_UploadedDt) as ProofSentDate, '' AS AUCorrRecDate, Artcl_ScheduledDt as scheduledt,'' AS EditorCorrRecDate, ISNULL(Artcl_ColourOnline,'') AS ColourOnline, ISNULL(Artcl_ColourPrint,'') AS ColourPrint, '' ReviseAppDate,ISNULL(OUP_SPMComments,'') AS SPMComment,'0' as JRS_ID, '0' as overdue, Artcl_Volume as Volume,Artcl_Issue as Issue, Artcl_AuthorEmail as Email,CONVERT(DATE,Artcl_AUCorr_RecDT) AS Artcl_AUCorr_RecDT, CONVERT(DATE,Artcl_EDCorr_RecDT) AS Artcl_EDCorr_RecDT , Artcl_CUP_Remarks as smartremark  FROM Article with(nolock) , Journal with(nolock),ArticleTypes with(nolock),UsrMst with(nolock) where UsrMst_EmpId=Jrnl_User and Artcl_JrnlId=Jrnl_Id AND Jrnl_PublID=8 AND Artcl_ArtType=ArtType_ID and ISNULL(Jrnl_User, '')<>'' AND  Artcl_ArticleId NOT IN(SELECT DISTINCT JRA_ArticleID  FROM JR_Articles with(nolock) , JR_Stage_Tran with(nolock),  JR_Main with(nolock) ,TrnsJournalRev with(NOLOCK) WHERE JRM_ID=JRST_JRM_ID  AND JRST_ID=JRA_JRST_ID and JrnlTrns_ArticleId=JRA_ID AND JrnlTrns_Id=Jra_TransID AND ((JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=35) or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=36)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=37)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=109)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=110)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=111)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=112) or JRST_JRS_ID IN (33,34,38,39,40,41,42,43,44,49,50,57,58,64,65,66,71,73,74,75,82))) AND CHARINDEX('_',Artcl_ArticleID)=0 and CONVERT(date, Artcl_ReceivedDt) >= '2018-01-01'), T2 as (select MAX(JRST_ID) as maxid,JRA_ArticleID as ArticleID ,PrcsMst_name as Artstatus , CONVERT(DATE,JRST_ReceivedDt) AS AUCorrRecDate,jrst_scheduleddt as scheduledt,JRST_UploadedDT as uldt from JR_Articles with(nolock), JR_Main with(nolock), ProcessMst with(nolock), JR_Stage_Tran with(nolock), Journal with(nolock) where PrcsMst_Id=jrst_status and JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_Id and Jrnl_PublID=8 and JRA_ArticleID in (SELECT DISTINCT Artcl_ArticleId as ArticleID FROM Article with(nolock) , Journal with(nolock) WHERE Artcl_JrnlId=Jrnl_Id AND Jrnl_PublID=8  and ISNULL(Jrnl_User, '')<>'' AND Artcl_ArticleId NOT IN(SELECT DISTINCT JRA_ArticleID  FROM JR_Articles with(nolock) , JR_Stage_Tran with(nolock),  JR_Main with(nolock)  WHERE JRM_ID=JRST_JRM_ID AND JRST_ID=JRA_JRST_ID  AND JRST_JRS_ID IN(33,34,38,39,40,41,42,43,44,49,50,57,58,64,65,66,71,73,74,75,82)) )  and JRST_JRS_ID  in('35') group by JRA_ArticleID ,JRST_ReceivedDt,PrcsMst_name,jrst_scheduleddt,JRST_UploadedDT) SELECT  t1.ArticleID, t1.ManuscriptID,t1.ReceivedDate AS 'Mss Received',t1.ProofSentDate,t2.AUCorrRecDate AS 'Author corrections Received date', t1.EditorCorrRecDate AS 'Editor corrections Received date',CASE WHEN t2.maxid IS NULL and t1.ProofSentDate is null then  'First Proof'   WHEN t2.maxid IS NULL and t1.ProofSentDate is not null   THEN 'Proof Sent'    WHEN t2.maxid IS NULL and  T1.Artstatus='PMChk' THEN 'PM Approval'  WHEN t2.maxid IS not NULL and  T2.Artstatus='PMChk' THEN 'PM Approval' WHEN t2.AUCorrRecDate is not null or t1.EditorCorrRecDate is not null THEN 'Corrections received' else JRS_StageName  end as StageName,CASE WHEN t2.maxid IS NULL and t1.ProofSentDate is null and T1.scheduledt<getdate() then dbo.fnTATWithoutHolidaysNew(convert(date,T1.scheduledt), convert(date, getdate()),0,0) WHEN t2.maxid IS not NULL and T2.uldt is null and T2.scheduledt<getdate() then dbo.fnTATWithoutHolidaysNew(convert(date,T2.scheduledt), convert(date, getdate()),0,0)else t1.overdue end as Overdue,T1.PM as 'PM Name', T1.CM as 'CM Name','' as 'Remarks' from T1  with(nolock) Left outer join T2  with(nolock) on t1.ArticleID=t2.ArticleID left outer join JR_Stage_Tran with(nolock)  on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages  with(nolock) ON JRST_JRS_ID=JR_Stages.JRS_ID WHERE CONVERT(DATE,t1.ReceivedDate)>='2015-09-01' order by Acronym,ArticleID";     
                //string Q1 = @"with T1 as (SELECT DISTINCT convert(bit,'False') as 'Check',Jrnl_Title As JrnlTitle,Artcl_Status as Artstatus, Jrnl_Acronym AS Acronym, Artcl_ArticleId as ArticleID,Artcl_ManuScriptID as ManuscriptID,Artcl_AuthorName as AuthorName,CONVERT(DATE,Artcl_ReceivedDt) as ReceivedDate, ISNULL(Artcl_Title,'') AS Title,UsrMst_EmpNm as PM, jrnl_contact as CM, ArtType_Name as ArticleType,ISNULL(Artcl_OUPCopyright,'') as Copyright, ISNULL(Proof_Pages,0) AS PageExtent, '' AS CESendDate, '' AS CEFileRecDate, CONVERT(DATE,Artcl_UploadedDt) as ProofSentDate, '' AS AUCorrRecDate, Artcl_ScheduledDt as scheduledt,'' AS EditorCorrRecDate, ISNULL(Artcl_ColourOnline,'') AS ColourOnline, ISNULL(Artcl_ColourPrint,'') AS ColourPrint, '' ReviseAppDate,ISNULL(OUP_SPMComments,'') AS SPMComment,'0' as JRS_ID, '0' as overdue, Artcl_Volume as Volume,Artcl_Issue as Issue, Artcl_AuthorEmail as Email,CONVERT(DATE,Artcl_AUCorr_RecDT) AS Artcl_AUCorr_RecDT, CONVERT(DATE,Artcl_EDCorr_RecDT) AS Artcl_EDCorr_RecDT , Artcl_CUP_Remarks as smartremark  FROM Article with(nolock) , Journal with(nolock),ArticleTypes with(nolock),UsrMst with(nolock) where UsrMst_EmpId=Jrnl_User and Artcl_JrnlId=Jrnl_Id AND Jrnl_PublID=8 AND Artcl_ArtType=ArtType_ID and ISNULL(Jrnl_User, '')<>'' AND  Artcl_ArticleId NOT IN(SELECT DISTINCT JRA_ArticleID  FROM JR_Articles with(nolock) , JR_Stage_Tran with(nolock),  JR_Main with(nolock) ,TrnsJournalRev with(NOLOCK) WHERE JRM_ID=JRST_JRM_ID  AND JRST_ID=JRA_JRST_ID and JrnlTrns_ArticleId=JRA_ID AND JrnlTrns_Id=Jra_TransID AND ((JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=35) or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=36)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=37)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=109)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=110)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=111)  or (JrnlTrns_NextProcessID in('33') AND JRST_JRS_ID=112) or JRST_JRS_ID IN (33,34,38,39,40,41,42,43,44,49,50,57,58,64,65,66,71,73,74,75,82))) AND CHARINDEX('_',Artcl_ArticleID)=0 and CONVERT(date, Artcl_ReceivedDt) >= '2018-01-01'), T2 as (select MAX(JRST_ID) as maxid,JRA_ArticleID as ArticleID ,PrcsMst_name as Artstatus,JR_Articles.LastModifiedDate as pmuldt , CONVERT(DATE,JRST_ReceivedDt) AS AUCorrRecDate,jrst_scheduleddt as scheduledt,JRST_UploadedDT as uldt from JR_Articles with(nolock), JR_Main with(nolock), ProcessMst with(nolock), JR_Stage_Tran with(nolock), Journal with(nolock) where PrcsMst_Id=jrst_status and JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_Id and Jrnl_PublID=8 and JRA_ArticleID in (SELECT DISTINCT Artcl_ArticleId as ArticleID FROM Article with(nolock) , Journal with(nolock) WHERE Artcl_JrnlId=Jrnl_Id AND Jrnl_PublID=8  and ISNULL(Jrnl_User, '')<>'' AND Artcl_ArticleId NOT IN(SELECT DISTINCT JRA_ArticleID  FROM JR_Articles with(nolock) , JR_Stage_Tran with(nolock),  JR_Main with(nolock)  WHERE JRM_ID=JRST_JRM_ID AND JRST_ID=JRA_JRST_ID  AND JRST_JRS_ID IN(33,34,38,39,40,41,42,43,44,49,50,57,58,64,65,66,71,73,74,75,82)) )  and JRST_JRS_ID  in('35') group by JRA_ArticleID ,JRST_ReceivedDt,PrcsMst_name,jrst_scheduleddt,JRST_UploadedDT,JR_Articles.LastModifiedDate) SELECT  t1.ArticleID, t1.ManuscriptID,t1.ReceivedDate AS 'Mss Received',t1.ProofSentDate,t2.AUCorrRecDate AS 'Author corrections Received date', t1.EditorCorrRecDate AS 'Editor corrections Received date',CASE WHEN t2.maxid IS NULL and t1.ProofSentDate is null then  'First Proof'   WHEN t2.maxid IS NULL and t1.ProofSentDate is not null   THEN 'Proof Sent'    WHEN t2.maxid IS NULL and  T1.Artstatus='PMChk' THEN 'PM Approval'  WHEN t2.maxid IS not NULL and  T2.Artstatus='PMChk' THEN 'PM Approval' WHEN t2.AUCorrRecDate is not null or t1.EditorCorrRecDate is not null THEN 'Corrections received' else JRS_StageName  end as StageName,CASE WHEN t2.maxid IS NULL and t1.ProofSentDate is null and T1.scheduledt<getdate() then dbo.fnTATWithoutHolidaysNew(convert(date,T1.scheduledt), convert(date, getdate()),0,0) WHEN t2.maxid IS not NULL and T2.uldt is null and  T2.Artstatus='PMChk' and T2.pmuldt < getdate() and dbo.fnTATWithoutHolidaysNew(convert(date,T2.pmuldt), convert(date, getdate()),0,0)>2 then dbo.fnTATWithoutHolidaysNew(convert(date,T2.pmuldt), convert(date, getdate()),0,0)WHEN t2.maxid IS not NULL and T2.uldt is null and T2.scheduledt<getdate() and  T2.Artstatus<>'PMChk'  then dbo.fnTATWithoutHolidaysNew(convert(date,T2.scheduledt), convert(date, getdate()),0,0)else t1.overdue end as Overdue,T1.PM as 'PM Name', T1.CM as 'CM Name','' as 'Remarks' from T1  with(nolock) Left outer join T2  with(nolock) on t1.ArticleID=t2.ArticleID left outer join JR_Stage_Tran with(nolock)  on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages  with(nolock) ON JRST_JRS_ID=JR_Stages.JRS_ID WHERE CONVERT(DATE,t1.ReceivedDate)>='2015-09-01' order by Acronym,ArticleID";
                string Q1 = "with T1 as (SELECT DISTINCT convert(bit,'False') as 'Check',Jrnl_Title As JrnlTitle,Artcl_Status as Artstatus, Jrnl_Acronym AS Acronym, Artcl_ArticleId as ArticleID,Artcl_ManuScriptID as ManuscriptID,Artcl_AuthorName as AuthorName,CONVERT(DATE,Artcl_ReceivedDt) as ReceivedDate, ISNULL(Artcl_Title,'') AS Title,UsrMst_EmpNm as PM, jrnl_contact as CM, ArtType_Name as ArticleType,ISNULL(Artcl_OUPCopyright,'') as Copyright, ISNULL(Proof_Pages,0) AS PageExtent, '' AS CESendDate, '' AS CEFileRecDate, CONVERT(DATE,Artcl_UploadedDt) as ProofSentDate, '' AS AUCorrRecDate, Artcl_ScheduledDt as scheduledt,'' AS EditorCorrRecDate, ISNULL(Artcl_ColourOnline,'') AS ColourOnline, ISNULL(Artcl_ColourPrint,'') AS ColourPrint, '' ReviseAppDate,ISNULL(OUP_SPMComments,'') AS SPMComment,'0' as JRS_ID, '0' as overdue, Artcl_Volume as Volume,Artcl_Issue as Issue, Artcl_AuthorEmail as Email,CONVERT(DATE,Artcl_AUCorr_RecDT) AS Artcl_AUCorr_RecDT, CONVERT(DATE,Artcl_EDCorr_RecDT) AS Artcl_EDCorr_RecDT , Artcl_CUP_Remarks as smartremark  FROM Article with(nolock) , Journal with(nolock),ArticleTypes with(nolock),UsrMst with(nolock) where UsrMst_EmpId=Jrnl_User and Artcl_JrnlId=Jrnl_Id AND Jrnl_PublID=8 AND Artcl_ArtType=ArtType_ID and ISNULL(Jrnl_User, '')<>'' AND  Artcl_ArticleId NOT IN(SELECT DISTINCT JRA_ArticleID  FROM JR_Articles with(nolock) , JR_Stage_Tran with(nolock),  JR_Main with(nolock) ,TrnsJournalRev with(NOLOCK) WHERE JRM_ID=JRST_JRM_ID  AND JRST_ID=JRA_JRST_ID and JrnlTrns_ArticleId=JRA_ID AND JrnlTrns_Id=Jra_TransID AND (((JrnlTrns_NextProcessID in('33') or JRST_Status=38) AND JRST_JRS_ID=35) or ((JrnlTrns_NextProcessID in('33') or JRST_Status=38) AND JRST_JRS_ID=36)  or ((JrnlTrns_NextProcessID in('33') or JRST_Status=38) AND JRST_JRS_ID=37)  or ((JrnlTrns_NextProcessID in('33') or JRST_Status=38) AND JRST_JRS_ID=109)  or ((JrnlTrns_NextProcessID in('33') or JRST_Status=38) AND JRST_JRS_ID=110)  or ((JrnlTrns_NextProcessID in('33') or JRST_Status=38) AND JRST_JRS_ID=111)  or ((JrnlTrns_NextProcessID in('33') or JRST_Status=38) AND JRST_JRS_ID=112) or JRST_JRS_ID IN (33,34,38,39,40,41,42,43,44,49,50,57,58,64,65,66,71,73,74,75,82))) AND CHARINDEX('_',Artcl_ArticleID)=0 and CONVERT(date, Artcl_ReceivedDt) >= '2018-01-01'), T2 as (select MAX(JRST_ID) as maxid,JRA_ArticleID as ArticleID ,PrcsMst_name as Artstatus,JR_Articles.LastModifiedDate as pmuldt , CONVERT(DATE,JRST_ReceivedDt) AS AUCorrRecDate,jrst_scheduleddt as scheduledt,JRST_UploadedDT as uldt from JR_Articles with(nolock), JR_Main with(nolock), ProcessMst with(nolock), JR_Stage_Tran with(nolock), Journal with(nolock) where PrcsMst_Id=jrst_status and JRM_ID = JRST_JRM_ID And JRST_ID = JRA_JRST_ID and JRM_JournalID=Jrnl_Id and Jrnl_PublID=8 and JRA_ArticleID in (SELECT DISTINCT Artcl_ArticleId as ArticleID FROM Article with(nolock) , Journal with(nolock) WHERE Artcl_JrnlId=Jrnl_Id AND Jrnl_PublID=8  and ISNULL(Jrnl_User, '')<>'' AND Artcl_ArticleId NOT IN(SELECT DISTINCT JRA_ArticleID  FROM JR_Articles with(nolock) , JR_Stage_Tran with(nolock),  JR_Main with(nolock)  WHERE JRM_ID=JRST_JRM_ID AND JRST_ID=JRA_JRST_ID  AND JRST_JRS_ID IN(33,34,38,39,40,41,42,43,44,49,50,57,58,64,65,66,71,73,74,75,82)) )  and JRST_JRS_ID  in('35') group by JRA_ArticleID ,JRST_ReceivedDt,PrcsMst_name,jrst_scheduleddt,JRST_UploadedDT,JR_Articles.LastModifiedDate) SELECT  t1.ArticleID, t1.ManuscriptID,t1.ReceivedDate AS 'Mss Received',t1.ProofSentDate,t2.AUCorrRecDate AS 'Author corrections Received date', t1.EditorCorrRecDate AS 'Editor corrections Received date',CASE WHEN t2.maxid IS NULL and t1.ProofSentDate is null then  'First Proof'   WHEN t2.maxid IS NULL and t1.ProofSentDate is not null   THEN 'Proof Sent'    WHEN t2.maxid IS NULL and  T1.Artstatus='PMChk' THEN 'PM Approval'  WHEN t2.maxid IS not NULL and  T2.Artstatus='PMChk' THEN 'PM Approval' WHEN t2.AUCorrRecDate is not null or t1.EditorCorrRecDate is not null THEN 'Corrections received' else JRS_StageName  end as StageName,CASE WHEN t2.maxid IS NULL and t1.ProofSentDate is null and T1.scheduledt<getdate() then dbo.fnTATWithoutHolidaysNew(convert(date,T1.scheduledt), convert(date, getdate()),0,0) WHEN t2.maxid IS not NULL and T2.uldt is null and  T2.Artstatus='PMChk' and T2.pmuldt < getdate() and dbo.fnTATWithoutHolidaysNew(convert(date,T2.pmuldt), convert(date, getdate()),0,0)>2 then dbo.fnTATWithoutHolidaysNew(convert(date,T2.pmuldt), convert(date, getdate()),0,0)WHEN t2.maxid IS not NULL and T2.uldt is null and T2.scheduledt<getdate() and  T2.Artstatus<>'PMChk'  then dbo.fnTATWithoutHolidaysNew(convert(date,T2.scheduledt), convert(date, getdate()),0,0)else t1.overdue end as Overdue,T1.PM as 'PM Name', T1.CM as 'CM Name','' as 'Remarks' from T1  with(nolock) Left outer join T2  with(nolock) on t1.ArticleID=t2.ArticleID left outer join JR_Stage_Tran with(nolock)  on JR_Stage_Tran.JRST_ID=t2.maxid LEFT OUTER JOIN JR_Stages  with(nolock) ON JRST_JRS_ID=JR_Stages.JRS_ID WHERE CONVERT(DATE,t1.ReceivedDate)>='2015-09-01' order by Acronym,ArticleID";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rows = ds.Tables[0].Rows;
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Sheets[1];               
                int j = 2;             
                for (int i = 0; i < ds.Tables[0].Columns.Count; i++)
                {
                    xlWorkSheet.Cells[1, i + 1] = ds.Tables[0].Columns[i].ColumnName; 
                }
                for (int i = 0; i < rows.Count; i++)
                {
                    if (Regex.IsMatch(rows[i][0].ToString(), "AGS2000097|ASO1800120|ASO1800121|ASO1900001|BER1800004|BPP2000055|DEM1800003|EDE1000020|HEP2100002|HLG1900009|INT1900003|INT2000056|INT2000057|INT2000058|INT2000060|JMO1800074|JMO1800075|JMO1900060|JOI1800032|JOI1800037|JOI1800038|JSC SAMPLE|JSC1800012|LVC standard small sample|PAO1900002|PAR1800108|PAR1800109|PAR1800158|PAR1800159|PAR1800162|PAR1800171|PAR1800172|PAR2000161|PAR2000162|pem1800044|pem1800045|PRM1900019|PSM1800358|PSM2000152|RAF2100006|RAM1900020|SSR1800033|SSR2100002|THC1800016|TRE1800010|TRE1800021|TRE1800022|TRE1800023|TRE1800024|TRE1800025|TRE1800026|TRE1800027|TRE1800028|TRE1800029|TRE1800030|TRE1800031|TRE1800032|TRE1800033|TRE1800034|TRE1800035|TRE1800036|TRE1800037|TRE1800038|TRE1800039|TRE1800040|TRE1800041|TRE1800044|TRE1800045|TRE1800046|TRE1800047|TRE1800048|TRE1800049|TRE1800050|TRE1800051|TRE1800052|TRE1800053|TRE1800054|TRE1800055|TRE1800056|TRE1800057|TRE1800058|TRE1800059|TRE1800060|TRE1800061|TRE1800062|TRE1800063|TRE1800064|TRE1800065|TRE1800066|TRE1800067|TRE1800068|TRE1800069|TRE1800070|TRE1800072|TRE1800073|TRE1800074|TRE1800075|TRE1800076|TRE1800077|TRE1800079|TRE1800080|TRE1800081|TRE1800082|TRE1800083|TRE1800084|TRE1800085|TRE1800086|TRE1800087|TRE1800088|TRE1800089|TRE1800090|TRE1800091|TRE1800092|TRE1800093|TRE1800096|TRE1800099|TRE1900001|TRE1900004|TRE1900005|TRE1900006|TRE1900012|TRE1900015|TRE1900017|TRE1900018|TRE1900020|TRE1900021|XYZ1700079|XYZ1700080|XYZ1700081|XYZ1700082|XYZ1700083|XYZ1700084|XYZ1700085|XYZ1700086|XYZ1700087|XYZ1700088|XYZ1700089|XYZ1700090|XYZ1700091|XYZ1800091|BPP2000062|BPP2100002|BPP2100003|LSY1800055|LSY1800056|LSY1800132|LSY1800133|LSY2000082|LVC2100006|LVC2100007|MRS2000149|MRS2000203|MRS2000231|MRS2000253|MRS2000279|MRS2000280|NAV2000010|PAX1800042|PAX1800043|PAX1900027|PAX1900028|PAX2000068|PES1800028|PES1800029|PES1900005|PES1900006|PES2100001|PES2100002|SAP2000015|SAP2000016|SAP2100006|ERM2100006|MRF1800115|MRF2100032|NAV1800041|NAV2100016|PRM2000093|PRM2000094", RegexOptions.IgnoreCase)) continue;
                    for (int i1 = 0; i1 < ds.Tables[0].Columns.Count; i1++)
                    {
                        if (i1 == 8)
                        {
                            System.Globalization.CultureInfo cultureInfo = System.Threading.Thread.CurrentThread.CurrentCulture;
                            System.Globalization.TextInfo textInfo = cultureInfo.TextInfo;
                            xlWorkSheet.Cells[j, i1 + 1] = textInfo.ToTitleCase(rows[i][i1].ToString().ToLower());
                        }
                        else if (i1 == 7)
                        {
                            int a = Convert.ToInt32(rows[i][i1].ToString());
                            if (a > 0 && rows[i][6].ToString() != "PM Approval") a = a - 1;
                            xlWorkSheet.Cells[j, i1 + 1] = a.ToString();
                        }
                        else { xlWorkSheet.Cells[j, i1 + 1] = rows[i][i1]; }
                    }
                    j++;
                }
                Xl.Range chartRange = xlWorkSheet.get_Range("A1", "K" + (j - 1));
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeLeft).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeRight).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideHorizontal).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideVertical).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeBottom).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeTop).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Cells.HorizontalAlignment = Xl.XlHAlign.xlHAlignCenter;
                chartRange.Cells.VerticalAlignment = Xl.XlHAlign.xlHAlignCenter;
                chartRange = xlWorkSheet.get_Range("A1", "K1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                chartRange.Font.Bold = true;
                chartRange.Font.Size = 16;
                CellAlignment(chartRange);
                chartRange.EntireColumn.AutoFit();
                if (!(Directory.Exists(System.Environment.CurrentDirectory + @"\CUP_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\CUP_Report\");
                xlapp.DisplayAlerts = false;
                string fname = System.Environment.CurrentDirectory + @"\CUP_Report\CUPPM_Report_" + DateTime.Now.ToString("ddMMyyyy_HHmm") + ".xlsx";
                if (File.Exists(fname)) File.Delete(fname);
                xlWorkSheet.SaveAs(fname);
                xlapp.Quit();
                System.Threading.Thread.Sleep(5000);
                Cs.SendMail("CUP", "Dear Team,<Br/><Br/>Kindly find the attached Report.", "CUP PM", false, "CUP_report", fname, "CUP PM Weekly Report");
                File.WriteAllText(System.Environment.CurrentDirectory + @"\CUP_Report\CUPPM_Report_" + DateTime.Now.ToString("ddMMyyyy") + @".txt", "");
            }
            catch (Exception e1)
            {
                //Cs.SendMail("IWAP", "IWAP Error:  Process aborted... " + e1.Message + "\n" + e1.StackTrace, "IWAP", true, "IWAP_report");
                Cs.SendMail("CUP", "CUP Weekly PM Report:  Process aborted... " + e1.Message + "\n" + e1.StackTrace, "CUP PM", true, "CUP_report", "", "CUP PM Weekly Report");
                return;
            }
        }

        public void CUP_MonthlyReport()
        {
            CommonClass Cs = new CommonClass();
            DBClass db = new DBClass();
            try
            {
                foreach (Process P in Process.GetProcessesByName("EXCEL"))
                {
                    try
                    {
                        P.Kill();
                    }
                    catch (Exception e2) { }
                }
                Xl.Workbook xlWorkBook;
                Xl.Worksheet xlWorkSheet;
                Xl.Application xlapp;
                xlapp = new Xl.Application();
                xlapp.Visible = false;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlapp.Workbooks.Add(misValue);
//                string Q1 = @"select Jrnl_Acronym as Journal,REPLACE(Artcl_ArticleId,Jrnl_Acronym,'') as 'Setters no',proof_pages as 'Page numbers' from article,Journal where Artcl_JrnlId=Jrnl_Id and Artcl_ArticleId in ( select distinct Artcl_ArticleId from Article where  CHARINDEX(' ',Artcl_ArticleId)=0 and CHARINDEX('_',Artcl_ArticleId)=0 and isnull(artcl_uploadeddt,'')<>'' and month(artcl_uploadeddt)=month(getdate()-1) and year(artcl_uploadeddt)=year(getdate()-1) and Artcl_JrnlId in (select jrnl_id from journal where Jrnl_Acronym in ('BJA','BJB','BJP','BJI','BJO','nav','lis','jhl','com','flm','pla') and Jrnl_PublID=8)) order by Artcl_UploadedDt
//";
     //string Q1 = @"select Artcl_ArticleId,Artcl_UploadedDt, Jrnl_Acronym as Journal,REPLACE(Artcl_ArticleId,Jrnl_Acronym,'') as 'Setters no',proof_pages as 'Page numbers' from article,Journal where Artcl_JrnlId=Jrnl_Id and Artcl_ArticleId in ( select distinct Artcl_ArticleId from Article where  CHARINDEX(' ',Artcl_ArticleId)=0 and CHARINDEX('_',Artcl_ArticleId)=0 and isnull(artcl_uploadeddt,'')<>'' and month(artcl_uploadeddt)=month(getdate()) and year(artcl_uploadeddt)=year(getdate()) and Artcl_JrnlId in (select jrnl_id from journal where Jrnl_Acronym in ('BJA','BJB','BJP','BJI','BJO','nav','lis','jhl') and Jrnl_PublID=8)) order by Artcl_UploadedDt --Jrnl_Acronym in ('com','flm','pla','BJA','BJB','BJP','BJI','BJO','nav','lis','jhl') and Jrnl_PublID=4))";
                string Q1 = "SSP_AutoReport 11";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                var rows = ds.Tables[0].Rows;
                xlWorkSheet = (Xl.Worksheet)xlWorkBook.Sheets[1];               
                xlWorkSheet.Cells[1, 1] = "Journal";
                xlWorkSheet.Cells[1, 2] = "Setters no";
                xlWorkSheet.Cells[1, 3] = "Page numbers";            
                int j = 2;
                for (int i = 0; i < rows.Count; i++)
                {
                    xlWorkSheet.Cells[j, 1] = rows[i][0];
                    xlWorkSheet.Cells[j, 2] = rows[i][1];
                    xlWorkSheet.Cells[j, 3] = rows[i][2];                  
                    j++;

                }
                Xl.Range chartRange = xlWorkSheet.get_Range("A1", "C" + (j - 1));
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeLeft).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeRight).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideHorizontal).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideVertical).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeBottom).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeTop).LineStyle = Xl.XlLineStyle.xlContinuous;
                chartRange.Cells.HorizontalAlignment = Xl.XlHAlign.xlHAlignCenter;
                chartRange.Cells.VerticalAlignment = Xl.XlHAlign.xlHAlignCenter;
                chartRange = xlWorkSheet.get_Range("A1", "C1");
                chartRange.Interior.Color = Xl.XlRgbColor.rgbSilver;
                chartRange.Font.Bold = true;
                chartRange.Font.Size = 16;
                CellAlignment(chartRange);
                chartRange.EntireColumn.AutoFit();
                if (!(Directory.Exists(System.Environment.CurrentDirectory + @"\CUP_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\CUP_Report\");
                xlapp.DisplayAlerts = false;
                //string fname = System.Environment.CurrentDirectory + @"\IWAP_Report\Online Publication Dates.xlsx";
                string fname = System.Environment.CurrentDirectory + @"\CUP_Report\SS Typeset page numbers - " + DateTime.Today.AddDays(-1).ToString("MMM") + DateTime.Today.AddDays(-1).ToString("yyyy") + ".xlsx";
                if (File.Exists(fname)) File.Delete(fname);
                xlWorkSheet.SaveAs(fname);
                xlapp.Quit();
                try
                {
                    System.Threading.Thread.Sleep(5000);                  
                    using (WebClient client = new WebClient())
                    {
                        client.Credentials = new NetworkCredential("SSL13", "gEmSt9us");
                        client.UploadFile("ftp://ftp2.sunrise-setting.co.uk/ToSSL/Typeset page numbers/" + Path.GetFileName(fname), WebRequestMethods.Ftp.UploadFile, fname);
                    }    
                    Cs.SendMail("CUP", "CUP Monthy's Report:  Success...", "CUPM", false, "CUP_report", fname);
                    File.WriteAllText(System.Environment.CurrentDirectory + @"\CUP_Report\CUP_Report_" + DateTime.Now.ToString("ddMMyyyy") + @"_Monthly.txt", "");
                }

                catch (Exception ex)
                {
                    Cs.SendMail("CUP", "CUP Monthy's Report:  Process aborted... " + ex.Message + "\n" + ex.StackTrace, "CUPM", true, "CUP_report");
                    return;
                }
                //MessageBox.Show("Process completed");
            }
            catch (Exception e1)
            {
                //Cs.SendMail("IWAP", "IWAP Error:  Process aborted... " + e1.Message + "\n" + e1.StackTrace, "IWAP", true, "IWAP_report");
                Cs.SendMail("CUP", "CUP Monthy's Report:  Process aborted... " + e1.Message + "\n" + e1.StackTrace, "CUPM", true, "CUP_report");
                return;
            }
        }

        public void CUP_DailyReport()
        {
            CommonClass Cs = new CommonClass();
            DBClass db = new DBClass();
            if (!(Directory.Exists(System.Environment.CurrentDirectory + @"\CUP_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\CUP_Report\");
            try
            {
                //string Q1 = "SELECT Artcl_ArticleId AS ArticleID,Artcl_ReceivedDt AS ReceivedDate,Artcl_ScheduledDt AS ScheduledDate,Artcl_Status AS Status,Artcl_CEReceiveDate AS CEReceivedDate,isnull(Artcl_smartRemarks,'') as Remarks FROM Article WHERE Artcl_JrnlId IN (1748,1747,1749,1750,1746) AND Artcl_UploadedDt IS NULL AND Artcl_Status NOT IN ('CE-Cust') AND convert(varchar,Artcl_ScheduledDt,112)<=convert(varchar,GETDATE(),112) ORDER BY Artcl_ReceivedDt";
                string Q1 = "SSP_AutoReport 10";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                string textBody = ""; string dt = Regex.Replace(DateTime.Today.ToString("MM/dd/yyyy").Replace("/0", "/"), "^0", "");
                if (ds.Tables[0].Rows.Count > 0)
                {
                    textBody = "<h2><u>First Proof</u></h2><table border=" + 1 + "><tr  bgcolor='#87cefa'>";
                    //<td><b>ArticleID</b></td><td> <b>ReceivedDate</b></td><td> <b>ScheduledDate</b></td><td> <b>Status</b></td><td> <b>CEReceivedDate</b></td> <td> <b>CEReceivedDate</b></td></tr>";                   
                    foreach (DataColumn myColumn in ds.Tables[0].Columns)
                    {
                        textBody += "<td><b>" + myColumn.ColumnName + "</b></td>";
                    }
                    textBody += "<td><b>Due/Overdue</b></td>";
                    textBody += "</tr>";
                    foreach (DataRow myRow in ds.Tables[0].Rows)
                    {
                        if (myRow["ScheduledDate"].ToString().Split(' ')[0] != dt) textBody += "<tr bgcolor='red'>";
                        else textBody += "<tr >";
                        foreach (DataColumn myColumn in ds.Tables[0].Columns)
                        {
                            if (myColumn.ColumnName == "ScheduledDate" || myColumn.ColumnName == "ReceivedDate") textBody += "<td >" + formatdate(myRow[myColumn.ColumnName].ToString()) + "</td>";
                            else textBody += "<td >" + myRow[myColumn.ColumnName].ToString() + "</td>";
                        }
                        if (myRow["ScheduledDate"].ToString().Split(' ')[0] != dt) textBody += "<td >Overdue</td>";
                        else textBody += "<td >Due</td>";
                        textBody += "</tr>";
                    }
                    textBody += "</table>";
                }
                else textBody += "<h2><u>First Proof</u></h2><h3>No Record Found</h3>";
                string Q2 = "SELECT JRM_ArticleID AS ArticleID,JRST_ReceivedDt AS ReceivedDate,JRST_ScheduledDt AS ScheduledDate,PrcsMst_Name AS Status,isnull(JRST_SmartRemarks,'') as Remarks FROM JR_Main,JR_Stage_Tran,JR_Articles,ProcessMst WHERE JRM_ID=JRST_JRM_ID and JRST_ID=JRA_JRST_ID AND JRST_Status=PrcsMst_Id AND JRM_JournalID IN (1748,1747,1749,1750,1746) AND JRST_JRS_ID IN (35,36,37,78,97,98) AND convert(varchar,JRST_ScheduledDt,112)<=convert(varchar,GETDATE(),112) AND JRST_UploadedDT IS NULL ORDER BY JRST_ReceivedDt";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q2, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    textBody += "<h2><u>Revises</u></h2><table border=" + 2 + "><tr bgcolor='#87cefa'>";

                    foreach (DataColumn myColumn in ds.Tables[0].Columns)
                    {
                        textBody += "<td><b>" + myColumn.ColumnName + "</b></td>";
                    }
                    textBody += "<td><b>Due/Overdue</b></td>";
                    textBody += "</tr>";
                    foreach (DataRow myRow in ds.Tables[0].Rows)
                    {
                        if (myRow["ScheduledDate"].ToString().Split(' ')[0] != dt) textBody += "<tr bgcolor='red'>";
                        else textBody += "<tr >";
                        foreach (DataColumn myColumn in ds.Tables[0].Columns)
                        {
                            if (myColumn.ColumnName == "ScheduledDate" || myColumn.ColumnName == "ReceivedDate") textBody += "<td >" + formatdate(myRow[myColumn.ColumnName].ToString()) + "</td>";
                            else textBody += "<td >" + myRow[myColumn.ColumnName].ToString() + "</td>";
                        }
                        if (myRow["ScheduledDate"].ToString().Split(' ')[0] != dt) textBody += "<td >Overdue</td>";
                        else textBody += "<td >Due</td>";
                        textBody += "</tr>";
                    }
                    textBody += "</table>";
                }
                else textBody += "<h2><u>Revises</u></h2><h3>No Record Found</h3>";
                string Q3 = "SELECT Jrnl_Acronym as Journal, JRM_Volume AS Volume, JRM_Issue as Issue,JRST_ReceivedDt AS ReceivedDate,JRST_ScheduledDt AS ScheduledDate,PrcsMst_Name AS Status,isnull(JRST_SmartRemarks,'') as Remarks FROM JR_Main,JR_Stage_Tran,JR_Articles,ProcessMst,Journal WHERE JRM_ID=JRST_JRM_ID and JRST_ID=JRA_JRST_ID AND JRST_Status=PrcsMst_Id AND JRM_JournalID=Jrnl_Id AND JRM_JournalID IN (1748,1747,1749,1750,1746) AND convert(varchar,JRST_ScheduledDt,112)<=convert(varchar,GETDATE(),112) AND JRST_JRS_ID IN (38,39,40,99,101) AND JRST_UploadedDT IS NULL ORDER BY JRST_ReceivedDt";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q3, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    textBody += "<h2><u>Issue</u></h2><table border=" + 1 + "><tr bgcolor='#87cefa'>";

                    foreach (DataColumn myColumn in ds.Tables[0].Columns)
                    {
                        textBody += "<td><b>" + myColumn.ColumnName + "</b></td>";
                    }
                    textBody += "<td><b>Due/Overdue</b></td>";
                    textBody += "</tr>";
                    foreach (DataRow myRow in ds.Tables[0].Rows)
                    {
                        if (myRow["ScheduledDate"].ToString().Split(' ')[0] != dt) textBody += "<tr bgcolor='red'>";
                        else textBody += "<tr >";
                        foreach (DataColumn myColumn in ds.Tables[0].Columns)
                        {
                            if (myColumn.ColumnName == "ScheduledDate" || myColumn.ColumnName == "ReceivedDate") textBody += "<td >" + formatdate(myRow[myColumn.ColumnName].ToString()) + "</td>";
                            else textBody += "<td >" + myRow[myColumn.ColumnName].ToString() + "</td>";
                        }
                        if (myRow["ScheduledDate"].ToString().Split(' ')[0] != dt) textBody += "<td >Overdue</td>";
                        else textBody += "<td >Due</td>";
                        textBody += "</tr>";
                    }
                    textBody += "</table>";
                }
                else textBody += "<h2><u>Issue</u></h2><h3>No Record Found</h3>";
                System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("Rajasekar@novatechset.com", "kalaivani@novatechset.com", "CUP RCP Report: " + DateTime.Today.ToString("dd/MM/yyyy"), textBody + "<Br/><Br/>Regards,<Br/>TechSupport.");
                MM.To.Add("viji@novatechset.com");
                MM.CC.Add("rajeshkannah@novatechset.com");
                //MM.CC.Add("abdulk@novatechset.com");
                MM.Bcc.Add("tiworkflow@novatechset.com");
                //MM.Bcc.Add("automailer@novatechset.com");
                //MM.Bcc.Add("Saravanakumar@novatechset.com");
                //System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("Rajasekar@novatechset.com", "parthiban@novatechset.com", "CUP RCP Report: " + DateTime.Today.ToString("dd/MM/yyyy"), textBody + "<Br/><Br/>Regards,<Br/>TechSupport.");
                System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                MM.IsBodyHtml = true;
                client.Send(MM);
                File.WriteAllText(System.Environment.CurrentDirectory + @"\CUP_Report\CUP_Report_" + DateTime.Now.ToString("ddMMyyyy") + @".txt", "");
            }                
            catch (Exception e1)
            {
                System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("Rajasekar@novatechset.com", "tiworkflow@novatechset.com", "CUP RCP Report: " + DateTime.Today.ToString("dd/MM/yyyy"), "Error while generating report: " + e1.Message + "<Br/>" + e1.StackTrace + "<Br/><Br/>Regards,<Br/>TechSupport.");
                System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                MM.IsBodyHtml = true;
                client.Send(MM);
                return;
            }
        }
        public void TnF_DailyReport()
        {
            CommonClass Cs = new CommonClass();
            DBClass db = new DBClass();
            if (Directory.Exists(System.Environment.CurrentDirectory + @"\TnF_Report\")) 
                Directory.Delete(System.Environment.CurrentDirectory + @"\TnF_Report\", true);   
            Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\TnF_Report\");

            try
            {
                string Q1 = "select DISTINCT Artcl_ArticleId,Artcl_Status from article where Artcl_JrnlId in (select jrnl_id from journal where Jrnl_Acronym in (" + File.ReadAllText(System.Environment.CurrentDirectory + @"\Formatfreejrnl.txt") + ")) AND  CONVERT(date,Artcl_ReceivedDt)='" + DateTime.Now.AddDays(-1).ToString("yyyy-MM-dd") + "'and CHARINDEX('-',Artcl_ArticleId)=0 and CHARINDEX('_',Artcl_ArticleId)=0 and CHARINDEX('cover',Artcl_ArticleId)= 0";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                string textBody = "";
                //string dt = Regex.Replace(DateTime.Today.ToString("MM/dd/yyyy").Replace("/0", "/"), "^0", "");
                if (ds.Tables[0].Rows.Count > 0)
                {
                    textBody = "<p>Hi Team,<br /><br />";
                    textBody += "The below article(s) were received in Format Free journal workflow on last day : " + DateTime.Now.AddDays(-1).ToString("dd-MM-yyyy") + " <br /><br />";
                    textBody += "<table border=" + 1 + @"><tr><span style='font-size:10.0pt;font-family:Arial'><td align=""center""><b>ArticleID</b></td></span><span style='font-size:10.0pt;font-family:Arial'><td align=""center""><b>Status</b></td></span></tr>";
                    for (int i = 0; i < db.dt.Rows.Count - 1; i++)
                    {
                        textBody += "<tr><span><td>" + db.dt.Rows[i]["Artcl_ArticleId"].ToString() + "</td> <td>" + db.dt.Rows[i]["Artcl_Status"].ToString() + "</span></tr>";
                       
                    }
                    textBody += "</table>";
                    System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("automailer@novatechset.com", "sathyac@novatechset.com", "Last day received Format Free journal articles list " + DateTime.Now.AddDays(-1).ToString("dd-MM-yyyy"), textBody + "<Br/><Br/>Regards,<Br/>TechSupport.");
                    MM.To.Add("padmashanthi@novatechset.com");
                    MM.CC.Add("senthilkumaran@novatechset.com");
                    System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                    MM.IsBodyHtml = true;
                    client.Send(MM);
                    File.WriteAllText(System.Environment.CurrentDirectory + @"\TnF_Report\TnF_Report_" + DateTime.Now.ToString("ddMMyyyy") + @".txt", "");

                }
            }
            catch (Exception e1)
            {
                System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("automailer@novatechset.com", "senthilkumaran@novatechset.com", "TnF Format free Report: " + DateTime.Today.ToString("dd/MM/yyyy"), "Error while generating report: " + e1.Message + "<Br/>" + e1.StackTrace + "<Br/><Br/>Regards,<Br/>TechSupport.");
                System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                MM.IsBodyHtml = true;
                client.Send(MM);
                return;
            }
        }


        public void TnF_OnshoreCSHL()
        {
            CommonClass Cs = new CommonClass();
            DBClass db = new DBClass();
            if (Directory.Exists(System.Environment.CurrentDirectory + @"\TnF_OnshoreCSHL\"))
                Directory.Delete(System.Environment.CurrentDirectory + @"\TnF_OnshoreCSHL\", true);
            Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\TnF_OnshoreCSHL\");

            try
            {
                string Q1 = "select  Artcl_ArticleId from journal inner join article on Jrnl_Id=Artcl_JrnlId where Jrnl_PublID in(1)and Jrnl_Freelancer=1  and CSHL_SubCode=NULL and Artcl_UploadedDt is not null ";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                string textBody = "";
                if (ds.Tables[0].Rows.Count > 0)
                {
                    textBody = "<p>Hi Team,<br /><br />";
                    textBody += "The below article(s) were sent with out CSHL_Subcode on last day : " + DateTime.Now.AddDays(-1).ToString("dd-MM-yyyy") + " <br /><br />";
                    textBody += "<table border=" + 1 + @"><tr><span style='font-size:10.0pt;font-family:Arial'><td align=""center""><b>ArticleID</b></td></span><span style='font-size:10.0pt;font-family:Arial'><td align=""center""><b>Status</b></td></span></tr>";
                    for (int i = 0; i < db.dt.Rows.Count - 1; i++)
                    {
                        textBody += "<tr><span><td>" + db.dt.Rows[i]["Artcl_ArticleId"].ToString() + "</td> <td>" + db.dt.Rows[i]["Artcl_Status"].ToString() + "</span></tr>";

                    }
                    textBody += "</table>";
                    System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("automailer@novatechset.com", "tiworkflow@novatechset.com", "CSHL subcode missing articles list " + DateTime.Now.AddDays(-1).ToString("dd-MM-yyyy"), textBody + "<Br/><Br/>Regards,<Br/>TechSupport.");
                    MM.To.Add("veeramani@novatechset.com");
                    MM.CC.Add("senthilkumaran@novatechset.com");
                    System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                    MM.IsBodyHtml = true;
                    client.Send(MM);
                    File.WriteAllText(System.Environment.CurrentDirectory + @"\TnF_OnshoreCSHL\TnF_OnshoreCSHL" + DateTime.Now.ToString("ddMMyyyy") + @".txt", "");

                }
            }
            catch (Exception e1)
            {
                System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("rajasekar@novatechset.com", "senthilkumaran@novatechset.com", "TnF CSHL Subcode: " + DateTime.Today.ToString("dd/MM/yyyy"), "Error while generating report: " + e1.Message + "<Br/>" + e1.StackTrace + "<Br/><Br/>Regards,<Br/>TechSupport.");
                System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                MM.IsBodyHtml = true;
                client.Send(MM);
                return;
            }
        }


        public void Tnf_Resupplyarticle()
        {
            CommonClass Cs = new CommonClass();
            DBClass db = new DBClass();
            if (Directory.Exists(System.Environment.CurrentDirectory + @"\Tnf_Resupplyarticle\"))
                Directory.Delete(System.Environment.CurrentDirectory + @"\Tnf_Resupplyarticle\", true);
            Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\Tnf_Resupplyarticle\");

            DateTime firstDayOfMonth = DateTime.Now.AddMonths(-1);
            DateTime lastDayOfMonth = firstDayOfMonth.AddMonths(1).AddDays(-1);
            //'" & gstrAuthUserID.Trim & "'
            try
            {
                string S1 = "select Artcl_ArticleId,Artcl_ReceivedDt from article inner join TrnsJournal on  Artcl_Id=JrnlTrns_ArticleId inner join Journal on  Artcl_JrnlId=Jrnl_Id and Jrnl_PublID in(1) where JrnlTrns_Remarks like '%First Proof Resupply Article Transaction Updation%'  and CONVERT(date,Artcl_ReceivedDt) BETWEEN                 '" + firstDayOfMonth.ToString("yyyy-MM-dd") + "' AND '" + lastDayOfMonth.ToString("yyyy-MM-dd") + "' order by Artcl_ReceivedDt desc";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(S1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                string textBody = "";
                //string dt = Regex.Replace(DateTime.Today.ToString("MM/dd/yyyy").Replace("/0", "/"), "^0", "");
                if (ds.Tables[0].Rows.Count > 0)
                {
                    textBody = "<p>Hi Team,<br /><br />";
                    textBody += "The below article(s) were received as First Proof Resupply Article on last month: " + DateTime.Now.AddMonths(-1).ToString("MMM-yyyy") + " <br /><br />";
                    textBody += "<table border=" + 1 + @"><tr><span style='font-size:10.0pt;font-family:Arial'><td align=""center""><b>ArticleID</b></td></span><span style='font-size:10.0pt;font-family:Arial'><td align=""center""><b>Status</b></td></span></tr>";
                    for (int i = 0; i < db.dt.Rows.Count - 1; i++)
                    {
                        textBody += "<tr><span><td>" + db.dt.Rows[i]["Artcl_ArticleId"].ToString() + "</td> <td>" + db.dt.Rows[i]["Artcl_ReceivedDt"].ToString() + "</span></tr>";

                    }
                    textBody += "</table>";
                    System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("automailer@novatechset.com", "sathyac@novatechset.com", "First Proof Resupply Article on last month " + DateTime.Now.AddMonths(-1).ToString("MMM-yyyy"), textBody + "<Br/><Br/>Regards,<Br/>TechSupport.");
                    MM.To.Add("padmashanthi@novatechset.com");
                    MM.CC.Add("senthilkumaran@novatechset.com");
                    //System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("automailer@novatechset.com", "senthilkumaran@novatechset.com", "First Proof Resupply Article on last month " + DateTime.Now.AddMonths(-1).ToString("MMM-yyyy"), textBody + "<Br/><Br/>Regards,<Br/>TechSupport.");
                    System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                    MM.IsBodyHtml = true;
                    client.Send(MM);
                    File.WriteAllText(System.Environment.CurrentDirectory + @"\Tnf_Resupplyarticle\Tnf_Resupplyarticle" + DateTime.Now.ToString("ddMMyyyy") + @".txt", "");

                }
            }
            catch (Exception e1)
            {
                System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("automailer@novatechset.com", "senthilkumaran@novatechset.com", "TnF Format free Report: " + DateTime.Today.ToString("dd/MM/yyyy"), "Error while generating report: " + e1.Message + "<Br/>" + e1.StackTrace + "<Br/><Br/>Regards,<Br/>TechSupport.");
                System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                MM.IsBodyHtml = true;
                client.Send(MM);
                return;
            }
        }
        public string formatdate(string dt)
        {
            string date = dt.Split(' ')[0];
            string time = dt.Split(' ')[1];
            if (date.Split('/')[1].Length == 1) dt = '0' + date.Split('/')[1];
            else dt = date.Split('/')[1];
            dt += '/';
            if (date.Split('/')[0].Length == 1) dt += '0' + date.Split('/')[0];
            else dt += date.Split('/')[0];
            dt += '/' + date.Split('/')[2];
            return dt + ' ' + time;
        }
        public void GenerateIPSCUPXL(string jrnl, string[] Aids, string Vol, string iss, Int32 tot, string fname, DBClass db, CommonClass Cs)
        {
            foreach (Process P in Process.GetProcessesByName("EXCEL"))
            {
                try
                {
                    P.Kill();
                }
                catch (Exception e2) { }
            }
            Xl.Workbook xlWorkBook;
            Xl.Worksheet xlWorkSheet;
            //Xl.Application xlapp;
            //xlapp = new Xl.Application();
            //xlapp.Visible = false;
            string AID = "";
            //string Q1 = "SELECT Artcl_ArtType,Proof_Pages, isnull(Artcl_Platform,'') as Aplatform FROM Article WHERE Artcl_ArticleId IN(" + AID + ")";
            //db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
            //db.dt = new DataTable();
            //db.Sqladptr.Fill(db.dt);
            //db.CloseConnection();
            //DataSet ds = new DataSet("New_DataSet");
            //ds.Tables.Add(db.dt);
            //var rows = ds.Tables[0].Rows;       
            Xl.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            xlApp.Visible = false;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Xl.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            xlWorkSheet.Cells[1, 1] = "MAKE UP STAGE CONTENTS LIST";
            Xl.Range chartRange = xlWorkSheet.get_Range("A1", "K1");
            chartRange.Merge();
            chartRange.EntireColumn.AutoFit();
            chartRange.Font.Bold = true;
            chartRange.Font.Size = 16;
            //CellAlignment(chartRange);
            xlWorkSheet.Cells[3, 1] = "Journal: " + jrnl.ToUpper();
            chartRange = xlWorkSheet.get_Range("A3", "B3");
            chartRange.Merge();
            chartRange.EntireColumn.AutoFit();
            chartRange.Font.Bold = true;
            chartRange.Font.Size = 14;
            //CellAlignment(chartRange);
            xlWorkSheet.Cells[3, 4] = "Vol/Issue: " + Vol + '.' + iss;
            chartRange = xlWorkSheet.get_Range("D3", "G3");
            chartRange.Merge();
            chartRange.EntireColumn.AutoFit();
            chartRange.Font.Bold = true;
            chartRange.Font.Size = 14;
            //CellAlignment(chartRange);
            xlWorkSheet.Cells[3, 8] = "Month: " + DateTime.Today.ToString("MMMM").ToUpper();
            chartRange = xlWorkSheet.get_Range("H3", "I3");
            chartRange.Merge();
            chartRange.EntireColumn.AutoFit();
            chartRange.Font.Bold = true;
            chartRange.Font.Size = 14;
            //CellAlignment(chartRange);
            xlWorkSheet.Cells[3, 10] = "Date: " + DateTime.Today.ToString("dd-MM-yyyy");
            chartRange = xlWorkSheet.get_Range("J3", "K3");
            chartRange.Merge();
            chartRange.EntireColumn.AutoFit();
            chartRange.Font.Bold = true;
            chartRange.Font.Size = 14;
            //CellAlignment(chartRange);
            //Issue Style: Verso and Recto Starts
            string str = "New Recto/Verso and Recto Starts";
            xlWorkSheet.Cells[5, 1] = "Issue Style: " + str;
            chartRange = xlWorkSheet.get_Range("A5", "H5");
            chartRange.Merge();
            chartRange.EntireColumn.AutoFit();
            chartRange.Font.Bold = true;
            chartRange.Font.Size = 14;
            //CellAlignment(chartRange);           
            xlWorkSheet.Cells[5, 9] = "Spine Width: XXmm";
            chartRange = xlWorkSheet.get_Range("I5", "K5");
            chartRange.Merge();
            chartRange.EntireColumn.AutoFit();
            chartRange.Font.Bold = true;
            chartRange.Font.Size = 14;
            //CellAlignment(chartRange);

            xlWorkSheet.Cells[7, 1] = "S.No";
            xlWorkSheet.Cells[7, 2] = "Article ID";
            xlWorkSheet.Cells[7, 3] = "CUP ref No";
            xlWorkSheet.Cells[7, 4] = "DOI/PII No";
            xlWorkSheet.Cells[7, 5] = "First Author Surname";
            xlWorkSheet.Cells[7, 6] = "Page Range";
            chartRange = xlWorkSheet.get_Range("F7", "G7");
            chartRange.Merge();
            xlWorkSheet.Cells[7, 8] = "Blank Pages";
            xlWorkSheet.Cells[7, 9] = "Colour Figures on Pages";
            chartRange = xlWorkSheet.get_Range("I7", "J7");
            chartRange.Merge();
            xlWorkSheet.Cells[7, 11] = "Online Publication date";
            chartRange = xlWorkSheet.get_Range("A7", "A8");
            chartRange.Merge();
            chartRange = xlWorkSheet.get_Range("B7", "B8");
            chartRange.Merge();
            chartRange = xlWorkSheet.get_Range("C7", "C8");
            chartRange.Merge();
            chartRange = xlWorkSheet.get_Range("D7", "D8");
            chartRange.Merge();
            chartRange = xlWorkSheet.get_Range("E7", "E8");
            chartRange.Merge();
            chartRange = xlWorkSheet.get_Range("F7", "G8");
            chartRange.Merge();
            chartRange = xlWorkSheet.get_Range("H7", "H8");
            chartRange.Merge();
            xlWorkSheet.Cells[8, 9] = "Print (page no)";
            xlWorkSheet.Cells[8, 10] = "Online (fig no)";
            chartRange = xlWorkSheet.get_Range("K7", "K8");
            chartRange.Merge();
            chartRange = xlWorkSheet.get_Range("A7", "K8");
            chartRange.EntireColumn.AutoFit();
            chartRange.Font.Bold = true;
            int i1 = 9;
            string au = "", p1 = "", p2 = "", seq = "", pii = "";
            int i = 0;
            for (i = 0; i < Aids.Length; i++)
            {
                AID = Aids[i];
                au = ""; p1 = ""; p2 = ""; seq = ""; pii = "";
                if (Aids[i].Split(':').Length > 0)
                {
                    AID = Aids[i].Split(':')[0];
                    au = Aids[i].Split(':')[3];
                    seq = Aids[i].Split(':')[1];
                    pii = Aids[i].Split(':')[2];
                }
                p1 = Cs.ReturnDetail("Artcl_FirstPage", "Article", db, "Artcl_DOI='" + pii + @"' or Artcl_PII='" + pii + @"'");
                p2 = Cs.ReturnDetail("Artcl_LastPage", "Article", db, "Artcl_DOI='" + pii + @"' or Artcl_PII='" + pii + @"'");
                string dt = Cs.ReturnDetail("Artcl_WebDelivery", "Article", db, "Artcl_DOI='" + pii + @"' or Artcl_PII='" + pii + @"'");
                xlWorkSheet.Cells[i1, 1] = i + 1;
                xlWorkSheet.Cells[i1, 2] = AID;
                xlWorkSheet.Cells[i1, 3] = seq;
                xlWorkSheet.Cells[i1, 4] = pii;
                xlWorkSheet.Cells[i1, 5] = au;
                xlWorkSheet.Cells[i1, 6] = p1;
                xlWorkSheet.Cells[i1, 7] = p2;
                xlWorkSheet.Cells[i1, 8] = "";
                string gt = "";
                if (Directory.Exists(@"\\techsetserver2\Journal\CUP\" + jrnl + @"\ISSUE\" + Vol + "-" + iss + @"\Pagination\") && System.IO.Directory.GetFiles(@"\\techsetserver2\Journal\CUP\" + jrnl + @"\ISSUE\" + Vol + "-" + iss + @"\Pagination\", pii + "*.3d").Count() > 0)
                {
                    foreach (string f in System.IO.Directory.GetFiles(@"\\techsetserver2\Journal\CUP\" + jrnl + @"\ISSUE\" + Vol + "-" + iss + @"\Pagination\", pii + "*.3d"))
                    {
                        if (Regex.IsMatch(Path.GetFileName(f), pii + @"[a-z]{3}\.3d", RegexOptions.IgnoreCase))
                        {
                            Process compiler = new Process();
                            compiler.StartInfo.FileName = @"\\techsetserver1\Library\DevelopmentTool\APP_Image_Details.exe";
                            compiler.StartInfo.Arguments = f;
                            compiler.StartInfo.UseShellExecute = false;
                            compiler.StartInfo.RedirectStandardOutput = true;
                            compiler.StartInfo.CreateNoWindow = true;
                            compiler.Start();
                            gt = compiler.StandardOutput.ReadToEnd();
                            compiler.WaitForExit();
                            break;
                        }
                    }
                }
                else if (Directory.Exists(@"\\techsetserver2\Journal\CUP\" + jrnl + @"\Articles\Pagination\") && System.IO.Directory.GetFiles(@"\\techsetserver2\Journal\CUP\" + jrnl + @"\Articles\Pagination\", pii + "*.3d").Count() > 0)
                {
                    foreach (string f in System.IO.Directory.GetFiles(@"\\techsetserver2\Journal\CUP\" + jrnl + @"\Articles\Pagination\", pii + "*.3d"))
                    {
                        if (Regex.IsMatch(Path.GetFileName(f), pii + @"[a-z]{3}\.3d", RegexOptions.IgnoreCase))
                        {
                            Process compiler = new Process();
                            compiler.StartInfo.FileName = @"\\techsetserver1\Library\DevelopmentTool\APP_Image_Details.exe";
                            compiler.StartInfo.Arguments = f;
                            compiler.StartInfo.UseShellExecute = false;
                            compiler.StartInfo.RedirectStandardOutput = true;
                            compiler.StartInfo.CreateNoWindow = true;
                            compiler.Start();
                            gt = compiler.StandardOutput.ReadToEnd();
                            compiler.WaitForExit();
                            break;
                        }
                    }
                }
                string col9val = "", col10val = "";
                if (gt != "")
                {
                    foreach (Match m in Regex.Matches(gt, "<figure( [^<>]*?)/>"))
                    {
                        if (Regex.IsMatch(m.Value, @" color=""online""") || Regex.IsMatch(m.Value, @" color=""yes"""))
                        {
                            col9val += "p." + Regex.Match(m.Value, @" page=""(\d+)""").Groups[1].Value + " (fig: " + Regex.Replace(Regex.Match(m.Value, @" id=""fig(\d+)""").Groups[1].Value, "^0+", "") + "), ";
                            col10val += "fig: " + Regex.Replace(Regex.Match(m.Value, @" id=""fig(\d+)""").Groups[1].Value, "^0+", "") + ", ";
                        }

                    }
                    col9val = Regex.Replace(col9val, ", $", "");
                    col10val = Regex.Replace(col10val, ", $", "");
                }
                xlWorkSheet.Cells[i1, 9] = col9val;
                xlWorkSheet.Cells[i1, 10] = col10val;
                xlWorkSheet.Cells[i1, 11] = dt;
                i1++;
            }
            xlWorkSheet.Cells[i1, 1] = i + 1;
            xlWorkSheet.Cells[i1, 2] = jrnl + "_" + Vol + "_" + iss + "_Cover";
            xlWorkSheet.Cells[i1, 3] = "";
            xlWorkSheet.Cells[i1, 4] = "";
            xlWorkSheet.Cells[i1, 5] = "";
            xlWorkSheet.Cells[i1, 6] = "";
            xlWorkSheet.Cells[i1, 7] = "";
            xlWorkSheet.Cells[i1, 8] = "";
            xlWorkSheet.Cells[i1, 9] = "";
            xlWorkSheet.Cells[i1, 10] = "";
            xlWorkSheet.Cells[i1, 11] = "";
            i1++;
            i++;
            xlWorkSheet.Cells[i1, 1] = i + 1;
            xlWorkSheet.Cells[i1, 2] = "C1,C2 and FM";
            xlWorkSheet.Cells[i1, 3] = "";
            xlWorkSheet.Cells[i1, 4] = "";
            xlWorkSheet.Cells[i1, 5] = "";
            xlWorkSheet.Cells[i1, 6] = "";
            xlWorkSheet.Cells[i1, 7] = "";
            xlWorkSheet.Cells[i1, 8] = "";
            xlWorkSheet.Cells[i1, 9] = "";
            xlWorkSheet.Cells[i1, 10] = "";
            xlWorkSheet.Cells[i1, 11] = "";
            i1++;
            i++;
            xlWorkSheet.Cells[i1, 1] = i + 1;
            xlWorkSheet.Cells[i1, 2] = "C3,C4 and BM";
            xlWorkSheet.Cells[i1, 3] = "";
            xlWorkSheet.Cells[i1, 4] = "";
            xlWorkSheet.Cells[i1, 5] = "";
            xlWorkSheet.Cells[i1, 6] = "";
            xlWorkSheet.Cells[i1, 7] = "";
            xlWorkSheet.Cells[i1, 8] = "";
            xlWorkSheet.Cells[i1, 9] = "";
            xlWorkSheet.Cells[i1, 10] = "";
            xlWorkSheet.Cells[i1, 11] = "";
            i1++;
            chartRange = xlWorkSheet.get_Range("J" + i1, "K" + i1);
            chartRange.Merge();
            xlWorkSheet.Cells[i1, 10] = "Total Pages: " + tot + " + cover";
            chartRange = xlWorkSheet.get_Range("A7", "K" + (i1 - 1));
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeLeft).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeRight).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideHorizontal).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideVertical).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeBottom).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeTop).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Cells.HorizontalAlignment = Xl.XlHAlign.xlHAlignCenter;
            chartRange.Cells.VerticalAlignment = Xl.XlHAlign.xlHAlignCenter;
            chartRange = xlWorkSheet.get_Range("J" + i1, "K" + i1);
            chartRange.Font.Bold = true;
            chartRange.Font.Size = 14;
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeLeft).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeRight).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideHorizontal).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlInsideVertical).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeBottom).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Borders.get_Item(Xl.XlBordersIndex.xlEdgeTop).LineStyle = Xl.XlLineStyle.xlContinuous;
            chartRange.Cells.HorizontalAlignment = Xl.XlHAlign.xlHAlignCenter;
            chartRange.Cells.VerticalAlignment = Xl.XlHAlign.xlHAlignCenter;
            chartRange = xlWorkSheet.get_Range("K9", "K" + i1);
            chartRange.EntireColumn.NumberFormat = "dd MMM yyyy";
            chartRange.EntireColumn.AutoFit();
            chartRange = xlWorkSheet.get_Range("A1", "K" + (i1 - 1));
            chartRange.Cells.HorizontalAlignment = Xl.XlHAlign.xlHAlignCenter;
            chartRange.Cells.VerticalAlignment = Xl.XlHAlign.xlHAlignCenter;
            chartRange.EntireColumn.AutoFit();
            chartRange = xlWorkSheet.get_Range("F7", "G8");
            chartRange.ColumnWidth = 10;
            if (!Directory.Exists(Path.GetDirectoryName(fname)))
            {
                if (!(Directory.Exists(@"D:\WatchTXT"))) Directory.CreateDirectory(@"D:\WatchTXT");
                xlWorkSheet.SaveAs(@"D:\WatchTXT\" + Path.GetFileName(fname));
                File.WriteAllText(@"D:\WatchTXT\" + Path.GetFileNameWithoutExtension(fname) + @".txt", @"D:\WatchTXT\" + Path.GetFileName(fname) + @"~" + fname);
            }
            else xlWorkSheet.SaveAs(fname);
            xlApp.Quit();
            foreach (Process P in Process.GetProcessesByName("EXCEL"))
            {
                try
                {
                    P.Kill();
                }
                catch (Exception e2) { }
            }
        }

        public void CUP_Hold_Articles()
        {
            CommonClass Cs = new CommonClass();
            DBClass db = new DBClass();
            if (!(Directory.Exists(System.Environment.CurrentDirectory + @"\CUP_Report\"))) Directory.CreateDirectory(System.Environment.CurrentDirectory + @"\CUP_Report\");
            try
            {
                string Q1 = "SSP_AutoReport 12";
                db.Sqladptr = new SqlDataAdapter(new SqlCommand(Q1, db.GetConnection()));
                db.dt = new DataTable();
                db.Sqladptr.Fill(db.dt);
                db.CloseConnection();
                DataSet ds = new DataSet("New_DataSet");
                ds.Tables.Add(db.dt);
                string textBody = "";
                string dt = Regex.Replace(DateTime.Today.ToString("MM/dd/yyyy").Replace("/0", "/"), "^0", "");
                if (ds.Tables[0].Rows.Count > 0)
                {
                    textBody = "<h2><u>CUP Hold Articles</u></h2><table border=" + 1 + "><tr  bgcolor='#87cefa'>";
                    //<td><b>ArticleID</b></td><td> <b>ReceivedDate</b></td><td> <b>ScheduledDate</b></td><td> <b>Status</b></td><td> <b>CEReceivedDate</b></td> <td> <b>CEReceivedDate</b></td></tr>";                   
                    foreach (DataColumn myColumn in ds.Tables[0].Columns)
                    {
                        textBody += "<td><b>" + myColumn.ColumnName + "</b></td>";
                    }
                    //textBody += "<td><b>Due/Overdue</b></td>";
                    textBody += "</tr>";
                    foreach (DataRow myRow in ds.Tables[0].Rows)
                    {
                        //if (myRow["ScheduledDate"].ToString().Split(' ')[0] != dt) textBody += "<tr bgcolor='red'>";
                        //else textBody += "<tr >";
                        foreach (DataColumn myColumn in ds.Tables[0].Columns)
                        {
                            //if (myColumn.ColumnName == "ScheduledDate" || myColumn.ColumnName == "ReceivedDate") textBody += "<td >" + formatdate(myRow[myColumn.ColumnName].ToString()) + "</td>";
                            //else textBody += "<td >" + myRow[myColumn.ColumnName].ToString() + "</td>";
                        }
                        //if (myRow["ScheduledDate"].ToString().Split(' ')[0] != dt) textBody += "<td >Overdue</td>";
                        //else textBody += "<td >Due</td>";
                        textBody += "</tr>";
                    }
                    textBody += "</table>";
                }
                else textBody += "<h2><u>CUP HOLD Articles</u></h2><h3>No Record Found</h3>";

                System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("rajasekar@novatechset.com", "parasakthis@novatechset.com;cup_firstproof@novatechset.com; cup_revises@novatechset.com; cambridgeproduction@novatechset.com;tiworkflow@novatechset.com;annapandiyan@novatechset.com;Saravanakumar@novatechset.com", "CUP Hold Article Report: " + DateTime.Today.ToString("dd/MM/yyyy"), textBody + "<Br/><Br/>Regards,<Br/>TechSupport.");
                
                //MM.Bcc.Add("automailer@novatechset.com");
                //MM.Bcc.Add("Saravanakumar@novatechset.com");
                //System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("Rajasekar@novatechset.com", "parthiban@novatechset.com", "CUP RCP Report: " + DateTime.Today.ToString("dd/MM/yyyy"), textBody + "<Br/><Br/>Regards,<Br/>TechSupport.");
                System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                MM.IsBodyHtml = true;
                client.Send(MM);
                File.WriteAllText(System.Environment.CurrentDirectory + @"\CUP_Report\CUP_Hold_Report_" + DateTime.Now.ToString("ddMMyyyy") + @".txt", "");
            }
            catch (Exception ex)
            {
                System.Net.Mail.MailMessage MM = new System.Net.Mail.MailMessage("annapandiyan@novatechset.com", "parasakthis@novatechset.com", "CUP Hold Report: " + DateTime.Today.ToString("dd/MM/yyyy"), "Error while generating report: " + ex.Message + "<Br/>" + ex.StackTrace + "<Br/><Br/>Regards,<Br/>TechSupport.");
                System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient(SerializedClass.MailServer);
                MM.IsBodyHtml = true;
                client.Send(MM);
                return;
            }

        }

        // CUP HOLD ARTICLES END

    }
}
